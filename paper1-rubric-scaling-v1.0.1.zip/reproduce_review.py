"""Offline replay of Table 6 and outcome-known NI sensitivity from aggregates.

This file is copied to the root of the release package as reproduce_review.py.
It does not call models, read student records, or create new bootstrap draws.
"""
from pathlib import Path
import json
import numpy as np

ROOT = Path(__file__).resolve().parent
LABELS = ['Qwen3 0.6B', 'Qwen3 1.7B', 'Qwen3 4B', 'Qwen3 8B',
          'Qwen3 14B', 'Qwen3 32B', 'HCX-007', 'GPT-5.6 Sol',
          'Claude Sonnet 5', 'Gemini 3.1 Pro', 'EXAONE 1.2B',
          'Kanana 1.3B', 'HCX SEED 1.5B', 'Mi:dm Mini 2.3B']


def read(name):
    return json.loads((ROOT / 'aggregate' / name).read_text('utf-8'))


def holm(values):
    flat = np.asarray(values).ravel()
    order = np.argsort(flat, kind='stable')
    adjusted = np.maximum.accumulate(flat[order] * np.arange(len(flat), 0, -1))
    result = np.empty_like(flat)
    result[order] = np.minimum(adjusted, 1)
    return result.reshape(np.shape(values))


def boundaries(passes, keys, models):
    result = {}
    for c, key in enumerate(keys):
        retained = None
        for m in reversed(range(6)):
            if not passes[m, c]:
                break
            retained = models[m]
        result[key] = retained
    return result


def table6(data):
    rows = ['| Model | Initial valid | Final valid | Initial QWK | Final QWK | Initial loss | Final loss |',
            '|---|---:|---:|---:|---:|---:|---:|']
    assert len(data['first_final_protocol']) == len(LABELS)
    for label, row in zip(LABELS, data['first_final_protocol']):
        vals = [label, str(row['first_valid']), str(row['final_valid'])]
        vals += [f'{row[k]:.4f}'.removeprefix('0') for k in
                 ('first_qwk', 'final_qwk', 'first_loss', 'final_loss')]
        rows.append('| ' + ' | '.join(vals) + ' |')
    return '\n'.join(rows) + '\n'


def sensitivity():
    base = read('constructed.json')
    models, keys = base['models'][:6], base['rubric_keys']
    expected = read('noninferiority_sensitivity.json')
    with np.load(ROOT / 'aggregate/ni_qwk_bootstrap.npz', allow_pickle=False) as z:
        assert set(z.files) == {'qwk', 'qwk_boot'}
        assert z['qwk'].shape == (10, 8)
        assert z['qwk_boot'].shape == (9999, 10, 8)
        point = z['qwk'][:6] - np.median(z['qwk'][6:10], axis=0)
        draws = z['qwk_boot'][:, :6] - np.median(z['qwk_boot'][:, 6:10], axis=1)[:, None, :]
    centered = draws - point
    results = {}
    for margin in (.05, .03):
        percentile_p = ((draws <= -margin).sum(axis=0) + 1) / (len(draws) + 1)
        basic_p = ((centered >= point + margin).sum(axis=0) + 1) / (len(draws) + 1)
        percentile_low = np.percentile(draws, 5, axis=0)
        basic_low = point - np.percentile(centered, 95, axis=0)
        p_holm, b_holm = holm(percentile_p), holm(basic_p)
        percentile_pass = (point > -margin) & (percentile_low > -margin) & (p_holm < .05)
        basic_pass = (point > -margin) & (basic_low > -margin) & (b_holm < .05)
        result = {
            'archived_percentile_boundaries_reproduced': boundaries(percentile_pass, keys, models),
            'exploratory_basic_bootstrap_boundaries': boundaries(basic_pass, keys, models),
            'changed_cell_decisions': int(np.count_nonzero(percentile_pass != basic_pass)),
            'delta': point.tolist(), 'percentile_holm_p': p_holm.tolist(),
            'basic_holm_p': b_holm.tolist(), 'basic_one_sided_95_lower': basic_low.tolist()}
        target = expected[str(margin)]
        for field in ('delta', 'percentile_holm_p', 'basic_holm_p', 'basic_one_sided_95_lower'):
            np.testing.assert_allclose(result[field], target[field], rtol=0, atol=1e-14)
        for field in ('archived_percentile_boundaries_reproduced',
                      'exploratory_basic_bootstrap_boundaries', 'changed_cell_decisions'):
            assert result[field] == target[field], (margin, field)
        for m, model in enumerate(models):
            for c, key in enumerate(keys):
                old = base['noninferiority']['all_48_holm'][str(margin)][key]['sizes'][model]
                assert abs(old['raw_p'] - percentile_p[m, c]) < 1e-14
                assert abs(old['holm_48_p'] - p_holm[m, c]) < 1e-14
                assert old['pass_holm'] == bool(percentile_pass[m, c])
        results[str(margin)] = result
    return results


def main():
    data = read('constructed_review_diagnostics.json')
    table = table6(data)
    assert table == (ROOT / 'expected/table6.md').read_text('utf-8')
    assert sum(r['regenerated'] for r in data['first_final_protocol']) == 946
    assert sum(r['regenerated_paired_valid_scores'] for r in data['first_final_protocol']) == 0
    for family in ('constructed', 'essay'):
        for row in read(f'{family}_review_diagnostics.json')['human_distributions']:
            for slot in ('h1', 'h2'):
                p = np.asarray(row[f'score_probabilities_{slot}'])
                np.testing.assert_allclose(p.sum(), 1, rtol=0, atol=1e-12)
                np.testing.assert_allclose(p @ np.arange(1, 6), row[f'mean_{slot}'], rtol=0, atol=1e-12)
                assert p[0] == row[f'floor_{slot}'] and p[4] == row[f'ceiling_{slot}']
    ni = sensitivity()
    out = ROOT / 'replayed'
    out.mkdir(exist_ok=True)
    (out / 'table6.md').write_text(table, encoding='utf-8')
    (out / 'ni_sensitivity.json').write_text(json.dumps(ni, indent=2, allow_nan=False), encoding='utf-8')
    result = dict(table6_numeric_cells=84, human_distribution_rows=32,
                  ni_margins_replayed=2, ni_original_cell_decisions_checked=96,
                  bootstrap_draws_reused=9999, raw_student_records_read=0,
                  new_inference_calls=0, status='pass',
                  interpretation='Aggregate replay, not independent record-level replication or exact finite-sample NI calibration')
    (out / 'review_checks.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
