# Supplementary methods and reviewer diagnostics

This supplement accompanies “Criterion-Dependent Associations between Qwen3 Model Size and Zero-Shot Scoring of Korean Constructed Responses.” All diagnostics added here were designed after the model outcomes were known. They supplement the archived analyses without replacing their hypotheses, scores, or decisions. No additional model inference was performed.

## Analysis chronology and scope

The original investigator JDI and positive directional hypothesis preceded model-outcome analysis, but human agreement had already been inspected. The intended independent-expert condition remained undocumented. Consequently, the moderator interpretation is exploratory despite its prospective relationship to model-outcome access. Three AI-assisted forms with reported expert review do not establish independent blinded coding or adjudicated consensus.

Amendment 013 documented deviations before outcome access in that analysis run and corrected the one-sided percentile-bound and multiplicity implementations. Amendments 014 and 015 added answer-blind controls, curve sensitivity, within-item discrimination, first-attempt analysis, literal rules, and supervised text controls after outcomes were known. Amendment 016 specified the current rater-slot, protocol, and grade diagnostics before executing those additions, but was also written with outcome knowledge. This chronology is not external preregistration and does not convert these analyses to confirmation.

QWK remains the original primary agreement endpoint. Normalized squared loss is a secondary error endpoint; within-item discrimination is a post hoc diagnostic. No co-primary endpoint was introduced after observing a favorable result. The two original human annotations are kept separate instead of constructing a new consensus gold.

## Human score distributions

Each applicable item contributes equal total weight. Within an item, answers receive equal weights. For each rubric and human annotation slot, the weighted proportions in score categories 1–5 sum to one. The tables show means and top-score proportions; the accompanying aggregate JSON also reports all five probabilities and bottom-score proportions for every rubric. Human-human QWK uses the same equal-item weighting as the manuscript.

H1 and H2 denote annotation positions in each response record. These summaries do not establish that a position identifies a single named rater across all records, nor do they reconstruct rater training, assignment, or adjudication. Differences are descriptive, not persistent-severity estimates from a rater-effects model.

### Constructed response annotations

| Rubric | Responses | Items | H1 mean | H2 mean | H1 score 5 | H2 score 5 | Human QWK |
|---|---|---|---|---|---|---|---|
| Task fulfillment | 4000 | 60 | 3.509 | 3.546 | 0.132 | 0.156 | 0.671 |
| Explanatory clarity | 4000 | 60 | 3.466 | 3.466 | 0.121 | 0.142 | 0.618 |
| Explanatory detail | 4000 | 60 | 3.100 | 3.167 | 0.057 | 0.080 | 0.589 |
| Keyword inclusion | 4000 | 60 | 2.753 | 2.751 | 0.094 | 0.093 | 0.991 |
| Sentence connections | 4000 | 60 | 3.405 | 3.535 | 0.090 | 0.114 | 0.495 |
| Thematic unity | 4000 | 60 | 3.462 | 3.520 | 0.110 | 0.136 | 0.642 |
| Lexical appropriateness | 4000 | 60 | 3.616 | 3.658 | 0.158 | 0.138 | 0.479 |
| Grammar and spacing | 4000 | 60 | 3.821 | 3.818 | 0.317 | 0.311 | 0.956 |

### Essay response annotations

| Rubric | Responses | Items | H1 mean | H2 mean | H1 score 5 | H2 score 5 | Human QWK |
|---|---|---|---|---|---|---|---|
| B-00A-1A-2A | 824 | 28 | 3.494 | 3.484 | 0.085 | 0.089 | 0.647 |
| B-00B-1A-2A | 698 | 30 | 3.512 | 3.579 | 0.060 | 0.089 | 0.692 |
| B-00C-1A-2A | 478 | 31 | 3.637 | 3.741 | 0.100 | 0.105 | 0.613 |
| B-00A-1B-2G | 824 | 28 | 3.302 | 3.249 | 0.072 | 0.048 | 0.504 |
| B-00B-1B-2M | 698 | 30 | 3.303 | 3.285 | 0.058 | 0.048 | 0.506 |
| B-00C-1B-2O | 478 | 31 | 3.393 | 3.437 | 0.050 | 0.070 | 0.457 |
| B-00A-1B-2F | 824 | 28 | 3.174 | 3.203 | 0.049 | 0.074 | 0.481 |
| B-00B-1B-2N | 698 | 30 | 3.128 | 3.139 | 0.031 | 0.056 | 0.493 |
| B-00C-1B-2P | 478 | 31 | 3.314 | 3.284 | 0.070 | 0.057 | 0.570 |
| B-00A-1B-2H | 824 | 28 | 3.319 | 3.259 | 0.111 | 0.085 | 0.700 |
| B-00B-1B-2B | 698 | 30 | 3.280 | 3.231 | 0.058 | 0.065 | 0.649 |
| B-00C-1B-2Q | 478 | 31 | 3.313 | 3.416 | 0.076 | 0.086 | 0.596 |
| B-00A-1C-2E | 824 | 28 | 3.155 | 3.239 | 0.041 | 0.046 | 0.485 |
| B-00B-1C-2C | 698 | 30 | 3.216 | 3.245 | 0.029 | 0.044 | 0.487 |
| B-00C-1C-2C | 478 | 31 | 3.259 | 3.324 | 0.048 | 0.042 | 0.479 |
| B-00A-1C-2D | 824 | 28 | 3.350 | 3.415 | 0.066 | 0.075 | 0.551 |
| B-00B-1C-2D | 698 | 30 | 3.417 | 3.476 | 0.054 | 0.074 | 0.558 |
| B-00C-1C-2D | 478 | 31 | 3.548 | 3.626 | 0.070 | 0.071 | 0.496 |
| B-00A-1D-2L | 824 | 28 | 3.444 | 3.518 | 0.073 | 0.080 | 0.463 |
| B-00B-1D-2K | 698 | 30 | 3.476 | 3.612 | 0.059 | 0.067 | 0.479 |
| B-00C-1D-2K | 478 | 31 | 3.547 | 3.585 | 0.086 | 0.081 | 0.462 |
| B-00A-1D-2I | 824 | 28 | 3.718 | 3.775 | 0.170 | 0.187 | 0.797 |
| B-00B-1D-2J | 698 | 30 | 3.733 | 3.792 | 0.143 | 0.156 | 0.833 |
| B-00C-1D-2J | 478 | 31 | 3.827 | 3.831 | 0.150 | 0.155 | 0.927 |

## Separate reference annotation sensitivity

For each model and rubric, weighted QWK is calculated separately against H1 and H2. Loss uses squared score difference divided by 16, with unresolved predictions assigned loss 1 separately for each human reference. The same 9,999 archived item draws are used for both slots and all models. Intervals below are outcome-known, unadjusted paired percentile intervals, conditional on the fixed rubric set. The archive reports all models and rubric cells, not only the contrasts highlighted here.

| Dataset | Reference | 32B minus 4B QWK | 95% interval | Loss difference | 95% interval |
|---|---|---|---|---|---|
| constructed | H1 | 0.0517 | 0.0309 to 0.0724 | 0.01486 | 0.00800 to 0.02187 |
| constructed | H2 | 0.0713 | 0.0506 to 0.0915 | 0.00849 | 0.00210 to 0.01502 |
| essay | H1 | 0.0220 | -0.0008 to 0.0460 | 0.03175 | 0.02649 to 0.03713 |
| essay | H2 | 0.0325 | 0.0096 to 0.0554 | 0.02834 | 0.02360 to 0.03324 |

Constructed-response QWK and loss differences were positive for both human annotations: higher agreement at 32B coexisted with larger absolute score error. Essay QWK uncertainty was sensitive to the reference, with the H1 interval crossing zero. The corresponding essay loss differences were positive for both references. This does not rank one human annotation as the true criterion.

The original-coding constructed-response JDI coefficients were -0.0243 for H1 and -0.0210 for H2. Essay coefficients were -0.0121 for H1 and -0.0043 for H2, with the H2 interval including zero. This sensitivity reinforces the restriction against claiming a replicated general inverse mechanism.

## Grade summaries

All grade strata and all models are retained in the aggregate JSON. The table contrasts 4B and 32B to expose the agreement–error distinction, not to select a favorable stratum. QWK is averaged across applicable rubric keys; loss averages applicable items and rubric keys. Grade strata have different items and, for essays, potentially different rubric composition. No causal grade contrast, multiplicity-adjusted subgroup discovery, or gender/region fairness claim is made. Each constructed-response grade contains only 12 items.

| Dataset | Grade | Responses | Items | Rubrics | 4B QWK | 32B QWK | 4B loss | 32B loss |
|---|---|---|---|---|---|---|---|---|
| constructed | 5 | 956 | 12 | 8 | 0.2651 | 0.3453 | 0.0849 | 0.0897 |
| constructed | 6 | 882 | 12 | 8 | 0.2504 | 0.3303 | 0.0832 | 0.0889 |
| constructed | 7 | 763 | 12 | 8 | 0.2768 | 0.3439 | 0.0856 | 0.0970 |
| constructed | 8 | 749 | 12 | 8 | 0.2495 | 0.2945 | 0.0877 | 0.1083 |
| constructed | 9 | 650 | 12 | 8 | 0.2954 | 0.3269 | 0.0807 | 0.0968 |
| essay | 5 | 534 | 22 | 24 | 0.2159 | 0.2611 | 0.0558 | 0.0840 |
| essay | 6 | 420 | 16 | 24 | 0.1654 | 0.2047 | 0.0552 | 0.0922 |
| essay | 7 | 469 | 23 | 24 | 0.2249 | 0.2435 | 0.0521 | 0.0808 |
| essay | 8 | 238 | 10 | 24 | 0.1205 | 0.1415 | 0.0440 | 0.0760 |
| essay | 9 | 339 | 18 | 24 | 0.2096 | 0.2339 | 0.0519 | 0.0752 |

## Initial output and regeneration

Main-text Table 6 reports every constructed-response pipeline's initial and final coverage, complete-case QWK, and failure-inclusive loss. The archived regeneration flag identifies 868 Gemini, 27 EXAONE, and 51 HCX SEED model-response cases. None has a valid first and final score-vector pair under the frozen strict parser. Consequently, score preservation, paired score agreement, and score shift cannot be estimated for that subset using that parser. Missing initial judgments are not imputed, assigned score zero, or parsed with a new outcome-selected permissive rule. All initially valid records retain identical initial and final scores. All six essay pipelines parsed on their initial attempts.

The common initial-valid Qwen/API constructed subset has 3,132 answers, retaining all 60 items but 3–128 answers per item. It changes the sentence-connections boundary at margin .05 from 14B to 32B. Selection on initial parse success changes population composition and precision; this comparison is not a causal effect of regeneration. Provider-specific generation constraints remain part of the evaluated pipelines.

## Noninferiority calculation sensitivity

An outcome-known sensitivity reuses the archived model-by-rubric QWK draws. The four-API median reference is recalculated in every draw. The original percentile procedure counts bootstrap differences at or below the negative margin. The comparison procedure centers each bootstrap difference at its observed difference and counts centered draws at or above the observed difference plus the margin. Each tail count uses the same add-one correction. The basic lower bound is the observed difference minus the 95th percentile of centered draws. Both procedures apply Holm correction to all 48 hypotheses and the same descending stop rule separately at margins .05 and .03.

At .05, explanatory clarity changes from retained 32B to retained 14B; its 14B adjusted tail value changes from .0943 to .0492. At .03, task fulfillment changes from no retained size to retained 32B; its 32B adjusted tail value changes from .0675 to .0094. Exactly one cell decision changes under each margin. The .0492 result is particularly close to the decision threshold. The original results are retained rather than replaced by the more favorable method.

Both procedures are approximate. Agreement or disagreement between them does not validate finite-sample error control, the educational meaning of the chosen margin, or the safety of a retained model size. The aggregate-only computational release includes QWK point estimates and paired bootstrap draws for this sensitivity; these are model-by-criterion statistics, not response-level predictions or original item identifiers.

## Korean model residuals and curve form

Under the original log-linear curve, mean QWK residuals were -.0116 for EXAONE, +.0446 for Kanana, +.1106 for HCX SEED, and +.0510 for Mi:dm. Four-model simultaneous intervals excluded zero positively for Kanana, HCX SEED, and Mi:dm. Under adjacent-size interpolation, the corresponding residuals were -.0124, +.0372, +.0913, and +.0090. Mi:dm's interval then included zero [-.0208, .0387], while Kanana and HCX SEED retained positive intervals.

Loss residuals also depended on curve form. Although all four original log-linear mean-loss intervals were negative, HCX SEED's interpolated residual interval included zero [-.0172, .0042]. Consequently, an unqualified claim that all Korean models reduce loss relative to a scale-matched expectation is unsupported across these two curve specifications. These comparisons remain non-causal differences among model families, not isolated effects of Korean-language specialization.

## Score collapse and size exclusion

Qwen 0.6B assigned all eight scores the maximum for 3,723 of 4,000 constructed responses and 1,995 of 2,000 essays. This concerns the frozen prompt, chat template, and structured generation configuration. All six leave-one-size-out analyses were retained for all five coding variants; removal of 0.6B did not eliminate the negative constructed association, while essay intervals included zero. These analyses do not validate the moderator, establish universal incapacity at 0.6B, or test alternative prompts.

## Computational verification and restricted inputs

New point estimates were checked using direct response weights and sklearn quadratic kappa, separately from the confusion-matrix aggregation. All 1,344 scalar checks agreed to within 7.78e-16. Three additional synthetic tests verified equal-item human distributions, missing-prediction loss, and the annotation-specific bootstrap. The primary predictions and archived analyses were unchanged.

Aggregate replay can reproduce tables and the noninferiority sensitivity without student responses. It does not reconstruct the original human annotations or model calls. Full record-level reanalysis requires separately authorized source data, corresponding manifests and predictions, and the historical configuration. A random seed alone is insufficient. Original text, record identifiers, private ethics documents, and expert forms are excluded from the public release. The computational materials are identified by version DOI 10.5281/zenodo.23345003. On 13 October 2026, the author stated that existing exemption P01-202605-01-076 applied to the present secondary analysis. This attestation is not presented as a new institutional determination specifically covering hosted or external API processing; the private determination is not included in the public release.

## Detailed control implementations

### Answer-blind controls

We evaluated four prespecified-for-this-extension rules: a constant score of 3; the Training rubric-mode score; the Training item-by-rubric mode; and the Training item-by-rubric mean rounded to the nearest integer. Both individual Training raters contributed equally. Mode ties used the lower score; mean ties were rounded upward. No rule was selected or tuned using evaluation labels.

Before fitting these rules, we excluded Training answers with Unicode-NFC and whitespace-normalized text matching an evaluation answer in the same dataset. This removed 1 of 32,006 constructed Training records and 4 of 16,010 essay Training records. All evaluation item-rubric combinations retained Training support. The original LLM evaluation sample was unchanged. Within essay evaluation, two records shared normalized answer text; this does not establish that they were the same student.

These controls do not inspect an evaluation answer to choose its score. Item-specific rules nevertheless use labeled Training responses to the same items and are not information-matched competitors to zero-shot LLMs. They diagnose what item-level score priors can achieve without response-level interpretation. All four rules and all model comparisons were retained. Paired bootstrap intervals reused the archived evaluation-item resamples, conditional on the fitted Training rules; Training-fit uncertainty was not resampled. Difference intervals are descriptive and unadjusted for multiple comparisons.


### Additional post hoc discrimination and protocol diagnostics

Within each item, criterion, and reference rater, we compared all unordered pairs of answers whose human scores differed and whose model scores were available. Concordant model orderings received 1, reversed orderings 0, and model ties 0.5. We averaged equally over eligible items for each rater, then over raters and rubric keys. Items without unequal reference scores were ineligible, rather than assigned 0.5. A constant within-item model scores exactly 0.5 when eligible pairs exist. Pair counts are not independent sample sizes; uncertainty resampled items using the original 9,999 draws. Human-human directional pair agreement was averaged as a descriptive reference. This metric assesses ordering, not absolute grading accuracy.

We also decomposed each complete-case item-rater mean normalized squared error into the square of its mean model-rater offset and the mean squared centered residual. Both components were then averaged across raters, items, and rubrics. This is an algebraic description of observed errors, not calibration fitted on evaluation labels or an achievable corrected score. The EXAONE complete-case decomposition excludes unresolved outputs, unlike primary intent-to-score loss.

For first-attempt analysis, we reparsed archived initial outputs without regeneration. Parsing failures remained missing for agreement and received loss 1 for intent-to-score error. Model-specific complete-case QWK estimates therefore need not concern the same response population. We repeated the original 48-hypothesis Holm and descending-size procedure on the common subset with valid initial outputs from all six Qwen and four API systems. Item resampling was unchanged because every item remained represented. This conditional subset analysis does not isolate a causal regeneration effect or estimate an unbiased full-population first-attempt comparison.

### Additional post hoc literal and supervised controls

For constructed-response `content_3`, the official anchors assign scores 1–5 for zero, one, two, three, or at least four keyword groups. We verified these thresholds and within-item keyword consistency. Two fixed literal rules counted either the base expression before parentheses or any base/parenthetical alternative within each group. Commas outside parentheses separated groups; each group counted at most once. After Unicode NFC, case, and whitespace normalization, matching used substrings with whitespace removed. Scores were capped at 5. Both variants were retained without evaluation-based selection or synonym expansion. Short substrings can match spuriously, paraphrases can be missed, and parenthetical forms are not guaranteed synonyms. The original LLM prompt already supplied the same official keyword field and count anchors. Unlike supervised controls, these rules did not use Training score labels; they were specialist implementations for this criterion, not complete eight-criterion scorers.

We fitted two supervised controls per dataset: character TF-IDF plus multioutput ridge regression, and the same features concatenated with item-ID one-hot features. These combine term weighting and penalized linear regression, rather than a new scoring architecture [26,27]. Targets were the means of the two Training raters for eight analytic slots. The previously specified normalized-text overlap exclusions left 32,005 constructed Training records and 16,006 essay Training records. A deterministic hash grouped identical texts into an approximately 80/20 Training fitting/tuning split, with every item represented in both partitions. Vocabulary, IDF, and item encoding were fitted only on fitting data during tuning. Evaluation labels were never arguments to the fitting or selection function.

TF-IDF used character 2–5-grams, minimum document frequency 3, at most 50,000 features, sublinear term frequency, smoothed IDF, L2 normalization, and float64. Ridge used an intercept, equal-item sample weights scaled to mean 1, LSQR tolerance 1e-5, and a 1,000-iteration cap. Penalties 1, 10, and 100 were selected by Training-tuning equal-item normalized loss after fixed clipping to [1,5] and half-up integer rounding; ties favored the larger penalty. Both feature branches were refitted on all eligible Training data, then evaluated once. The implementation used scikit-learn 1.7.2 [28]. No iteration cap was reached.

These controls use same-item labeled data unavailable to zero-shot LLMs. Essay targets share slot-level models across purpose families, rather than explicit semantic rubric conditioning. Bootstrap uncertainty is conditional on fitted Training models, without resampling model fitting. All candidate settings, both feature branches, and all model comparisons were retained. New comparison intervals are exploratory and unadjusted, not additional confirmatory discoveries.

