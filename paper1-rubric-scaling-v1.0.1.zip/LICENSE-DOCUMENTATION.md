# Documentation and aggregate-result license

Original author-owned release documentation, supplementary methods, prompt/configuration descriptions and aggregate research summaries are offered under Creative Commons Attribution 4.0 International (CC BY 4.0), to the extent the author holds the relevant rights. Attribute Taeryeong Kim, the package title and version, link to the license and identify modifications.

License deed: https://creativecommons.org/licenses/by/4.0/
Legal code: https://creativecommons.org/licenses/by/4.0/legalcode.en

This notice does not relicense source AI Hub data, source rubric text, cited publications, third-party code, model weights or any excluded personal/ethics material. The article manuscript and publisher-formatted article are not included in this blanket grant. Python source is separately covered by LICENSE-CODE.txt. No license creates rights in third-party material or supplies an ethics determination.
