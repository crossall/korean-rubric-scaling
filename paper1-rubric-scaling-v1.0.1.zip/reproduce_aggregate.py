"""Replay five tables and two figures from aggregate data; no model inference."""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'replayed'
SIZES = [.6, 1.7, 4, 8, 14, 32]

def read(name):
    return json.loads((ROOT / 'aggregate' / (name + '.json')).read_text('utf-8'))

def fmt(value, places=3):
    if abs(value) < .5 * 10 ** (-places):
        value = 0.
    return f'{value:.{places}f}'.removeprefix('0')

def row(values):
    return '| ' + ' | '.join(str(x) for x in values) + ' |'

def tables():
    criteria = read('criterion_table')
    c, e = read('constructed'), read('essay')
    blocks = [[], [], [], [], []]
    for r in criteria:
        blocks[0].append(row([r['name'], r['focus'], r['jdi'], fmt(r['human_qwk'])]))
        ni = [r[k].replace('qwen3_', '').upper() if r[k] else 'None' for k in ('retained_05', 'retained_03')]
        blocks[1].append(row([r['name'], fmt(r['qwen32_qwk']), fmt(r['api_median']), *ni]))
    for i, label in enumerate(('Constant score 3', 'Training rubric mode', 'Training item mode', 'Training item rounded mean')):
        a, b = c['answer_blind'][i], e['answer_blind'][i]
        blocks[2].append(row([label, fmt(a['mean_qwk']), fmt(a['mean_loss'],4), fmt(b['mean_qwk']), fmt(b['mean_loss'],4)]))
    for i, label in enumerate(('TF-IDF + ridge (supervised)', 'TF-IDF + item ID + ridge (supervised)')):
        a, b = c['text_summary'][i], e['text_summary'][i]
        blocks[2].append(row([label, fmt(a['mean_qwk']), fmt(a['mean_loss'],4), fmt(b['mean_qwk']), fmt(b['mean_loss'],4)]))
    for model, label in [('qwen3_4b','Qwen3 4B'), ('qwen3_32b','Qwen3 32B')]:
        a, b = [next(r for r in d['model_summary'] if r['model']==model) for d in (c,e)]
        blocks[2].append(row([label,fmt(a['equal_rubric_mean_qwk']),fmt(a['mean_loss'],4),fmt(b['equal_rubric_mean_qwk']),fmt(b['mean_loss'],4)]))
    labels = dict(zip(c['models'][:6], ['Qwen3 '+s+'B' for s in ('0.6','1.7','4','8','14','32')]))
    labels.update({'training_item_rounded_mean':'Training item rounded mean','tfidf_ridge':'TF-IDF + ridge','tfidf_item_ridge':'TF-IDF + item ID + ridge'})
    for model,label in labels.items():
        values = [next(r for r in d['within_item']['summary'] if r['model']==model)['within_item_pair_agreement']['estimate'] for d in (c,e)]
        blocks[3].append(row([label,*map(fmt,values)]))
    blocks[3].append(row(['Human-human reference',*[fmt(d['within_item']['human_reference']['mean']['estimate']) for d in (c,e)]]))
    for label,r in zip(('Literal base expressions','Literal base or parenthetical forms'),read('keyword_rules')['summary']):
        blocks[4].append(row([label,fmt(r['qwk'])]))
    for model,label in [('qwen3_32b','Qwen3 32B'),('gemini_3_1_pro','Gemini 3.1 Pro Preview (highest LLM point estimate)')]:
        v=next(r['qwk'] for r in c['cells'] if r['model']==model and r['rubric']=='content_3')
        blocks[4].append(row([label,fmt(v)]))
    blocks[4].append(row(['Human-human reference',fmt(next(r['human_qwk'] for r in c['cells'] if r['rubric']=='content_3'))]))
    expected=(ROOT/'expected/tables.md').read_text('utf-8').strip().split('\n\n')
    if len(expected)!=5:
        raise ValueError('Expected five archived tables')
    replay=[]
    for i,(block,target) in enumerate(zip(blocks,expected),1):
        lines=target.splitlines()
        observed='\n'.join(lines[:2]+block)
        if observed!=target:
            raise ValueError(f'Table {i} does not match the manuscript')
        replay.append(observed)
    (OUT/'tables.md').write_text('\n\n'.join(replay)+'\n',encoding='utf-8')
    return sum(len(b) for b in blocks)

def figures():
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.right':False,'axes.spines.top':False})
    c=read('constructed'); criteria=read('criterion_table'); cells={(r['model'],r['rubric']):r for r in c['cells']}
    fig,axes=plt.subplots(4,2,figsize=(8,10),sharex=True,sharey=True)
    for k,(r,ax) in enumerate(zip(criteria,axes.flat)):
        rs=[cells[m,r['criterion']] for m in c['models'][:6]]
        q=np.array([x['qwk'] for x in rs]);ci=np.array([x['qwk_ci95'] for x in rs])
        refs=[cells[m,r['criterion']]['qwk'] for m in c['models'][6:10]]
        ax.axhspan(min(refs),max(refs),color='#E69F00',alpha=.18)
        ax.axhline(r['human_qwk'],color='#555555',ls='--',lw=1)
        ax.errorbar(SIZES,q,yerr=np.maximum(0,np.stack([q-ci[:,0],ci[:,1]-q])),color='#0072B2',marker='o',markersize=4,capsize=3,lw=1.3)
        ax.set_title(f"{chr(65+k)}  {r['name']}   JDI {r['jdi']}",loc='left',fontsize=10)
        ax.set_xscale('log',base=2);ax.set_xticks(SIZES,['0.6','1.7','4','8','14','32']);ax.set_ylim(-.05,1.03);ax.grid(axis='y',alpha=.15)
        if k%2==0:ax.set_ylabel('Model–human QWK')
        if k>=6:ax.set_xlabel('Qwen3 parameters in billions')
    fig.legend(handles=[Line2D([0],[0],color='#0072B2',marker='o',label='Qwen3 with 95% item-bootstrap intervals'),Line2D([0],[0],color='#555555',ls='--',label='Human–human reference'),Line2D([0],[0],color='#E69F00',lw=7,alpha=.25,label='API min–max range, not a confidence interval')],loc='lower center',bbox_to_anchor=(.5,.005),frameon=False,fontsize=9)
    fig.subplots_adjust(left=.09,right=.99,top=.97,bottom=.13,hspace=.32,wspace=.16)
    savefig(fig,'criterion_scaling')
    fig,axes=plt.subplots(3,2,figsize=(8,9.5)); colors=['#009E73','#D55E00','#7B6BA8'];styles=['--','-.',':']
    for col,family in enumerate(('constructed','essay')):
        d=read(family)['plot']
        for r,ax in enumerate(axes[:,col]):
            p=np.array(d['point'][r]);ci=np.array(d['ci95'][r])
            ax.errorbar(SIZES,p,yerr=np.maximum(0,np.stack([p-ci[:,0],ci[:,1]-p])),color='#0072B2',marker='o',markersize=4,capsize=3,lw=1.3)
            for k,v in enumerate(d['controls'][r]):ax.axhline(v,color=colors[k],ls=styles[k],lw=1.2)
            if r==1:ax.axhline(d['human_pair'],color='#555555',ls='--',lw=1);ax.set_ylim(.46,.85)
            if family=='constructed' and r in (0,2):ax.axhspan(*d['api_range'][str(r)],color='#999999',alpha=.17)
            ax.set_xscale('log',base=2);ax.set_xticks(SIZES,['0.6','1.7','4','8','14','32']);ax.grid(axis='y',alpha=.15)
            ax.set_title(f"{chr(65+r*2+col)}  {['Mean QWK','Within-item pair agreement','Normalized squared loss'][r]}",loc='left',fontsize=10)
            if r==2:ax.set_xlabel('Qwen3 parameters in billions')
        axes[0,col].text(.5,1.25,'Constructed responses' if col==0 else 'Essays',ha='center',transform=axes[0,col].transAxes,fontweight='bold',fontsize=12)
    handles=[Line2D([0],[0],color='#0072B2',marker='o',label='Qwen3 with 95% intervals')]
    handles += [Line2D([0],[0],color=colors[k],ls=styles[k],label=label) for k,label in enumerate(('TF-IDF + ridge','TF-IDF + item ID + ridge','Training item rounded mean'))]
    handles += [Line2D([0],[0],color='#555555',ls='--',label='Human pair agreement'),Line2D([0],[0],color='#999999',lw=7,alpha=.3,label='API min–max, not a CI')]
    fig.legend(handles=handles,loc='lower center',ncol=2,frameon=False,fontsize=9,bbox_to_anchor=(.5,0))
    fig.subplots_adjust(left=.08,right=.98,top=.89,bottom=.15,hspace=.35,wspace=.25)
    savefig(fig,'scaling_and_controls_portrait')

def savefig(fig,name):
    for suffix in ('png','svg'):
        fig.savefig(OUT/(name+'.'+suffix),dpi=220)
    plt.close(fig)

def main():
    OUT.mkdir(exist_ok=True)
    n=tables();figures()
    checks={'tables_exactly_matched':5,'data_rows_checked':n,'figures_replayed':2,'model_calls':0,'record_level_reanalysis':False}
    (OUT/'checks.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(checks))

if __name__=='__main__':main()
