| Criterion | Operational focus | Original JDI | Human QWK |
|---|---|---:|---:|
| Task fulfillment | Fulfillment of task requirements across the response | 2 | .671 |
| Explanatory clarity | Clear focus and explanation | 3 | .618 |
| Explanatory detail | Specific supporting details without undue repetition | 2 | .589 |
| Keyword inclusion | Explicit number of official keyword groups | 0 | .991 |
| Sentence connections | Relations and flow between sentences | 4 | .495 |
| Thematic unity | Whole-response topical unity | 3 | .642 |
| Lexical appropriateness | Contextually appropriate and natural wording | 3 | .479 |
| Grammar and spacing | Formal language correctness and spacing | 1 | .956 |

| Criterion | Qwen 32B QWK | API median QWK | Retained size at .05 | Retained size at .03 |
|---|---:|---:|---|---|
| Task fulfillment | .460 | .455 | 32B | None |
| Explanatory clarity | .387 | .382 | 32B | 32B |
| Explanatory detail | .339 | .349 | 32B | None |
| Keyword inclusion | .524 | .781 | None | None |
| Sentence connections | .183 | .190 | 14B | None |
| Thematic unity | .433 | .411 | 32B | 32B |
| Lexical appropriateness | .178 | .200 | None | None |
| Grammar and spacing | .173 | .294 | None | None |

| Method | Constructed QWK | Constructed loss | Essay QWK | Essay loss |
|---|---:|---:|---:|---:|
| Constant score 3 | .000 | .0776 | .000 | .0563 |
| Training rubric mode | .000 | .0746 | .000 | .0510 |
| Training item mode | .101 | .0694 | .062 | .0496 |
| Training item rounded mean | .122 | .0637 | .077 | .0477 |
| TF-IDF + ridge (supervised) | .418 | .0467 | .175 | .0440 |
| TF-IDF + item ID + ridge (supervised) | .424 | .0464 | .200 | .0435 |
| Qwen3 4B | .273 | .0844 | .219 | .0522 |
| Qwen3 32B | .335 | .0961 | .246 | .0823 |

| Scorer | Constructed pair agreement | Essay pair agreement |
|---|---:|---:|
| Qwen3 0.6B | .501 | .500 |
| Qwen3 1.7B | .585 | .563 |
| Qwen3 4B | .622 | .581 |
| Qwen3 8B | .620 | .593 |
| Qwen3 14B | .632 | .614 |
| Qwen3 32B | .648 | .608 |
| Training item rounded mean | .500 | .500 |
| TF-IDF + ridge | .661 | .555 |
| TF-IDF + item ID + ridge | .662 | .554 |
| Human-human reference | .799 | .738 |

| Method | Keyword-criterion QWK |
|---|---:|
| Literal base expressions | .923 |
| Literal base or parenthetical forms | .943 |
| Qwen3 32B | .524 |
| Gemini 3.1 Pro Preview (highest LLM point estimate) | .896 |
| Human-human reference | .991 |
