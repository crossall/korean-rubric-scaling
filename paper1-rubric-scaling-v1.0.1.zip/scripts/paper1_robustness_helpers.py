"""Shared, local-only helpers for Amendment 015 exploratory experiments."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import sys
import unicodedata
import zipfile

import validate_paper1_and_add_baselines as v
sys.path.insert(0, str(v.ROOT / 'artifacts/paper1_extension_runtime'))
np = v.np
OUT = v.ROOT / 'artifacts/paper1_robustness_20261011'


def normalize(text):
    return ' '.join(unicodedata.normalize('NFC', str(text)).split())


def tuning_fold(text_hash):
    return int(hashlib.sha256(f'20261011|{text_hash}'.encode()).hexdigest()[:16], 16) % 5


def rounded_score(values):
    return np.floor(np.clip(values, 1, 5) + .5).astype(int)


def item_weights(items):
    counts = Counter(items)
    values = np.array([1 / counts[item] for item in items])
    return values / values.mean()


def read_text_records(family, split, exclusion_hashes=None):
    """No texts or original answer IDs are written to outputs."""
    excluded = set(exclusion_hashes or [])
    rows = []
    archives = {}
    skipped = 0
    expected = v.DATASETS[family]['expected'][split]
    scanned = 0
    for path in v.locate_label_zips(v.ROOT, v.DATASETS[family]['root'], split):
        archives[str(path.relative_to(v.ROOT))] = v.sha(path)
        with zipfile.ZipFile(path) as archive:
            for member in sorted(n for n in archive.namelist() if n.lower().endswith('.json')):
                record = v.read_json_member(archive, member)
                scanned += 1
                text = normalize(record['essay_answer']['text'])
                digest = v.normalized_digest(text)
                if digest in excluded:
                    skipped += 1
                    continue
                rows.append({'text': text, 'text_hash': digest,
                             'item': str(record['essay_question']['id']),
                             'humans': v.source_labels(record),
                             'rubric_keys': [record['rubric']['analytic'][c]['rubric_key'] for c in v.CRITERIA]})
    assert scanned == expected
    return rows, {'scanned': scanned, 'retained': len(rows), 'excluded_overlap': skipped,
                  'archive_sha256': archives}


def evaluation_texts(family, manifest):
    texts, keywords, anchors = [], [], []
    archives = {}
    try:
        for pointer in manifest:
            path = v.ROOT / pointer['zip_path']
            if path not in archives:
                archives[path] = zipfile.ZipFile(path)
            record = v.read_json_member(archives[path], pointer['member'])
            text = str(record['essay_answer']['text'])
            assert hashlib.sha256(text.encode()).hexdigest() == pointer['content_sha256']
            texts.append(normalize(text))
            keywords.append(record['essay_question'].get('keyword'))
            anchors.append(record['rubric']['analytic']['content_3'])
    finally:
        for archive in archives.values():
            archive.close()
    return texts, keywords, anchors


def keyword_groups(value):
    """Split top-level commas, preserving parenthetical forms as alternatives."""
    if not isinstance(value, str):
        raise ValueError('Keyword field must be a string')
    depth = 0
    start = 0
    chunks = []
    for i, char in enumerate(value):
        if char == '(':
            depth += 1
        elif char == ')':
            depth -= 1
            if depth < 0:
                raise ValueError('Unbalanced keyword parentheses')
        elif char == ',' and depth == 0:
            chunks.append(value[start:i])
            start = i + 1
    if depth:
        raise ValueError('Unbalanced keyword parentheses')
    chunks.append(value[start:])
    groups = []
    for chunk in chunks:
        chunk = normalize(chunk)
        if not chunk:
            raise ValueError('Empty keyword group')
        base = normalize(chunk.split('(', 1)[0])
        alternatives = [base]
        for inner in re.findall(r'\(([^()]*)\)', chunk):
            alternatives.extend(normalize(x) for x in inner.split(',') if normalize(x))
        assert all(alternatives)
        groups.append(list(dict.fromkeys(alternatives)))
    return groups


def keyword_score(text, groups, include_parenthetical=False):
    compact = ''.join(normalize(text).lower().split())
    matched = sum(any(''.join(term.lower().split()) in compact
                      for term in (group if include_parenthetical else group[:1]))
                  for group in groups)
    return min(5, matched + 1)


def pair_agreement(conf):
    """Tie-half concordance conditional on unequal reference-column scores."""
    numerator = np.zeros(conf.shape[:-2])
    denominator = np.zeros_like(numerator)
    triangle = np.triu(np.ones((5, 5)), k=1) + .5 * np.eye(5)
    for low in range(4):
        for high in range(low + 1, 5):
            cross = conf[..., :, low, None] * conf[..., None, :, high]
            numerator += (cross * triangle).sum(axis=(-2, -1))
            denominator += cross.sum(axis=(-2, -1))
    ratio = np.divide(numerator, denominator, out=np.full_like(numerator, np.nan), where=denominator > 0)
    return ratio, denominator


def paired_item_means(values, weights):
    flat = np.nan_to_num(values).reshape(len(values), -1)
    support = np.isfinite(values).reshape(len(values), -1).astype(float)
    denom = weights @ support
    mean = np.divide(weights @ flat, denom, out=np.full(denom.shape, np.nan), where=denom > 0)
    return mean.reshape(len(weights), *values.shape[1:])


def finite_summary(point, samples):
    """Never drop undefined bootstrap replicates to manufacture an interval."""
    count = int(np.count_nonzero(~np.isfinite(samples)))
    return {'estimate': float(point) if np.isfinite(point) else None,
            'ci95': v.ci(samples) if count == 0 else None,
            'undefined_bootstrap_draws': count}


def score_results(family, names, predictions, indices, humans, keys, key_names, weights):
    conf, hc, loss = v.build_confusions(indices, humans, keys, key_names, predictions)
    values = v.metrics(conf, loss)
    qb, lb = v.bootstrap_from_weights(conf, loss, weights)
    summaries = []
    for m, name in enumerate(names):
        summaries.append({'model': name, 'mean_qwk': float(values['qwk'][m].mean()),
                          'mean_qwk_ci95': v.ci(qb[:, m].mean(axis=1)),
                          'mean_loss': float(values['normalized_squared_loss'][m].mean()),
                          'mean_loss_ci95': v.ci(lb[:, m].mean(axis=1)),
                          'mean_mae': float(values['mae'][m].mean())})
    cells = [{'model': name, 'rubric': key, **{metric: float(array[m, c]) for metric, array in values.items()},
              'qwk_ci95': v.ci(qb[:, m, c]), 'loss_ci95': v.ci(lb[:, m, c])}
             for m, name in enumerate(names) for c, key in enumerate(key_names)]
    return {'family': family, 'models': names, 'summary': summaries, 'cells': cells}, values, qb, lb, conf, hc, loss
