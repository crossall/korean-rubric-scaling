"""Training-only tuning for two conventional text-scoring controls per dataset."""
import argparse
from datetime import datetime, timezone
import gc
import hashlib
import json
import time

import paper1_robustness_helpers as h
v, np = h.v, h.np
import sklearn
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import Ridge
from sklearn.preprocessing import OneHotEncoder
from scipy.sparse import hstack
from threadpoolctl import threadpool_limits

BRANCHES = ['tfidf_ridge', 'tfidf_item_ridge']
ALPHAS = [1., 10., 100.]


def vectorizer():
    return TfidfVectorizer(analyzer='char', ngram_range=(2, 5), min_df=3,
                           max_features=50000, sublinear_tf=True, smooth_idf=True,
                           norm='l2', lowercase=True, dtype=np.float64)


def fit_ridge(x, y, items, alpha):
    model = Ridge(alpha=alpha, solver='lsqr', tol=1e-5, max_iter=1000, fit_intercept=True)
    model.fit(x, y, sample_weight=h.item_weights(items))
    if np.any(model.n_iter_ >= 1000):
        raise RuntimeError('LSQR reached iteration limit; do not silently accept nonconvergence')
    return model


def tuning_loss(prediction, humans, items):
    errors = ((prediction[:, :, None] - humans) ** 2 / 16).mean(axis=(1, 2))
    return float(np.average(errors, weights=h.item_weights(items)))


def fit_text_models(train, eval_texts, eval_items):
    texts = [row['text'] for row in train]
    items = np.array([row['item'] for row in train], dtype=object)
    humans = np.stack([row['humans'] for row in train])
    targets = humans.mean(axis=-1)
    hashes = [row['text_hash'] for row in train]
    tune = np.array([h.tuning_fold(digest) == 0 for digest in hashes])
    assert tune.any() and (~tune).any()
    assert set(np.array(hashes)[tune]).isdisjoint(set(np.array(hashes)[~tune]))
    assert set(eval_items) <= set(items[~tune])
    assert set(items[tune]) == set(items[~tune])
    vector = vectorizer()
    xfit = vector.fit_transform([texts[i] for i in np.flatnonzero(~tune)])
    xtune = vector.transform([texts[i] for i in np.flatnonzero(tune)])
    encoder = OneHotEncoder(handle_unknown='error', sparse_output=True, dtype=np.float64)
    ifit = encoder.fit_transform(items[~tune, None])
    itune = encoder.transform(items[tune, None])
    selected = {}
    details = {'fit_records': int((~tune).sum()), 'tuning_records': int(tune.sum()),
               'fit_items': len(set(items[~tune])), 'tuning_items': len(set(items[tune])),
               'group_overlap': 0, 'fit_features': xfit.shape[1], 'candidates': {},
               'tuning_partition_sha256': hashlib.sha256(''.join(f'{digest}|{int(flag)}\n' for digest, flag in zip(hashes, tune)).encode()).hexdigest()}
    for branch in BRANCHES:
        xf = xfit if branch == 'tfidf_ridge' else hstack([xfit, ifit], format='csr')
        xt = xtune if branch == 'tfidf_ridge' else hstack([xtune, itune], format='csr')
        candidates = []
        for alpha in ALPHAS:
            start = time.perf_counter()
            model = fit_ridge(xf, targets[~tune], items[~tune], alpha)
            prediction = h.rounded_score(model.predict(xt))
            value = tuning_loss(prediction, humans[tune], items[tune])
            candidates.append({'alpha': alpha, 'tuning_loss': value,
                               'iterations': model.n_iter_.tolist(), 'seconds': time.perf_counter() - start})
            print(f'{branch} alpha={alpha:g}: Training tuning loss={value:.6f}', flush=True)
        selected[branch] = min(candidates, key=lambda row: (row['tuning_loss'], -row['alpha']))['alpha']
        details['candidates'][branch] = candidates
    del xfit, xtune, ifit, itune, vector, encoder, xf, xt, model
    gc.collect()
    final_vector = vectorizer()
    xtrain = final_vector.fit_transform(texts)
    xevaluation = final_vector.transform(eval_texts)
    final_encoder = OneHotEncoder(handle_unknown='error', sparse_output=True, dtype=np.float64)
    itraining = final_encoder.fit_transform(items[:, None])
    ievaluation = final_encoder.transform(np.array(eval_items, dtype=object)[:, None])
    predictions = []
    details['selected_alpha'] = selected
    details['full_training_features'] = xtrain.shape[1]
    details['evaluation_all_zero_text_vectors'] = int(np.count_nonzero(xevaluation.getnnz(axis=1) == 0))
    details['final_fits'] = {}
    for branch in BRANCHES:
        xt = xtrain if branch == 'tfidf_ridge' else hstack([xtrain, itraining], format='csr')
        xe = xevaluation if branch == 'tfidf_ridge' else hstack([xevaluation, ievaluation], format='csr')
        start = time.perf_counter()
        model = fit_ridge(xt, targets, items, selected[branch])
        fitted_seconds = time.perf_counter() - start
        start = time.perf_counter()
        predictions.append(h.rounded_score(model.predict(xe)))
        details['final_fits'][branch] = {'fit_seconds': fitted_seconds,
                                       'predict_seconds': time.perf_counter() - start,
                                       'iterations': model.n_iter_.tolist()}
    return np.stack(predictions, axis=1), details


def main():
    h.OUT.mkdir(parents=True, exist_ok=True)
    if (h.OUT / 'text_baseline_manifest.json').exists():
        raise ValueError('Do not overwrite a recorded experiment')
    protected = v.read_json(v.DEFAULT_OUT / 'revision_manifest.json')['products_sha256']
    original = v.read_json(v.DEFAULT_OUT / 'audit_manifest.json')['protected_files']
    protected = {**original, **protected}
    for path, digest in protected.items():
        assert v.sha(v.ROOT / path) == digest
    scripts = ['scripts/paper1_robustness_helpers.py', 'scripts/run_paper1_text_baselines.py',
               'reports/paper1_amendment_015.md']
    v.save(h.OUT / 'text_baseline_manifest.json', {
        'started_at_utc': datetime.now(timezone.utc).isoformat(),
        'status': 'post hoc controls; prior LLM outcomes known; tuning uses Training only',
        'sklearn_version': sklearn.__version__, 'numpy_version': np.__version__,
        'source_sha256': {p: v.sha(v.ROOT / p) for p in scripts}, 'protected_sha256': protected,
        'new_paid_inference_calls': 0, 'external_student_data_transfers': 0})
    with threadpool_limits(limits=2):
        for family in ('constructed', 'essay'):
            start = time.perf_counter()
            evaluation = v.load_evaluation(family)
            manifest, items, indices, humans, keys, training_keys, hashes, _ = evaluation
            texts, _, _ = h.evaluation_texts(family, manifest)
            training, train_meta = h.read_text_records(family, 'Training', hashes)
            expected_exclusions = 1 if family == 'constructed' else 4
            assert train_meta['excluded_overlap'] == expected_exclusions
            assert set(training_keys.ravel()) <= {key for row in training for key in row['rubric_keys']}
            # Evaluation labels are never arguments to the fitting/tuning function.
            predictions, details = fit_text_models(training, texts, [row['item_id'] for row in manifest])
            del training, texts
            gc.collect()
            prior = v.read_json(v.OLD / f'{family}_results.json')
            with np.load(v.OLD / f'{family}_bootstrap.npz') as stream:
                weights = stream['multiplicities']
                old_q = stream['qwk'].copy()
                old_l = stream['loss'].copy()
                old_qb = stream['qwk_boot'].copy()
                old_lb = stream['loss_boot'].copy()
            results, values, qb, lb, *_ = h.score_results(family, BRANCHES, predictions, indices, humans,
                                                        keys, prior['rubric_keys'], weights)
            comparisons = []
            for b, name in enumerate(BRANCHES):
                for m, model in enumerate(prior['models']):
                    comparisons.append({'baseline': name, 'model': model,
                                        'model_minus_baseline_qwk': float((old_q[m] - values['qwk'][b]).mean()),
                                        'qwk_difference_ci95_unadjusted': v.ci((old_qb[:, m] - qb[:, b]).mean(axis=1)),
                                        'model_minus_baseline_loss': float((old_l[m] - values['normalized_squared_loss'][b]).mean()),
                                        'loss_difference_ci95_unadjusted': v.ci((old_lb[:, m] - lb[:, b]).mean(axis=1))})
            results.update({'training': train_meta, 'tuning': details, 'paired_comparisons': comparisons,
                            'total_seconds': time.perf_counter() - start,
                            'scope': 'Supervised within-seen-item controls, not information-matched to zero-shot LLMs; conditional bootstrap, post hoc unadjusted intervals'})
            v.save(h.OUT / f'{family}_text_baselines.json', results)
            np.savez_compressed(h.OUT / f'{family}_text_baselines.npz', predictions=predictions,
                                qwk=values['qwk'], loss=values['normalized_squared_loss'], qwk_boot=qb, loss_boot=lb)
            print(f'{family}: text controls completed in {results["total_seconds"]:.1f}s', flush=True)
    for path, digest in protected.items():
        assert v.sha(v.ROOT / path) == digest
    v.save(h.OUT / 'text_baseline_completion.json', {'finished_at_utc': datetime.now(timezone.utc).isoformat(),
                                                   'protected_files_unchanged': len(protected), 'new_paid_inference_calls': 0})


if __name__ == '__main__':
    main()
