"""Outcome-known reviewer diagnostics, using archived predictions only.

Amendment 016: no new inference, no demographic inference, no source-row export.
"""
from pathlib import Path
import json
import time
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'artifacts/paper1_analysis_runtime'))
sys.path.insert(0, str(ROOT / 'artifacts/paper1_extension_runtime'))
import numpy as np
from threadpoolctl import threadpool_limits
import validate_paper1_and_add_baselines as v
import paper1_robustness_helpers as h
from run_paper1_robustness_diagnostics import first_attempt_predictions

OUT = ROOT / 'artifacts/paper1_review_extensions_20261013'


def human_distributions(conf, keys, counts):
    pooled = conf.sum(axis=0)
    distributions = np.stack([pooled.sum(axis=-1), pooled.sum(axis=-2)], axis=1)
    distributions /= distributions.sum(axis=-1, keepdims=True)
    means = distributions @ np.arange(1, 6)
    return [dict(rubric=key, applicable_items=int(np.count_nonzero(conf[:, c].sum(axis=(-2, -1)))),
                 response_count=int(counts[c]), score_probabilities_h1=distributions[c, 0].tolist(),
                 score_probabilities_h2=distributions[c, 1].tolist(),
                 mean_h1=float(means[c, 0]), mean_h2=float(means[c, 1]),
                 mean_h1_minus_h2=float(means[c, 0]-means[c, 1]),
                 floor_h1=float(distributions[c, 0, 0]), floor_h2=float(distributions[c, 1, 0]),
                 ceiling_h1=float(distributions[c, 0, 4]), ceiling_h2=float(distributions[c, 1, 4]),
                 human_qwk=float(v.qwk(pooled[c]))) for c, key in enumerate(keys)]


def losses_by_rater(indices, humans, keys, key_names, predictions):
    result = np.full((int(indices.max())+1, predictions.shape[1], len(key_names), 2), np.nan)
    lookup = {key: c for c, key in enumerate(key_names)}
    for item in range(len(result)):
        selected = np.flatnonzero(indices == item)
        for slot in range(8):
            c = lookup[keys[selected[0], slot]]
            err = (predictions[selected, :, slot, None] - humans[selected, None, slot, :])**2 / 16
            result[item, :, c] = np.where(np.isfinite(err), err, 1).mean(axis=0)
    return result


def boot_raters(conf, loss, weights):
    moments = v.archived.qwk_moments(conf)
    flat = moments.reshape(len(conf), -1)
    values = np.nan_to_num(loss).reshape(len(conf), -1)
    support = np.isfinite(loss).reshape(len(conf), -1).astype(float)
    qboot = np.empty((len(weights), *conf.shape[1:4]))
    lboot = np.empty_like(qboot)
    for start in range(0, len(weights), 128):
        w = weights[start:start+128]
        qboot[start:start+len(w)] = v.archived.moment_qwk((w @ flat).reshape(len(w), *moments.shape[1:]))
        lboot[start:start+len(w)] = ((w @ values)/(w @ support)).reshape(len(w), *loss.shape[1:])
    assert np.isfinite(qboot).all() and np.isfinite(lboot).all()
    return qboot, lboot


def protocol_rows(family, manifest, names, predictions, first, coverage):
    old = v.read_json(v.OLD / f'{family}_results.json')
    initial = v.read_json(h.OUT / f'{family}_first_attempt.json')
    final_lookup = {r['model']: r for r in old['model_summary']}
    first_lookup = {r['model']: r for r in initial['summary']}
    rows = []
    for m, (name, path) in enumerate(v.archived.paths_for(family).items()):
        regen = both = final_ok = 0
        for line in path.read_text(encoding='utf-8').splitlines():
            raw = json.loads(line)
            if raw.get('repair_used'):
                regen += 1
                final_ok += raw['status'] == 'ok'
                try:
                    v.parse_scores(raw['first_raw_output'])
                    v.parse_scores(raw['raw_output'])
                except (ValueError, TypeError):
                    pass
                else:
                    both += 1
        valid_first = np.isfinite(first[:, m]).all(axis=-1)
        np.testing.assert_array_equal(first[valid_first, m], predictions[valid_first, m])
        assert coverage[m]['first_valid'] == valid_first.sum()
        row = dict(coverage[m])
        row.update(regenerated=regen, regeneration_rate=regen/len(manifest),
                   regenerated_final_valid=final_ok, regenerated_paired_valid_scores=both,
                   first_qwk=first_lookup[name]['mean_qwk'], final_qwk=final_lookup[name]['equal_rubric_mean_qwk'],
                   first_loss=first_lookup[name]['mean_loss'], final_loss=final_lookup[name]['mean_loss'],
                   preserved_on_first_valid_records=True,
                   regeneration_score_shift=None,
                   shift_status='Not identifiable under the frozen parser: the regeneration subset lacks valid initial score vectors' if both == 0 else 'Requires separately defined paired analysis')
        rows.append(row)
    return rows


def main():
    started = time.perf_counter()
    OUT.mkdir(parents=True, exist_ok=True)
    assert not (OUT/'completion.json').exists(), 'Do not overwrite a completed outcome-known analysis'
    source = v.read_json(h.OUT/'diagnostic_manifest.json')
    protected = source['protected_sha256']
    for rel, digest in protected.items():
        assert v.sha(ROOT/rel) == digest, rel
    for p in [ROOT/'reports/Paper1_Author_Provenance_Revision_20261011.docx',
              ROOT/'reports/paper1_manuscript_author_provenance_20261011.md',
              ROOT/'reproducibility/paper1-rubric-scaling-v0.1.0-rc1.zip']:
        protected[str(p.relative_to(ROOT))] = v.sha(p)
    v.save(OUT/'input_manifest.json', dict(review_date='2026-10-13', protected_sha256=protected,
           amendment_sha256=v.sha(ROOT/'reports/paper1_amendment_016.md'),
           analysis_script_sha256=v.sha(__file__), analysis_status='Outcome-known exploratory diagnostics'))
    with threadpool_limits(limits=2):
        for family in ('constructed', 'essay'):
            manifest, items, indices, humans, keys, training_keys, hashes, prompt_hashes = v.load_evaluation(family)
            names, predictions, checks = v.load_predictions(family, manifest, prompt_hashes)
            first, coverage = first_attempt_predictions(family, manifest, names)
            protocol = protocol_rows(family, manifest, names, predictions, first, coverage)
            prior = v.read_json(v.OLD/f'{family}_results.json')
            key_names = prior['rubric_keys']
            with np.load(v.OLD/f'{family}_bootstrap.npz') as z:
                weights = z['multiplicities'].copy()
                archived_qr = z['qwk_by_rater'].copy()
            fitted = v.read_json(v.DEFAULT_OUT/f'{family}_verification.json')['baseline_training']['fitted_rules']
            item_mean = np.array([[fitted[f"{row['item_id']}|{training_keys[i,c]}"]['item_rounded_mean']
                                  for c in range(8)] for i, row in enumerate(manifest)])[:, None, :]
            with np.load(h.OUT/f'{family}_text_baselines.npz') as z:
                text_pred = z['predictions'].copy()
            all_names = names + ['training_item_rounded_mean', 'tfidf_ridge', 'tfidf_item_ridge']
            all_pred = np.concatenate([predictions, item_mean, text_pred], axis=1)
            conf, human_conf, loss = v.build_confusions(indices, humans, keys, key_names, all_pred)
            qpoint = v.qwk(conf.sum(axis=0))
            np.testing.assert_allclose(qpoint[:len(names)], archived_qr, atol=1e-12, rtol=0)
            lr = losses_by_rater(indices, humans, keys, key_names, all_pred)
            np.testing.assert_allclose(np.nanmean(lr.mean(axis=-1), axis=0), np.nanmean(loss, axis=0), atol=1e-14)
            lpoint = np.nanmean(lr, axis=0)
            qb, lb = boot_raters(conf, lr, weights)
            rater_summaries = []
            for m, name in enumerate(all_names):
                rater_summaries.append(dict(model=name, qwk_by_rater=qpoint[m].mean(axis=0).tolist(),
                    qwk_by_rater_ci95=v.ci(qb[:,m].mean(axis=1)), loss_by_rater=lpoint[m].mean(axis=0).tolist(),
                    loss_by_rater_ci95=v.ci(lb[:,m].mean(axis=1))))
            m32, m4 = names.index('qwen3_32b'), names.index('qwen3_4b')
            jdi = v.archived.variants_for(family, key_names)['frozen_v1']
            contrasts = []
            for r in range(2):
                curve = v.archived.curve_analysis(qpoint[:6,:,r], qb[:,:6,:,r], jdi)
                contrasts.append(dict(rater_slot=r+1,
                    qwk_32b_minus_4b=float((qpoint[m32,:,r]-qpoint[m4,:,r]).mean()),
                    qwk_difference_ci95=v.ci((qb[:,m32,:,r]-qb[:,m4,:,r]).mean(axis=-1)),
                    loss_32b_minus_4b=float((lpoint[m32,:,r]-lpoint[m4,:,r]).mean()),
                    loss_difference_ci95=v.ci((lb[:,m32,:,r]-lb[:,m4,:,r]).mean(axis=-1)),
                    exploratory_original_jdi_interaction=curve['scale_by_jdi'],
                    criterion_heterogeneity=curve['scale_by_criterion']))
            grades = np.array([str(row['grade']) for row in manifest])
            grade_rows = []
            for grade in sorted(set(grades)):
                selected = grades == grade
                item_ids = np.unique(indices[selected])
                assert all(np.all(selected[indices==i]) for i in item_ids), 'Item spans grades'
                applicable = human_conf[item_ids].sum(axis=(0,2,3)) > 0
                values = v.metrics(conf[item_ids][:,:,applicable], loss[item_ids][:,:,applicable])
                grade_rows.append(dict(grade=grade, records=int(selected.sum()), items=len(item_ids),
                    applicable_rubrics=int(applicable.sum()), models=[dict(model=name,
                    qwk=float(values['qwk'][m].mean()), loss=float(values['normalized_squared_loss'][m].mean()))
                    for m,name in enumerate(all_names)]))
            data = dict(family=family, records=len(manifest), items=len(items),
                rubric_keys=key_names, human_reference_scope='H1 and H2 are annotation slots; stable named-rater identities, training and adjudication are not established by these calculations',
                human_distributions=human_distributions(human_conf, key_names, [(keys==key).sum() for key in key_names]),
                model_rater_summary=rater_summaries, rater_contrasts=contrasts,
                model_rater_cells=[dict(model=name, rubric=key, qwk_h1=float(qpoint[m,c,0]),qwk_h2=float(qpoint[m,c,1]),
                    loss_h1=float(lpoint[m,c,0]),loss_h2=float(lpoint[m,c,1])) for m,name in enumerate(all_names) for c,key in enumerate(key_names)],
                first_final_protocol=protocol, grade_descriptive=grade_rows,
                grade_scope='Descriptive unadjusted strata; item and rubric composition differ. Not a causal grade effect or a protected-group fairness validation',
                inference_scope='Outcome-known, conditional on fixed criteria and fitted baselines; rater-contrast intervals are unadjusted; no consensus gold created',
                link_and_parse_checks=checks)
            v.save(OUT/f'{family}_review_diagnostics.json', data)
            print(json.dumps(dict(family=family, records=len(manifest), items=len(items),
                  rater_contrasts=contrasts, human_mean_gap_range=[min(r['mean_h1_minus_h2'] for r in data['human_distributions']),max(r['mean_h1_minus_h2'] for r in data['human_distributions'])]),ensure_ascii=False), flush=True)
    for rel,digest in protected.items():
        assert v.sha(ROOT/rel) == digest, rel
    v.save(OUT/'completion.json', dict(review_date='2026-10-13', runtime_seconds=time.perf_counter()-started,
        protected_files_unchanged=len(protected), new_inference_calls=0, new_paid_spend_usd=0,
        outputs_sha256={p.name:v.sha(p) for p in OUT.glob('*_review_diagnostics.json')}))


if __name__ == '__main__':
    main()
