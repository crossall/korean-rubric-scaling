#!/usr/bin/env python3
"""Build deterministic, pointer-only Paper 1 manifests from AI Hub ZIP files.

The manifests deliberately contain no response text, demographic fields, feedback,
or human scores.  Each row points back to the licensed source JSON inside a ZIP.
Development records are selected from Training by response-length quantiles only.
All Validation records form the locked evaluation set.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import sys
import zipfile
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable


DATASETS = {
    "constructed": {
        "root": "25.서술형 글쓰기 평가 데이터",
        "expected": {"Training": 32006, "Validation": 4000},
        "expected_items": 60,
        "dev_per_item": 5,
    },
    "essay": {
        "root": "26.논술형 글쓰기 평가 데이터",
        "expected": {"Training": 16010, "Validation": 2000},
        "expected_items": 89,
        "dev_per_item": 3,
    },
}


def canonical_json(value: Any) -> bytes:
    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def json_members(archive: zipfile.ZipFile) -> Iterable[str]:
    return sorted(
        name for name in archive.namelist() if name.lower().endswith(".json")
    )


def read_json_member(archive: zipfile.ZipFile, member: str) -> dict[str, Any]:
    raw = archive.read(member)
    for encoding in ("utf-8-sig", "utf-8", "cp949"):
        try:
            return json.loads(raw.decode(encoding))
        except (UnicodeDecodeError, json.JSONDecodeError):
            continue
    raise ValueError(f"Could not decode JSON: {archive.filename}!{member}")


def locate_label_zips(workspace: Path, dataset_root: str, split: str) -> list[Path]:
    base = workspace / dataset_root
    candidates = sorted(
        path
        for path in base.glob(f"**/{split}/02.라벨링데이터/*.zip")
        if path.is_file()
    )
    if not candidates:
        raise FileNotFoundError(f"No label ZIPs found below {base} for {split}")
    return candidates


def scan_split(
    workspace: Path, dataset: str, split: str, dataset_root: str
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    seen_ids: set[str] = set()
    for zip_path in locate_label_zips(workspace, dataset_root, split):
        zip_rel = zip_path.relative_to(workspace).as_posix()
        with zipfile.ZipFile(zip_path) as archive:
            for member in json_members(archive):
                record = read_json_member(archive, member)
                question = record["essay_question"]
                answer = record["essay_answer"]
                item_id = str(question["id"])
                answer_id = str(answer["id"])
                text = str(answer.get("text", ""))
                content_sha256 = sha256_bytes(text.encode("utf-8"))
                identity = f"{dataset}|{split}|{item_id}|{answer_id}|{content_sha256}"
                record_id = hashlib.sha256(identity.encode("utf-8")).hexdigest()[:24]
                if record_id in seen_ids:
                    raise ValueError(f"Duplicate record_id: {record_id}")
                seen_ids.add(record_id)
                rows.append(
                    {
                        "record_id": record_id,
                        "dataset": dataset,
                        "source_split": split,
                        "zip_path": zip_rel,
                        "member": member,
                        "item_id": item_id,
                        "answer_id": answer_id,
                        "grade": str(question.get("grade", "")),
                        "subject": str(question.get("subject", "")),
                        "response_chars": len(text),
                        "content_sha256": content_sha256,
                    }
                )
    return sorted(rows, key=lambda row: (row["item_id"], row["record_id"]))


def quantile_representatives(
    rows: list[dict[str, Any]], per_item: int
) -> list[dict[str, Any]]:
    by_item: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        by_item[row["item_id"]].append(row)

    selected: list[dict[str, Any]] = []
    for item_id in sorted(by_item):
        candidates = sorted(
            by_item[item_id], key=lambda row: (row["response_chars"], row["record_id"])
        )
        if len(candidates) < per_item:
            raise ValueError(
                f"Item {item_id} has only {len(candidates)} Training rows; "
                f"cannot select {per_item} quantiles"
            )
        indices = [
            int(math.floor(index * (len(candidates) - 1) / (per_item - 1) + 0.5))
            if per_item > 1
            else len(candidates) // 2
            for index in range(per_item)
        ]
        if len(set(indices)) != len(indices):
            raise AssertionError(f"Non-unique quantile indices for item {item_id}")
        for quantile_index, candidate_index in enumerate(indices):
            row = dict(candidates[candidate_index])
            row["selection"] = "training_length_quantile"
            row["selection_quantile_index"] = quantile_index
            row["selection_quantile_total"] = per_item
            selected.append(row)
    return sorted(selected, key=lambda row: (row["item_id"], row["selection_quantile_index"]))


def median_representatives(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    by_item: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        by_item[row["item_id"]].append(row)
    selected: list[dict[str, Any]] = []
    for item_id in sorted(by_item):
        candidates = sorted(
            by_item[item_id], key=lambda row: (row["response_chars"], row["record_id"])
        )
        row = dict(candidates[(len(candidates) - 1) // 2])
        row["selection"] = "training_length_median"
        selected.append(row)
    return sorted(selected, key=lambda row: row["item_id"])


def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")


def item_counts(rows: list[dict[str, Any]]) -> dict[str, int]:
    return dict(sorted(Counter(row["item_id"] for row in rows).items()))


def build(workspace: Path, output_dir: Path) -> dict[str, Any]:
    manifest_info: dict[str, Any] = {}
    record_sets: dict[str, set[str]] = {}

    for dataset, specification in DATASETS.items():
        train = scan_split(workspace, dataset, "Training", specification["root"])
        evaluation = scan_split(
            workspace, dataset, "Validation", specification["root"]
        )
        expected_train = specification["expected"]["Training"]
        expected_evaluation = specification["expected"]["Validation"]
        if len(train) != expected_train:
            raise ValueError(
                f"{dataset} Training count {len(train)} != expected {expected_train}"
            )
        if len(evaluation) != expected_evaluation:
            raise ValueError(
                f"{dataset} Validation count {len(evaluation)} != expected "
                f"{expected_evaluation}"
            )
        if len(item_counts(evaluation)) != specification["expected_items"]:
            raise ValueError(
                f"{dataset} Validation item count {len(item_counts(evaluation))} != "
                f"expected {specification['expected_items']}"
            )

        development = quantile_representatives(train, specification["dev_per_item"])
        smoke = median_representatives(train)
        for name, rows in (
            ("development", development),
            ("smoke", smoke),
            ("evaluation", evaluation),
        ):
            filename = f"{dataset}_{name}_v1.jsonl"
            path = output_dir / filename
            write_jsonl(path, rows)
            key = f"{dataset}_{name}"
            record_sets[key] = {row["record_id"] for row in rows}
            manifest_info[key] = {
                "path": path.relative_to(workspace).as_posix(),
                "sha256": sha256_file(path),
                "records": len(rows),
                "items": len(item_counts(rows)),
                "item_counts": item_counts(rows),
                "source_split": rows[0]["source_split"] if rows else None,
            }

        if record_sets[f"{dataset}_development"] & record_sets[f"{dataset}_evaluation"]:
            raise AssertionError(f"{dataset}: development/evaluation record overlap")
        if record_sets[f"{dataset}_smoke"] & record_sets[f"{dataset}_evaluation"]:
            raise AssertionError(f"{dataset}: smoke/evaluation record overlap")

    summary = {
        "schema_version": 1,
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "selection_seed": None,
        "selection_rule": (
            "Training-only deterministic response-length quantiles within item; "
            "all Validation responses are locked evaluation records."
        ),
        "privacy": (
            "Pointer-only manifests: no response text, demographic fields, feedback, "
            "or human scores are copied."
        ),
        "manifests": manifest_info,
    }
    summary_path = output_dir / "manifest_summary_v1.json"
    summary_path.write_bytes(canonical_json(summary) + b"\n")
    summary["summary_path"] = summary_path.relative_to(workspace).as_posix()
    summary["summary_sha256"] = sha256_file(summary_path)
    return summary


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--workspace",
        type=Path,
        default=Path(__file__).resolve().parents[1],
        help="Workspace root (default: parent of scripts directory)",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=None,
        help="Output directory (default: WORKSPACE/artifacts/manifests)",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    workspace = args.workspace.resolve()
    output_dir = (
        args.output_dir.resolve()
        if args.output_dir
        else workspace / "artifacts" / "manifests"
    )
    try:
        summary = build(workspace, output_dir)
    except Exception as exc:  # concise CLI failure without source-record leakage
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1
    for name, info in summary["manifests"].items():
        print(
            f"{name}: records={info['records']} items={info['items']} "
            f"sha256={info['sha256']}"
        )
    print(f"summary_sha256={summary['summary_sha256']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
