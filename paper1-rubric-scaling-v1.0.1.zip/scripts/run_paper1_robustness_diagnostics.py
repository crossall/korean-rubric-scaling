"""Within-item, first-attempt, and literal-rule diagnostics; no inference calls."""
from datetime import datetime, timezone
import json
import time
from pathlib import Path

import paper1_robustness_helpers as h
v, np = h.v, h.np
from threadpoolctl import threadpool_limits


def error_components(indices, humans, keys, key_names, predictions):
    shape = (int(indices.max())+1, predictions.shape[1], len(key_names))
    bias = np.full(shape, np.nan)
    centered = np.full(shape, np.nan)
    counts = np.zeros(shape, dtype=int)
    lookup = {key: c for c, key in enumerate(key_names)}
    for item in range(shape[0]):
        selected = np.flatnonzero(indices == item)
        for slot in range(8):
            assert len(set(keys[selected, slot])) == 1
            c = lookup[keys[selected[0], slot]]
            for m in range(shape[1]):
                p = predictions[selected, m, slot]
                valid = np.isfinite(p)
                counts[item, m, c] = valid.sum()
                if valid.any():
                    errors = (p[valid, None]-humans[selected[valid], slot])/4
                    bias[item, m, c] = (errors.mean(axis=0)**2).mean()
                    centered[item, m, c] = ((errors-errors.mean(axis=0))**2).mean()
                    assert np.isclose(bias[item, m, c]+centered[item, m, c], (errors**2).mean())
    return bias, centered, counts


def discrimination(family, names, predictions, indices, humans, keys, key_names, weights):
    conf, human_conf, _ = v.build_confusions(indices, humans, keys, key_names, predictions)
    pair, denom = h.pair_agreement(conf)
    point = h.paired_item_means(pair, np.ones((1, len(conf))))[0].mean(axis=-1)
    boot = h.paired_item_means(pair, weights).mean(axis=-1)
    # Reference columns identify the rater whose unequal scores define eligibility.
    human_pair = np.stack([h.pair_agreement(human_conf.swapaxes(-1, -2))[0],
                           h.pair_agreement(human_conf)[0]], axis=-1)
    human_point = h.paired_item_means(human_pair, np.ones((1, len(conf))))[0].mean(axis=-1)
    human_boot = h.paired_item_means(human_pair, weights).mean(axis=-1)
    bias, centered, counts = error_components(indices, humans, keys, key_names, predictions)
    bpoint = np.nanmean(bias, axis=0).mean(axis=-1)
    cpoint = np.nanmean(centered, axis=0).mean(axis=-1)
    bboot = h.paired_item_means(bias, weights).mean(axis=-1)
    cboot = h.paired_item_means(centered, weights).mean(axis=-1)
    pair_counts = np.rint(denom * counts[..., None]**2).astype(np.int64)
    summaries = []
    cells = []
    for m, name in enumerate(names):
        summaries.append({'model': name, 'within_item_pair_agreement': h.finite_summary(point[m].mean(), boot[:, m].mean(axis=-1)),
                          'mean_offset_loss_component': h.finite_summary(bpoint[m], bboot[:, m]),
                          'centered_loss_component': h.finite_summary(cpoint[m], cboot[:, m]),
                          'complete_case_loss': float(bpoint[m]+cpoint[m]),
                          'missing_response_criterion_predictions': int((~np.isfinite(predictions[:, m])).sum()),
                          'eligible_pairs_summed_across_two_raters_and_criteria': int(pair_counts[:, m].sum())})
        for c, key in enumerate(key_names):
            cells.append({'model': name, 'rubric': key, 'pair_agreement': h.finite_summary(point[m, c], boot[:, m, c]),
                          'eligible_items_by_rater': np.isfinite(pair[:, m, c]).sum(axis=0).tolist(),
                          'eligible_pairs_by_rater': pair_counts[:, m, c].sum(axis=0).tolist()})
    human = {'mean': h.finite_summary(human_point.mean(), human_boot.mean(axis=-1)),
             'cells': [{'rubric': key, 'pair_agreement': h.finite_summary(human_point[c], human_boot[:, c]),
                        'eligible_items_by_reference_rater': np.isfinite(human_pair[:, c]).sum(axis=0).tolist()}
                       for c, key in enumerate(key_names)]}
    result = {'family': family, 'models': names, 'summary': summaries, 'cells': cells, 'human_reference': human,
              'scope': 'Post hoc; pairs dependent within items; equal applicable-item, then rater, then rubric means; complete-case algebraic error decomposition, not fitted calibration'}
    v.save(h.OUT / f'{family}_within_item.json', result)
    np.savez_compressed(h.OUT / f'{family}_within_item.npz', pair_agreement=point, pair_boot=boot,
                        human_pair_agreement=human_point, human_pair_boot=human_boot,
                        offset_loss=bpoint, centered_loss=cpoint)


def first_attempt_predictions(family, manifest, names):
    lookup = {row['record_id']: i for i, row in enumerate(manifest)}
    predictions = np.full((len(manifest), len(names), 8), np.nan)
    coverage = []
    for m, (name, path) in enumerate(v.archived.paths_for(family).items()):
        assert name == names[m]
        initial_history, final_valid, first_valid = 0, 0, 0
        seen = set()
        for line in path.read_text(encoding='utf-8').splitlines():
            row = json.loads(line)
            rid = row['record_id']
            assert rid in lookup and rid not in seen
            seen.add(rid)
            first = row.get('first_raw_output')
            if row.get('repair_used'):
                assert first is not None, 'Missing pre-regeneration history'
            if first is not None:
                initial_history += 1
            else:
                first = row.get('raw_output')
            final_valid += row['status'] == 'ok'
            try:
                scores = v.parse_scores(first)
            except (ValueError, TypeError):
                continue
            first_valid += 1
            predictions[lookup[rid], m] = [scores[key] for key in v.CRITERIA]
        assert seen == set(lookup)
        coverage.append({'model': name, 'records': len(manifest), 'first_valid': first_valid,
                         'final_valid': final_valid, 'separate_first_raw_output_records': initial_history,
                         'first_parse_rate': first_valid/len(manifest)})
    return predictions, coverage


def first_attempt_analysis(family, manifest, names, final_predictions, indices, humans, keys, key_names, weights):
    predictions, coverage = first_attempt_predictions(family, manifest, names)
    unchanged = np.isfinite(predictions).all(axis=-1)
    np.testing.assert_array_equal(predictions[unchanged], final_predictions[unchanged])
    result, _, qb, lb, *_ = h.score_results(family, names, predictions, indices, humans, keys, key_names, weights)
    result.update({'coverage': coverage,
                   'scope': 'First-attempt complete-case QWK; different models can have different populations. Failed attempts receive loss 1.'})
    if family == 'constructed':
        selected = np.isfinite(predictions[:, :10]).all(axis=(1, 2))
        kept_items, remapped = np.unique(indices[selected], return_inverse=True)
        assert len(kept_items) == len(np.unique(indices)), 'Changed item population needs a documented amendment'
        common, common_values, common_qb, common_lb, *_ = h.score_results(
            family, names[:10], predictions[selected, :10], remapped, humans[selected], keys[selected], key_names, weights)
        common.update({'records': int(selected.sum()), 'items': len(kept_items),
                       'minimum_records_per_item': int(np.bincount(remapped).min()),
                       'maximum_records_per_item': int(np.bincount(remapped).max()),
                       'noninferiority': v.archived.ni_with_full_holm(common_values['qwk'], common_qb),
                       'scope': 'Conditional on all ten Qwen/reference pipelines parsing on first attempt; selection may be nonrandom; not a corrected full-population estimate'})
        result['common_qwen_frontier_subset'] = common
        np.savez_compressed(h.OUT / 'constructed_first_common.npz', qwk=common_values['qwk'],
                            loss=common_values['normalized_squared_loss'], qwk_boot=common_qb, loss_boot=common_lb)
    v.save(h.OUT / f'{family}_first_attempt.json', result)


def keyword_analysis(manifest, indices, humans, prior, original_boot):
    texts, raw_keywords, anchors = h.evaluation_texts('constructed', manifest)
    predictions = np.zeros((len(texts), 2), dtype=int)
    item_rules = {}
    for i, (text, raw, anchor) in enumerate(zip(texts, raw_keywords, anchors)):
        expected = {5: '핵심어4개이상', 4: '핵심어3개', 3: '핵심어2개', 2: '핵심어1개', 1: '핵심어없음'}
        for score, phrase in expected.items():
            assert phrase in ''.join(anchor[f'evaluation_{score}'].split())
        groups = h.keyword_groups(raw)
        item = manifest[i]['item_id']
        if item in item_rules:
            assert item_rules[item]['groups'] == groups
        item_rules[item] = {'groups': groups, 'number_of_groups': len(groups), 'rubric_key': anchor['rubric_key']}
        predictions[i] = [h.keyword_score(text, groups, False), h.keyword_score(text, groups, True)]
    names = ['literal_base_keywords', 'literal_with_parenthetical_forms']
    conf = np.zeros((len(item_rules), 2, 1, 2, 5, 5))
    loss = np.empty((len(item_rules), 2, 1))
    c = list(v.CRITERIA).index('content_3')
    for item in range(len(item_rules)):
        selected = indices == item
        human = humans[selected, c]
        for m in range(2):
            p = predictions[selected, m]
            for r in range(2):
                conf[item, m, 0, r] = np.bincount((p-1)*5+human[:, r]-1, minlength=25).reshape(5, 5)/len(p)
            loss[item, m, 0] = ((p[:, None]-human)**2/16).mean()
    values = v.metrics(conf, loss)
    qb, lb = v.bootstrap_from_weights(conf, loss, original_boot['multiplicities'])
    summaries = [{'model': name, **{metric: float(array[m, 0]) for metric, array in values.items()},
                  'qwk_ci95': v.ci(qb[:, m, 0]), 'loss_ci95': v.ci(lb[:, m, 0])}
                 for m, name in enumerate(names)]
    comparisons = []
    for b, name in enumerate(names):
        for m, model in enumerate(prior['models']):
            comparisons.append({'rule': name, 'model': model,
                                'model_qwk': float(original_boot['qwk'][m, c]),
                                'model_minus_rule_qwk': float(original_boot['qwk'][m, c]-values['qwk'][b, 0]),
                                'qwk_difference_ci95_unadjusted': v.ci(original_boot['qwk_boot'][:, m, c]-qb[:, b, 0]),
                                'model_minus_rule_loss': float(original_boot['loss'][m, c]-values['normalized_squared_loss'][b, 0]),
                                'loss_difference_ci95_unadjusted': v.ci(original_boot['loss_boot'][:, m, c]-lb[:, b, 0])})
    v.save(h.OUT / 'constructed_keyword_rules.json', {
        'criterion': 'content_3', 'records': len(texts), 'items': len(item_rules),
        'summary': summaries, 'paired_comparisons': comparisons,
        'human_qwk': float(original_boot['human'][c]), 'human_qwk_ci95': v.ci(original_boot['human_boot'][:, c]),
        'item_group_counts': {item: rule['number_of_groups'] for item, rule in item_rules.items()},
        'scope': 'Both fixed literal variants; parenthetical forms are not guaranteed semantic synonyms; substring matches can be false positives, paraphrases can be missed'})
    np.savez_compressed(h.OUT / 'constructed_keyword_rules.npz', predictions=predictions,
                        qwk=values['qwk'], loss=values['normalized_squared_loss'], qwk_boot=qb, loss_boot=lb)


def main():
    start = time.perf_counter()
    assert (h.OUT / 'text_baseline_completion.json').exists(), 'Finish the fitted text controls first'
    destination = h.OUT / 'diagnostic_manifest.json'
    assert not destination.exists(), 'Do not overwrite a recorded experiment'
    source_manifest = v.read_json(h.OUT / 'text_baseline_manifest.json')
    protected = source_manifest['protected_sha256']
    for path, digest in {**protected, **source_manifest['source_sha256']}.items():
        assert v.sha(v.ROOT / path) == digest
    inputs = [h.OUT / f'{family}_text_baselines{ext}' for family in ('constructed', 'essay') for ext in ('.json', '.npz')]
    v.save(destination, {'started_at_utc': datetime.now(timezone.utc).isoformat(),
                         'source_sha256': {str(Path(__file__).relative_to(v.ROOT)): v.sha(__file__),
                                           **source_manifest['source_sha256']},
                         'text_control_sha256': {str(p.relative_to(v.ROOT)): v.sha(p) for p in inputs},
                         'protected_sha256': protected, 'new_paid_inference_calls': 0})
    with threadpool_limits(limits=2):
        for family in ('constructed', 'essay'):
            manifest, items, indices, humans, keys, training_keys, hashes, prompt_hashes = v.load_evaluation(family)
            names, predictions, checks = v.load_predictions(family, manifest, prompt_hashes)
            prior = v.read_json(v.OLD / f'{family}_results.json')
            with np.load(v.OLD / f'{family}_bootstrap.npz') as stream:
                boot = {k: stream[k] for k in stream.files}
            weights = boot['multiplicities']
            key_names = prior['rubric_keys']
            baseline = v.read_json(v.DEFAULT_OUT / f'{family}_verification.json')['baseline_training']['fitted_rules']
            item_mean = np.array([[baseline[f"{row['item_id']}|{training_keys[i, c]}"]['item_rounded_mean']
                                   for c in range(8)] for i, row in enumerate(manifest)])[:, None, :]
            with np.load(h.OUT / f'{family}_text_baselines.npz') as stream:
                text_predictions = stream['predictions'].copy()
            all_names = names + ['training_item_rounded_mean', 'tfidf_ridge', 'tfidf_item_ridge']
            all_predictions = np.concatenate([predictions, item_mean, text_predictions], axis=1)
            discrimination(family, all_names, all_predictions, indices, humans, keys, key_names, weights)
            print(f'{family}: within-item discrimination completed', flush=True)
            first_attempt_analysis(family, manifest, names, predictions, indices, humans, keys, key_names, weights)
            print(f'{family}: first-attempt diagnostics completed', flush=True)
            if family == 'constructed':
                keyword_analysis(manifest, indices, humans, prior, boot)
                print('constructed: keyword-rule controls completed', flush=True)
    for path, digest in protected.items():
        assert v.sha(v.ROOT / path) == digest
    v.save(h.OUT / 'diagnostic_completion.json', {'finished_at_utc': datetime.now(timezone.utc).isoformat(),
                                                'runtime_seconds': time.perf_counter()-start,
                                                'protected_files_unchanged': len(protected), 'new_paid_inference_calls': 0})


if __name__ == '__main__':
    main()
