"""Local outcome analysis with explicitly unresolved AI-assisted expert provenance.

Never asserts that the original independent-expert gate was satisfied.  Preserves
frozen inputs and writes a separate pre-unblinding manifest and analysis outputs.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
import time
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'artifacts/paper1_analysis_runtime'))

import numpy as np
import scipy
from scipy.stats import chi2

import analyze_paper1_primary as original
from analyze_paper1_extensions import build_essay_item_confusions, holm_adjust, noninferiority
from paper1_prompting import CRITERIA, human_scores, read_manifest

OUT = ROOT/'artifacts/paper1_analysis_20261011'
REMOTE = ROOT/'artifacts/runpod_downloads/extracted_20260903/artifacts/predictions'
QWEN = ['qwen3_0_6b','qwen3_1_7b','qwen3_4b','qwen3_8b','qwen3_14b','qwen3_32b']
PARAMETERS = np.array([.6,1.7,4,8,14,32])
FRONTIER = ['hcx_007','gpt_5_6_sol','claude_sonnet_5','gemini_3_1_pro']
KOREAN = ['exaone4_1_2b','kanana2_1_3b','hcx_seed_1_5b','midm2_mini_2_3b']
KPARAMETERS = np.array([1.2,1.3,1.5,2.3])
REPETITIONS = 9999
SEED = 20260903


def utc():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, data):
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')


def qwk_moments(conf):
    grid = np.arange(1,6,dtype=float)
    x = grid[:,None]
    y = grid[None,:]
    return np.stack([conf.sum(axis=(-2,-1)),
                     (conf*(x-y)**2).sum(axis=(-2,-1)),
                     (conf*x).sum(axis=(-2,-1)), (conf*y).sum(axis=(-2,-1)),
                     (conf*x*x).sum(axis=(-2,-1)),(conf*y*y).sum(axis=(-2,-1))],axis=-1)


def moment_qwk(moment):
    total, squared_error, sum_x, sum_y, sum_x2, sum_y2 = np.moveaxis(moment,-1,0)
    with np.errstate(divide='ignore',invalid='ignore'):
        expected = sum_x2 + sum_y2 - 2*sum_x*sum_y/total
        result = 1-squared_error/expected
    return np.where((total>0)&(expected>1e-12),result,np.nan)


def bootstrap(conf, human_conf, item_loss, repetitions, seed):
    items = len(conf)
    multiplicities = np.random.default_rng(seed).multinomial(items,np.full(items,1/items),size=repetitions)
    moments = qwk_moments(conf)
    human_moments = qwk_moments(human_conf)
    observed_by_rater = moment_qwk(moments.sum(axis=0))
    observed_human = moment_qwk(human_moments.sum(axis=0))
    observed_loss = np.nanmean(item_loss,axis=0)
    samples = np.empty((repetitions,*observed_by_rater.shape[:-1]))
    human_samples = np.empty((repetitions,*observed_human.shape))
    loss_samples = np.empty((repetitions,*observed_loss.shape))
    flat_moments = moments.reshape(items,-1)
    flat_human = human_moments.reshape(items,-1)
    flat_loss = np.nan_to_num(item_loss).reshape(items,-1)
    flat_support = np.isfinite(item_loss).reshape(items,-1).astype(float)
    for start in range(0,repetitions,256):
        stop = min(start+256,repetitions)
        weights = multiplicities[start:stop]
        sums = (weights@flat_moments).reshape(stop-start,*moments.shape[1:])
        samples[start:stop] = moment_qwk(sums).mean(axis=-1)
        human_sums = (weights@flat_human).reshape(stop-start,*human_moments.shape[1:])
        human_samples[start:stop] = moment_qwk(human_sums)
        loss_samples[start:stop] = ((weights@flat_loss)/(weights@flat_support)).reshape(stop-start,*observed_loss.shape)
    assert np.isfinite(samples).all(), 'Undefined bootstrap model-human QWK; no draws silently discarded'
    assert np.isfinite(human_samples).all(), 'Undefined bootstrap human QWK'
    assert np.isfinite(loss_samples).all()
    return {'qwk':observed_by_rater.mean(axis=-1),'qwk_by_rater':observed_by_rater,
            'human':observed_human,'loss':observed_loss,
            'qwk_boot':samples,'human_boot':human_samples,'loss_boot':loss_samples,
            'multiplicities':multiplicities}


def interval(samples):
    return np.percentile(samples,[2.5,97.5],axis=0).T.tolist()


def wald_test(point, samples):
    covariance = np.atleast_2d(np.cov(samples,rowvar=False,ddof=1))
    rank = int(np.linalg.matrix_rank(covariance))
    df = len(point)
    statistic = float(point@np.linalg.pinv(covariance)@point)
    p = float(chi2.sf(statistic,df)) if rank == df else None
    return {'wald':statistic,'df':df,'covariance_rank':rank,'p':p,
            'supported':p is not None and p<.05}


def curve_analysis(cells, samples, jdi, negative=False):
    directional, omnibus, scale, scale_z = original.design_matrices(PARAMETERS,np.array(jdi,dtype=float))
    dp = np.linalg.pinv(directional)
    op = np.linalg.pinv(omnibus)
    estimate = dp@cells.reshape(-1)
    betas = samples.reshape(len(samples),-1)@dp.T
    ncriteria = cells.shape[1]
    slopes = (op@cells.reshape(-1))[ncriteria:]
    boot_slopes = (samples.reshape(len(samples),-1)@op.T)[:,ncriteria:]
    contrasts = slopes[1:]-slopes[0]
    boot_contrasts = boot_slopes[:,1:]-boot_slopes[:,[0]]
    omnibus_result = wald_test(contrasts,boot_contrasts)
    tail = betas[:,-1]
    lower = float(np.percentile(tail,5))
    upper = float(np.percentile(tail,95))
    p = float((np.count_nonzero(tail>=0 if negative else tail<=0)+1)/(len(tail)+1))
    supported = bool(estimate[-1]<0 and upper<0 and p<.05) if negative else bool(estimate[-1]>0 and lower>0 and p<.05)
    return {'scale_by_criterion':omnibus_result,
            'scale_by_jdi':{'estimate':float(estimate[-1]),'ci95_two_sided':interval(tail),
                            'one_sided_95_lower':lower,'one_sided_95_upper':upper,
                            'one_sided_p':p,'alternative':'negative' if negative else 'positive',
                            'numerical_rule_supported':supported},
            'mean_scale_slope_per_sd':float(estimate[-2]),
            'mean_scale_slope_ci95':interval(betas[:,-2]),
            'criterion_slopes_per_sd':slopes.tolist(),
            'criterion_slopes_per_doubling':(slopes/scale.std()).tolist(),
            'criterion_slopes_ci95':interval(boot_slopes),
            'conjunctive_numerical_rule_supported':bool(omnibus_result['supported'] and supported),
            'protocol_compliant_confirmatory_claim':False}


def saturated_interaction(cells, samples):
    """Size by criterion difference-in-differences, without linear scale."""
    contrasts = cells[1:,1:]-cells[1:,[0]]-cells[[0],1:]+cells[0,0]
    boot_contrasts = samples[:,1:,1:]-samples[:,1:,[0]]-samples[:,[0],1:]+samples[:,0,0,None,None]
    result = wald_test(contrasts.reshape(-1),boot_contrasts.reshape(len(samples),-1))
    result['scope'] = 'prespecified secondary saturated size-by-criterion heterogeneity; not the primary linear-scale test'
    return result


def ni_with_full_holm(observed, samples):
    # Original implementation is retained as a labeled descriptive comparator.
    planned = noninferiority(observed,samples,QWEN,FRONTIER,list(CRITERIA),len(samples))
    reference = np.median(observed[6:10],axis=0)
    reference_boot = np.median(samples[:,6:10],axis=1)
    delta = observed[:6]-reference
    delta_boot = samples[:,:6]-reference_boot[:,None,:]
    out = {'planned_selected_boundary_procedure_descriptive':planned,'all_48_holm':{}}
    for margin in (.05,.03):
        pvals = {(m,c):float((np.count_nonzero(delta_boot[:,m,c]<=-margin)+1)/(len(samples)+1)) for m in range(6) for c in range(8)}
        adjusted = holm_adjust(pvals)
        criteria = {}
        for c,criterion in enumerate(CRITERIA):
            active = True
            minimum = None
            sizes = {}
            for m in reversed(range(6)):
                low = float(np.percentile(delta_boot[:,m,c],5))
                passed = bool(delta[m,c]>-margin and low>-margin and adjusted[m,c]<.05)
                reached = bool(active and passed)
                if reached:
                    minimum = QWEN[m]
                else:
                    active = False
                sizes[QWEN[m]] = {'delta':float(delta[m,c]),'nominal_one_sided_95_lower':low,
                                   'raw_p':pvals[m,c],'holm_48_p':adjusted[m,c],
                                   'pass_holm':passed,'descending_sequence_pass':reached}
            criteria[criterion] = {'minimum_sufficient':minimum,'sizes':sizes}
        out['all_48_holm'][str(margin)] = criteria
    return out


def residual_analysis(cells, samples, variants):
    xq = np.column_stack([np.ones(6),np.log2(PARAMETERS)])
    xk = np.column_stack([np.ones(4),np.log2(KPARAMETERS)])
    interpolation = xk@np.linalg.pinv(xq)
    expected = interpolation@cells[:6]
    residual = cells[10:14]-expected
    boot_residual = samples[:,10:14]-np.einsum('kq,bqc->bkc',interpolation,samples[:,:6])
    radius = float(np.percentile(np.max(np.abs(boot_residual-residual),axis=(1,2)),95))
    mean = residual.mean(axis=1)
    mean_boot = boot_residual.mean(axis=2)
    mean_radius = float(np.percentile(np.max(np.abs(mean_boot-mean),axis=1),95))
    output = {'simultaneous_cell_radius':radius,'simultaneous_mean_radius':mean_radius,'models':{},'jdi_associations':{}}
    for k,model in enumerate(KOREAN):
        output['models'][model] = {'mean_residual':float(mean[k]),'mean_ci95':interval(mean_boot[:,k]),
                                   'mean_simultaneous_ci95':[float(mean[k]-mean_radius),float(mean[k]+mean_radius)],
                                   'criterion_residuals':residual[k].tolist(),'criterion_ci95':interval(boot_residual[:,k]),
                                   'criterion_simultaneous_ci95':np.column_stack([residual[k]-radius,residual[k]+radius]).tolist()}
    for label,jdi in variants.items():
        reg = np.linalg.pinv(np.column_stack([np.ones(len(jdi)),jdi]))[1]
        slopes = residual@reg
        bs = boot_residual@reg
        sr = float(np.percentile(np.max(np.abs(bs-slopes),axis=1),95))
        output['jdi_associations'][label] = {'slopes':slopes.tolist(),'ci95':interval(bs),
                                           'simultaneous_ci95':np.column_stack([slopes-sr,slopes+sr]).tolist()}
    return output


def paths_for(family):
    models = QWEN + (FRONTIER+KOREAN if family == 'constructed' else [])
    return {model:(ROOT/'artifacts/predictions' if model in FRONTIER else REMOTE)/f'{model}_{family}_evaluation.jsonl' for model in models}


def variants_for(family,keys):
    config_path = ROOT/'configs'/('paper1_rubric_judgment_demand_v1.json' if family=='constructed' else 'paper1_essay_rubric_judgment_demand_v1.json')
    cfg = json.loads(config_path.read_text(encoding='utf-8'))
    entries = cfg['criteria' if family=='constructed' else 'rubrics']
    field = 'criterion' if family=='constructed' else 'rubric_key'
    base = {row[field]:row['judgment_demand_index'] for row in entries}
    candidate = json.loads((ROOT/'artifacts/paper1_expert_returns_20261011/assisted_review/majority_candidate.json').read_text(encoding='utf-8'))
    candidates = {row[field]:row for row in candidate['rubrics'] if row['family']==family}
    return {'frozen_v1':[base[key] for key in keys],
            'assisted_majority':[candidates[key]['majority_jdi'] for key in keys],
            **{submission:[candidates[key]['jdi_by_submission'][submission] for key in keys] for submission in ('S01','S02','S03')}}


def freeze():
    OUT.mkdir(parents=True,exist_ok=True)
    path = OUT/'preunblinding_freeze.json'
    if path.exists():
        previous = json.loads(path.read_text(encoding='utf-8'))
        assert previous['script_sha256'] == sha(Path(__file__)), 'Analysis code changed after freeze; document a new version explicitly'
        for name,digest in previous['inputs'].items():
            assert sha(ROOT/name)==digest, f'Frozen input changed: {name}'
        return previous
    needed = [ROOT/'reports/paper1_amendment_013.md',ROOT/'reports/paper1_confirmatory_protocol_v1.md',
              ROOT/'configs/paper1_rubric_judgment_demand_v1.json',ROOT/'configs/paper1_essay_rubric_judgment_demand_v1.json',
              ROOT/'configs/paper1_experiment_v1.json',
              ROOT/'artifacts/paper1_expert_returns_20261011/assisted_review/majority_candidate.json',
              ROOT/'artifacts/paper1_expert_returns_20261011/assisted_review/provenance_update.json',
              ROOT/'scripts/analyze_paper1_primary.py',ROOT/'scripts/analyze_paper1_extensions.py',ROOT/'scripts/paper1_prompting.py']
    for family in ('constructed','essay'):
        needed.append(ROOT/f'artifacts/manifests/{family}_evaluation_v1.jsonl')
        needed.extend(paths_for(family).values())
        needed.extend(Path(str(p)+'.meta.json') for p in paths_for(family).values() if Path(str(p)+'.meta.json').exists())
        needed.extend(ROOT/p['zip_path'] for p in read_manifest(ROOT/f'artifacts/manifests/{family}_evaluation_v1.jsonl'))
    needed.extend((ROOT/'artifacts/paper1_expert_returns_20261011/originals').glob('*.docx'))
    needed = sorted(set(needed))
    result = {'frozen_at_utc':utc(),'before_first_model_outcome_read_in_this_run':True,
              'expert_final_adoption_confirmed':False,'original_independent_expert_gate_satisfied':False,
              'authorization':'User instructed proceeding with these AI-assisted reviewed forms and renewed instruction to complete checks and proceed.',
              'claim_status':'protocol-deviating qualified analysis; not fully protocol-compliant confirmation',
              'script_sha256':sha(Path(__file__)),'inputs':{str(path.relative_to(ROOT)):sha(path) for path in needed},
              'bootstrap_repetitions':REPETITIONS,'constructed_seed':SEED,'essay_seed':SEED+10,
              'runtime':{'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__},
              'jdi_variants':['frozen_v1','assisted_majority','S01','S02','S03']}
    save(path,result)
    return result


def load_sources(family):
    manifest = read_manifest(ROOT/f'artifacts/manifests/{family}_evaluation_v1.jsonl')
    expected_records,expected_items = (4000,60) if family=='constructed' else (2000,89)
    assert len(manifest)==expected_records
    ids = [row['record_id'] for row in manifest]
    assert len(set(ids))==len(ids)
    items = sorted({row['item_id'] for row in manifest})
    assert len(items)==expected_items
    lookup = {item:i for i,item in enumerate(items)}
    indices = np.array([lookup[row['item_id']] for row in manifest])
    humans = np.empty((len(ids),8,2),dtype=int)
    keys = np.empty((len(ids),8),dtype=object)
    archives = {}
    try:
        for i,pointer in enumerate(manifest):
            archive_path = (ROOT/pointer['zip_path']).resolve()
            assert ROOT.resolve() in archive_path.parents
            if archive_path not in archives:
                archives[archive_path] = zipfile.ZipFile(archive_path)
            raw = archives[archive_path].read(pointer['member'])
            for encoding in ('utf-8-sig','utf-8','cp949'):
                try:
                    record = json.loads(raw.decode(encoding))
                    break
                except (UnicodeDecodeError,json.JSONDecodeError):
                    continue
            else:
                raise ValueError('Cannot decode source')
            assert hashlib.sha256(str(record['essay_answer']['text']).encode()).hexdigest()==pointer['content_sha256']
            assert str(record['essay_question']['id'])==str(pointer['item_id'])
            first,second = human_scores(record)
            for c,criterion in enumerate(CRITERIA):
                humans[i,c] = [first[criterion],second[criterion]]
                keys[i,c] = record['rubric']['analytic'][criterion]['rubric_key']
    finally:
        for archive in archives.values():
            archive.close()
    assert np.all((humans>=1)&(humans<=5))
    return ids,indices,humans,keys


def load_predictions(family, ids):
    paths = paths_for(family)
    tensor = np.full((len(ids),len(paths),8),np.nan)
    lookup = {rid:i for i,rid in enumerate(ids)}
    metadata = {}
    for m,(name,path) in enumerate(paths.items()):
        seen = set()
        statuses = Counter()
        requested_models = Counter()
        returned_models = Counter()
        loaded_revisions = Counter()
        error_types = Counter()
        usage_totals = Counter()
        direct_tokens = Counter()
        network_calls = 0
        latency = []
        amortized = []
        repaired = 0
        for line in path.read_text(encoding='utf-8').splitlines():
            if not line.strip():
                continue
            row = json.loads(line)
            assert row.get('provider')!='mock'
            rid = row['record_id']
            assert rid in lookup and rid not in seen, f'Duplicate or unknown ID in {name}'
            seen.add(rid)
            statuses[row['status']]+=1
            requested_models[str(row.get('requested_model'))]+=1
            returned_models[str(row.get('returned_model'))]+=1
            loaded_revisions[str(row.get('loaded_commit_hash'))]+=1
            network_calls+=int(row.get('network_calls',0))
            for token_key in ('input_tokens','output_tokens'):
                if isinstance(row.get(token_key),(int,float)):
                    direct_tokens[token_key]+=row[token_key]
            for token_key,value in (row.get('usage') or {}).items():
                if isinstance(value,(int,float)) and not isinstance(value,bool):
                    usage_totals[token_key]+=value
            if row.get('latency_seconds') is not None:
                latency.append(float(row['latency_seconds']))
            if row.get('amortized_latency_seconds') is not None:
                amortized.append(float(row['amortized_latency_seconds']))
            repaired+=int(bool(row.get('repair_used',False)))
            if row['status']=='ok':
                scores = row['scores']
                assert set(scores)==set(CRITERIA)
                for c,criterion in enumerate(CRITERIA):
                    value = scores[criterion]
                    assert type(value)==int and 1<=value<=5
                    tensor[lookup[rid],m,c]=value
            else:
                assert row['status']=='error'
                error_types[str(row.get('error_type'))]+=1
        assert seen==set(ids)
        expected_errors = 10 if name=='exaone4_1_2b' else 0
        assert statuses.get('error',0)==expected_errors
        meta_path = Path(str(path)+'.meta.json')
        rawmeta = json.loads(meta_path.read_text(encoding='utf-8')) if meta_path.exists() else {}
        keep = ('generation_seconds','input_tokens','output_tokens','peak_vram_bytes','batch_size','dtype','model','model_id','provider',
                'requested_revision','loaded_commit_hash','gpu_name','device_name','torch_version','transformers_version','status',
                'newly_completed','errors','repaired','input_tokens_per_second')
        metadata[name] = {'records':len(seen),'status_counts':dict(statuses),'repaired_flag_count':repaired,
                          'requested_models':dict(requested_models),'returned_models':dict(returned_models),
                          'loaded_revisions':dict(loaded_revisions),'error_types':dict(error_types),
                          'summed_usage_fields':dict(usage_totals),'direct_tokens':dict(direct_tokens),'network_calls':network_calls,
                          'mean_request_latency_seconds':float(np.mean(latency)) if latency else None,
                          'mean_amortized_batch_latency_seconds':float(np.mean(amortized)) if amortized else None,
                          'metadata':{key:rawmeta[key] for key in keep if key in rawmeta}}
        print(f'{family} {name}: {len(seen)} records, {expected_errors} errors',flush=True)
    return tensor,metadata


def analyze_family(family):
    ids,indices,humans,rubric_keys = load_sources(family)
    predictions,metadata = load_predictions(family,ids)
    nitems = len(np.unique(indices))
    if family=='constructed':
        keys = list(CRITERIA)
        conf,human_conf = original.build_item_confusions(indices,predictions,humans,nitems)
        loss = original.build_item_losses(indices,predictions,humans,nitems)
        response_conf,_ = original.build_item_confusions(indices,predictions,humans,nitems,equal_item_weighting=False)
        worst = original.worst_score_fill(predictions,humans)
        worst_conf,_ = original.build_item_confusions(indices,worst,humans,nitems)
    else:
        cfg = json.loads((ROOT/'configs/paper1_essay_rubric_judgment_demand_v1.json').read_text(encoding='utf-8'))
        keys = [r['rubric_key'] for r in cfg['rubrics']]
        conf,human_conf,loss = build_essay_item_confusions(indices,predictions,humans,rubric_keys,keys,nitems)
        response_counts = np.bincount(indices)
        response_conf = conf*response_counts.reshape(-1,1,1,1,1,1)
        worst_conf = conf.copy()
    for m in range(conf.shape[1]):
        check = moment_qwk(qwk_moments(conf[:,m]).sum(axis=0)).mean(axis=-1)
        assert np.allclose(check,original.model_agreement_from_confusions(conf[:,m:m+1])[0],atol=1e-12)
    print(f'{family}: starting {REPETITIONS} paired item bootstrap draws',flush=True)
    boot = bootstrap(conf,human_conf,loss,REPETITIONS,SEED+(10 if family=='essay' else 0))
    variants = variants_for(family,keys)
    fits = {label:{'jdi':jdi,
                   'qwk':curve_analysis(boot['qwk'][:6],boot['qwk_boot'][:,:6],jdi),
                   'normalized_loss':curve_analysis(boot['loss'][:6],boot['loss_boot'][:,:6],jdi,True)}
            for label,jdi in variants.items()}
    names = list(paths_for(family))
    qwk_ci = np.percentile(boot['qwk_boot'],[2.5,97.5],axis=0)
    h_ci = np.percentile(boot['human_boot'],[2.5,97.5],axis=0)
    secondary = original.secondary_metrics_from_confusions(conf)
    response_qwk = moment_qwk(qwk_moments(response_conf).sum(axis=0)).mean(axis=-1)
    worst_qwk = moment_qwk(qwk_moments(worst_conf).sum(axis=0)).mean(axis=-1)
    rows=[]
    for m,name in enumerate(names):
        for c,key in enumerate(keys):
            rows.append({'model':name,'rubric':key,'qwk':float(boot['qwk'][m,c]),
                         'qwk_h1':float(boot['qwk_by_rater'][m,c,0]),'qwk_h2':float(boot['qwk_by_rater'][m,c,1]),
                         'qwk_ci95':[float(qwk_ci[0,m,c]),float(qwk_ci[1,m,c])],
                         'human_qwk':float(boot['human'][c]),'human_qwk_ci95':[float(h_ci[0,c]),float(h_ci[1,c])],
                         'response_weighted_qwk':float(response_qwk[m,c]),'worst_score_mapping_qwk':float(worst_qwk[m,c]),
                         'normalized_squared_loss':float(boot['loss'][m,c]),
                         **{metric:float(values[m,c]) for metric,values in secondary.items()}})
    model_summary = []
    for m,name in enumerate(names):
        means = boot['qwk_boot'][:,m].mean(axis=1)
        model_summary.append({'model':name,'equal_rubric_mean_qwk':float(boot['qwk'][m].mean()),
                              'mean_qwk_ci95':interval(means),'mean_loss':float(boot['loss'][m].mean()),
                              'mean_exact_agreement':float(secondary['exact_agreement'][m].mean()),
                              'mean_mae':float(secondary['mae'][m].mean()),'failures':metadata[name]['status_counts'].get('error',0)})
    output = {'family':family,'records':len(ids),'items':nitems,'rubric_keys':keys,'models':names,
              'analysis_status':'qualified protocol-deviating analysis; expert provenance unresolved',
              'model_summary':model_summary,'jdi_variants':fits,'cells':rows,'operational_metadata':metadata,
              'saturated_size_by_criterion':{
                  'qwk':saturated_interaction(boot['qwk'][:6],boot['qwk_boot'][:,:6]),
                  'normalized_loss':saturated_interaction(boot['loss'][:6],boot['loss_boot'][:,:6])},
              'bootstrap_repetitions':REPETITIONS,'bootstrap_seed':SEED+(10 if family=='essay' else 0),
              'secondary_metric_scope':'complete-pair agreement metrics; unresolved failures mapped to maximum normalized loss'}
    if family=='constructed':
        output['noninferiority'] = ni_with_full_holm(boot['qwk'],boot['qwk_boot'])
        output['korean_qwk_residuals'] = residual_analysis(boot['qwk'],boot['qwk_boot'],variants)
        output['korean_loss_residuals'] = residual_analysis(boot['loss'],boot['loss_boot'],variants)
        output['korean_residual_interpretation'] = 'Architecture/training distribution differences, not causal effects of Korean specialization; positive QWK and negative loss residuals favor Korean models.'
        worst_boot = bootstrap(worst_conf,human_conf,loss,REPETITIONS,SEED)
        output['korean_qwk_residuals_worst_mapping'] = residual_analysis(worst_boot['qwk'],worst_boot['qwk_boot'],variants)
    np.savez_compressed(OUT/f'{family}_bootstrap.npz',**boot)
    save(OUT/f'{family}_results.json',output)
    print(f'{family}: complete',flush=True)
    return output


def self_test():
    rng=np.random.default_rng(1)
    conf=rng.uniform(.1,5,size=(4,6,8,2,5,5))
    human=rng.uniform(.1,5,size=(4,8,5,5))
    losses=rng.uniform(0,1,size=(4,6,8))
    assert np.allclose(moment_qwk(qwk_moments(conf).sum(axis=0)).mean(axis=-1),original.model_agreement_from_confusions(conf))
    b=bootstrap(conf,human,losses,31,SEED)
    for i,weight in enumerate(b['multiplicities']):
        assert np.allclose(b['qwk_boot'][i],original.model_agreement_from_confusions(conf*weight[:,None,None,None,None,None]))
        assert np.allclose(b['loss_boot'][i],np.average(losses,axis=0,weights=weight))
    fit=curve_analysis(b['qwk'],b['qwk_boot'],[2,3,2,0,4,3,3,1])
    assert fit['scale_by_jdi']['one_sided_95_lower'] >= fit['scale_by_jdi']['ci95_two_sided'][0]
    assert holm_adjust({'a':.01,'b':.04,'c':.03}) == {'a':.03,'c':.06,'b':.06}
    additive=np.arange(6)[:,None]+np.arange(8)[None,:]
    assert np.allclose(additive[1:,1:]-additive[1:,[0]]-additive[[0],1:]+additive[0,0],0)
    saturated=saturated_interaction(b['qwk'],b['qwk_boot'])
    assert saturated['df']==35
    print('Synthetic QWK, bootstrap weighting, loss, interval and Holm checks passed',flush=True)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--self-test-only',action='store_true')
    parser.add_argument('--acknowledge-protocol-deviation',action='store_true')
    args=parser.parse_args()
    self_test()
    if args.self_test_only:
        return
    if not args.acknowledge_protocol_deviation:
        raise ValueError('Explicit acknowledgment required; this does not mark experts validated')
    start=time.monotonic()
    frozen=freeze()
    log=OUT/'outcome_access.json'
    if log.exists():
        raise ValueError('Outcome access already recorded; do not overwrite run silently')
    save(log,{'first_outcome_access_at_utc':utc(),'preunblinding_freeze_sha256':sha(OUT/'preunblinding_freeze.json'),
              'independent_expert_validation_complete':False,'amendment':'013'})
    results={family:analyze_family(family) for family in ('constructed','essay')}
    for name,digest in frozen['inputs'].items():
        assert sha(ROOT/name)==digest
    save(OUT/'completion.json',{'completed_at_utc':utc(),'seconds':time.monotonic()-start,
                               'families':list(results),'input_hashes_unchanged':True,'new_inference_calls':0,
                               'claim_status':frozen['claim_status'],
                               'result_sha256':{family:sha(OUT/f'{family}_results.json') for family in results}})
    print('Analysis finished; result files are local and source hashes are unchanged',flush=True)


if __name__=='__main__':
    main()
