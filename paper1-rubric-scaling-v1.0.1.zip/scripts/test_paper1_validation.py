"""Synthetic regression tests for the independent post-outcome audit."""
import unittest

import validate_paper1_and_add_baselines as audit

np = audit.np


class ValidationTests(unittest.TestCase):
    def test_perfect_and_constant_qwk(self):
        self.assertAlmostEqual(float(audit.qwk(np.eye(5))), 1)
        constant = np.zeros((5, 5))
        constant[2] = [1, 2, 3, 4, 5]
        self.assertAlmostEqual(float(audit.qwk(constant)), 0)
        undefined = np.zeros((5, 5))
        undefined[2, 2] = 1
        self.assertTrue(np.isnan(audit.qwk(undefined)))

    def test_qwk_reversed(self):
        self.assertAlmostEqual(float(audit.qwk(np.fliplr(np.eye(5)))), -1)

    def test_nfc_and_whitespace_digest(self):
        self.assertEqual(audit.normalized_digest('가  나\n다'), audit.normalized_digest('가 나 다'))
        self.assertEqual(audit.normalized_digest('가'), audit.normalized_digest('\u1100\u1161'))
        self.assertNotEqual(audit.normalized_digest('가'), audit.normalized_digest('나'))

    def test_equal_item_weighting_and_failure_loss(self):
        indices = np.array([0, 1, 1, 1])
        humans = np.full((4, 8, 2), 1)
        humans[1:] = 5
        keys = np.tile(np.array(audit.CRITERIA, dtype=object), (4, 1))
        predictions = np.full((4, 1, 8), 3.0)
        conf, hc, loss = audit.build_confusions(indices, humans, keys, list(audit.CRITERIA), predictions)
        self.assertTrue(np.allclose(conf.sum(axis=(-2, -1)), 1))
        self.assertTrue(np.allclose(hc.sum(axis=(-2, -1)), 1))
        values = audit.metrics(conf, loss)
        self.assertTrue(np.allclose(values['bias'], 0))
        self.assertTrue(np.allclose(values['normalized_squared_loss'], .25))
        predictions[0] = np.nan
        conf, _, loss = audit.build_confusions(indices, humans, keys, list(audit.CRITERIA), predictions)
        self.assertTrue(np.allclose(loss[0], 1))
        self.assertTrue(np.allclose(np.nanmean(loss, axis=0), .625))
        self.assertEqual(float(conf[0].sum()), 0)

    def test_bootstrap_duplicates_reweight_whole_items(self):
        rng = np.random.default_rng(12)
        indices = np.repeat(np.arange(3), [2, 3, 4])
        humans = rng.integers(1, 6, size=(9, 8, 2))
        keys = np.tile(np.array(audit.CRITERIA, dtype=object), (9, 1))
        predictions = rng.integers(1, 6, size=(9, 2, 8)).astype(float)
        conf, _, loss = audit.build_confusions(indices, humans, keys, list(audit.CRITERIA), predictions)
        weights = np.array([[1, 1, 1], [2, 1, 0], [0, 1, 2]])
        qs, ls = audit.bootstrap_from_weights(conf, loss, weights)
        for i, w in enumerate(weights):
            expected_conf = conf * w[:, None, None, None, None, None]
            self.assertTrue(np.allclose(qs[i], audit.qwk(expected_conf.sum(axis=0)).mean(axis=-1)))
            self.assertTrue(np.allclose(ls[i], np.average(loss, axis=0, weights=w)))

    def test_essay_absent_rubrics_not_zero_loss(self):
        indices = np.array([0, 0, 1, 1])
        humans = np.tile(np.array([1, 5]), (4, 8, 1))
        keys = np.array([[f'{prefix}_{c}' for c in range(8)] for prefix in ('a', 'a', 'b', 'b')], dtype=object)
        names = [f'{prefix}_{c}' for prefix in ('a', 'b') for c in range(8)]
        predictions = np.full((4, 1, 8), 3.0)
        conf, _, loss = audit.build_confusions(indices, humans, keys, names, predictions)
        self.assertTrue(np.isnan(loss[0, :, 8:]).all())
        self.assertTrue(np.isnan(loss[1, :, :8]).all())
        values = audit.metrics(conf, loss)
        self.assertTrue(np.allclose(values['normalized_squared_loss'], .25))
        self.assertTrue(np.allclose(values['qwk'], 0))

    def test_boolean_source_score_rejected(self):
        record = {'score': {'personal': {'analytic': {c: [1, 5] for c in audit.CRITERIA}}}}
        self.assertEqual(audit.source_labels(record).shape, (8, 2))
        record['score']['personal']['analytic'][audit.CRITERIA[0]] = [True, 5]
        with self.assertRaises(ValueError):
            audit.source_labels(record)


if __name__ == '__main__':
    unittest.main(verbosity=2)
