#!/usr/bin/env python3
"""Synthetic, zero-data unit tests for Paper 1 API adapters and score parsing."""

from __future__ import annotations

import json
import unittest
from unittest.mock import patch

import run_paper1_scoring as scoring
from paper1_prompting import CRITERIA, PromptPair, parse_scores


VALID = {criterion: 3 for criterion in CRITERIA}
PROMPT = PromptPair(system="synthetic system", user="synthetic user", prompt_sha256="0" * 64)


class ParserTests(unittest.TestCase):
    def test_exact_json(self):
        self.assertEqual(parse_scores(json.dumps(VALID)), VALID)

    def test_fenced_json_is_recoverable(self):
        self.assertEqual(parse_scores(f"```json\n{json.dumps(VALID)}\n```"), VALID)

    def test_rejects_extra_key(self):
        with self.assertRaises(ValueError):
            parse_scores({**VALID, "holistic": 3})

    def test_rejects_float_and_out_of_range(self):
        for bad in (3.0, 0, 6, True):
            candidate = dict(VALID)
            candidate["task_1"] = bad
            with self.assertRaises(ValueError):
                parse_scores(candidate)


class AdapterTests(unittest.TestCase):
    @patch("run_paper1_scoring.post_json")
    def test_openai_responses_schema(self, post):
        post.return_value = {
            "id": "r",
            "model": "gpt-5.6-sol",
            "status": "completed",
            "usage": {},
            "output": [{"content": [{"type": "output_text", "text": json.dumps(VALID)}]}],
        }
        result = scoring.openai_adapter(PROMPT, "gpt-5.6-sol", "secret", 1, None)
        self.assertEqual(parse_scores(result.text), VALID)
        body = post.call_args.args[2]
        self.assertEqual(body["reasoning"]["effort"], "none")
        self.assertTrue(body["text"]["format"]["strict"])

    @patch("run_paper1_scoring.post_json")
    def test_anthropic_no_sampling_parameters(self, post):
        post.return_value = {
            "id": "a",
            "model": "claude-sonnet-5",
            "stop_reason": "end_turn",
            "usage": {},
            "content": [{"type": "text", "text": json.dumps(VALID)}],
        }
        result = scoring.anthropic_adapter(PROMPT, "claude-sonnet-5", "secret", 1, None)
        self.assertEqual(parse_scores(result.text), VALID)
        body = post.call_args.args[2]
        self.assertNotIn("temperature", body)
        self.assertEqual(body["thinking"], {"type": "disabled"})
        self.assertEqual(body["output_config"]["effort"], "low")

    @patch("run_paper1_scoring.post_json")
    def test_google_structured_low_thinking(self, post):
        post.return_value = {
            "modelVersion": "gemini-3.1-pro-preview",
            "usageMetadata": {},
            "candidates": [
                {
                    "finishReason": "STOP",
                    "content": {"parts": [{"text": json.dumps(VALID)}]},
                }
            ],
        }
        result = scoring.google_adapter(
            PROMPT, "gemini-3.1-pro-preview", "secret", 1, None
        )
        self.assertEqual(parse_scores(result.text), VALID)
        generation = post.call_args.args[2]["generationConfig"]
        self.assertEqual(generation["thinkingConfig"]["thinkingLevel"], "low")
        self.assertEqual(generation["responseMimeType"], "application/json")

    @patch("run_paper1_scoring.post_json")
    def test_ncloud_explicitly_disables_thinking(self, post):
        post.return_value = {
            "result": {
                "message": {"content": json.dumps(VALID)},
                "finishReason": "stop",
                "usage": {},
            }
        }
        result = scoring.ncloud_adapter(PROMPT, "HCX-007", "secret", 1, None)
        self.assertEqual(parse_scores(result.text), VALID)
        body = post.call_args.args[2]
        self.assertEqual(body["thinking"], {"effort": "none"})
        self.assertEqual(body["responseFormat"]["type"], "json")

    @patch("run_paper1_scoring.post_json")
    def test_openai_compatible_qwen_nonthinking(self, post):
        post.return_value = {
            "id": "v",
            "model": "Qwen/Qwen3-0.6B",
            "usage": {},
            "choices": [
                {
                    "finish_reason": "stop",
                    "message": {"content": json.dumps(VALID)},
                }
            ],
        }
        result = scoring.openai_compatible_adapter(
            PROMPT, "Qwen/Qwen3-0.6B", "", 1, "http://localhost:8000/v1"
        )
        self.assertEqual(parse_scores(result.text), VALID)
        body = post.call_args.args[2]
        self.assertFalse(body["chat_template_kwargs"]["enable_thinking"])
        self.assertEqual(body["temperature"], 0.0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
