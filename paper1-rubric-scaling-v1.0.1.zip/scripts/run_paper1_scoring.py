#!/usr/bin/env python3
"""Resume-safe Paper 1 scorer for local OpenAI-compatible and frontier APIs.

Secrets are read exclusively from environment variables.  Neither prompts nor
source responses are written to prediction files; successful rows contain IDs,
validated scores, hashes, latency, usage, and reproducibility metadata only.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import random
import sys
import threading
import time
import urllib.error
import urllib.request
import uuid
from concurrent.futures import Future, ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from paper1_prompting import (
    CRITERIA,
    PromptPair,
    load_json_member,
    make_repair_prompt,
    parse_scores,
    read_manifest,
    render_prompt,
    score_schema,
)


DEFAULT_KEY_ENVS = {
    "openai": "OPENAI_API_KEY",
    "anthropic": "ANTHROPIC_API_KEY",
    "google": "GEMINI_API_KEY",
    "ncloud": "NCLOUD_API_KEY",
}


class HttpStatusError(RuntimeError):
    def __init__(self, status: int):
        super().__init__(f"HTTP status {status}")
        self.status = status


class RateGate:
    def __init__(self, requests_per_second: float) -> None:
        self.interval = 1.0 / requests_per_second if requests_per_second > 0 else 0.0
        self.lock = threading.Lock()
        self.next_time = 0.0

    def wait(self) -> None:
        if not self.interval:
            return
        with self.lock:
            now = time.monotonic()
            delay = max(0.0, self.next_time - now)
            self.next_time = max(now, self.next_time) + self.interval
        if delay:
            time.sleep(delay)


@dataclass(frozen=True)
class AdapterResult:
    text: str | dict[str, Any]
    usage: dict[str, Any]
    returned_model: str | None
    finish_reason: str | None
    response_id: str | None


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def post_json(
    url: str, headers: dict[str, str], body: dict[str, Any], timeout: float
) -> dict[str, Any]:
    data = json.dumps(body, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    request = urllib.request.Request(url, data=data, method="POST")
    request.add_header("Content-Type", "application/json")
    for name, value in headers.items():
        request.add_header(name, value)
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            raw = response.read()
    except urllib.error.HTTPError as exc:
        # Do not read or log the response body: some providers echo request content.
        raise HttpStatusError(exc.code) from exc
    return json.loads(raw.decode("utf-8"))


def openai_adapter(
    prompt: PromptPair, model: str, key: str, timeout: float, _: str | None
) -> AdapterResult:
    body = {
        "model": model,
        "input": [
            {
                "role": "system",
                "content": [{"type": "input_text", "text": prompt.system}],
            },
            {
                "role": "user",
                "content": [{"type": "input_text", "text": prompt.user}],
            },
        ],
        "reasoning": {"effort": "none"},
        "max_output_tokens": 128,
        "text": {
            "format": {
                "type": "json_schema",
                "name": "paper1_scores",
                "strict": True,
                "schema": score_schema(),
            }
        },
    }
    response = post_json(
        "https://api.openai.com/v1/responses",
        {"Authorization": f"Bearer {key}"},
        body,
        timeout,
    )
    texts = []
    for output in response.get("output", []):
        for content in output.get("content", []):
            if content.get("type") == "output_text":
                texts.append(content.get("text", ""))
    return AdapterResult(
        text="".join(texts),
        usage=response.get("usage", {}),
        returned_model=response.get("model"),
        finish_reason=response.get("status"),
        response_id=response.get("id"),
    )


def anthropic_adapter(
    prompt: PromptPair, model: str, key: str, timeout: float, _: str | None
) -> AdapterResult:
    body = {
        "model": model,
        "max_tokens": 128,
        "system": prompt.system,
        "messages": [{"role": "user", "content": prompt.user}],
        "thinking": {"type": "disabled"},
        "output_config": {
            "effort": "low",
            "format": {"type": "json_schema", "schema": score_schema()},
        },
    }
    response = post_json(
        "https://api.anthropic.com/v1/messages",
        {
            "x-api-key": key,
            "anthropic-version": "2023-06-01",
        },
        body,
        timeout,
    )
    texts = [
        part.get("text", "")
        for part in response.get("content", [])
        if part.get("type") == "text"
    ]
    return AdapterResult(
        text="".join(texts),
        usage=response.get("usage", {}),
        returned_model=response.get("model"),
        finish_reason=response.get("stop_reason"),
        response_id=response.get("id"),
    )


def google_adapter(
    prompt: PromptPair, model: str, key: str, timeout: float, _: str | None
) -> AdapterResult:
    body = {
        "systemInstruction": {"parts": [{"text": prompt.system}]},
        "contents": [{"role": "user", "parts": [{"text": prompt.user}]}],
        "generationConfig": {
            "temperature": 0.0,
            "maxOutputTokens": 128,
            "responseMimeType": "application/json",
            "responseJsonSchema": score_schema(),
            "thinkingConfig": {"thinkingLevel": "low"},
        },
    }
    response = post_json(
        f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent",
        {"x-goog-api-key": key},
        body,
        timeout,
    )
    candidate = response.get("candidates", [{}])[0]
    texts = [part.get("text", "") for part in candidate.get("content", {}).get("parts", [])]
    return AdapterResult(
        text="".join(texts),
        usage=response.get("usageMetadata", {}),
        returned_model=response.get("modelVersion"),
        finish_reason=candidate.get("finishReason"),
        response_id=response.get("responseId"),
    )


def ncloud_schema() -> dict[str, Any]:
    schema = score_schema()
    schema.pop("additionalProperties", None)
    return schema


def ncloud_adapter(
    prompt: PromptPair, model: str, key: str, timeout: float, _: str | None
) -> AdapterResult:
    # HCX-007 defaults to low thinking when this field is omitted. The live API
    # rejects that implicit mode together with Structured Outputs, so explicitly
    # select the documented non-reasoning mode.
    body = {
        "messages": [
            {"role": "system", "content": prompt.system},
            {"role": "user", "content": prompt.user},
        ],
        "topP": 1.0,
        "topK": 1,
        "maxCompletionTokens": 128,
        "temperature": 0.0,
        "repetitionPenalty": 1.0,
        "seed": 20260903,
        "stop": [],
        "thinking": {"effort": "none"},
        "responseFormat": {"type": "json", "schema": ncloud_schema()},
        "includeAiFilters": False,
    }
    response = post_json(
        f"https://clovastudio.stream.ntruss.com/v3/chat-completions/{model}",
        {
            "Authorization": f"Bearer {key}",
            "X-NCP-CLOVASTUDIO-REQUEST-ID": str(uuid.uuid4()),
        },
        body,
        timeout,
    )
    result = response.get("result", {})
    return AdapterResult(
        text=result.get("message", {}).get("content", ""),
        usage=result.get("usage", {}),
        returned_model=model,
        finish_reason=result.get("finishReason"),
        response_id=None,
    )


def openai_compatible_adapter(
    prompt: PromptPair, model: str, key: str, timeout: float, base_url: str | None
) -> AdapterResult:
    if not base_url:
        base_url = "http://127.0.0.1:8000/v1"
    body = {
        "model": model,
        "messages": [
            {"role": "system", "content": prompt.system},
            {"role": "user", "content": prompt.user},
        ],
        "temperature": 0.0,
        "top_p": 1.0,
        "seed": 20260903,
        "max_tokens": 128,
        "chat_template_kwargs": {"enable_thinking": False},
        "response_format": {
            "type": "json_schema",
            "json_schema": {
                "name": "paper1_scores",
                "strict": True,
                "schema": score_schema(),
            },
        },
    }
    headers = {"Authorization": f"Bearer {key}"} if key else {}
    response = post_json(
        base_url.rstrip("/") + "/chat/completions", headers, body, timeout
    )
    choice = response.get("choices", [{}])[0]
    content = choice.get("message", {}).get("content", "")
    return AdapterResult(
        text=content,
        usage=response.get("usage", {}),
        returned_model=response.get("model"),
        finish_reason=choice.get("finish_reason"),
        response_id=response.get("id"),
    )


def mock_adapter(
    prompt: PromptPair, model: str, key: str, timeout: float, base_url: str | None
) -> AdapterResult:
    del key, timeout, base_url
    # Pipeline test only.  Never use these deterministic pseudo-scores in analysis.
    digest = bytes.fromhex(prompt.prompt_sha256)
    scores = {criterion: 1 + digest[index] % 5 for index, criterion in enumerate(CRITERIA)}
    return AdapterResult(
        text=scores,
        usage={"mock": True},
        returned_model=model,
        finish_reason="mock",
        response_id=None,
    )


ADAPTERS: dict[str, Callable[..., AdapterResult]] = {
    "openai": openai_adapter,
    "anthropic": anthropic_adapter,
    "google": google_adapter,
    "ncloud": ncloud_adapter,
    "openai-compatible": openai_compatible_adapter,
    "mock": mock_adapter,
}


def retryable(exc: Exception) -> bool:
    if isinstance(exc, HttpStatusError):
        return exc.status in {408, 409, 429, 500, 502, 503, 504}
    return isinstance(exc, (TimeoutError, urllib.error.URLError))


def score_one(
    workspace: Path,
    prompt_path: Path,
    pointer: dict[str, Any],
    provider: str,
    model: str,
    key: str,
    timeout: float,
    base_url: str | None,
    retries: int,
    gate: RateGate,
) -> dict[str, Any]:
    started = time.perf_counter()
    prompt: PromptPair | None = None
    network_calls = 0
    first_raw_output: str | dict[str, Any] | None = None
    final_raw_output: str | dict[str, Any] | None = None
    try:
        record = load_json_member(workspace, pointer)
        prompt = render_prompt(record, prompt_path)
        adapter = ADAPTERS[provider]

        def call_with_retries(current_prompt: PromptPair) -> AdapterResult:
            nonlocal network_calls
            last_error: Exception | None = None
            for attempt in range(retries + 1):
                try:
                    gate.wait()
                    network_calls += 1
                    return adapter(current_prompt, model, key, timeout, base_url)
                except Exception as exc:
                    last_error = exc
                    if attempt >= retries or not retryable(exc):
                        raise
                    wait_seconds = min(30.0, (2**attempt) + random.random())
                    time.sleep(wait_seconds)
            raise last_error or RuntimeError("Adapter produced no result")

        adapter_result = call_with_retries(prompt)
        first_raw_output = adapter_result.text
        final_raw_output = first_raw_output
        repair_used = False
        repair_prompt_sha256 = None
        try:
            scores = parse_scores(final_raw_output)
        except (ValueError, json.JSONDecodeError):
            repair_prompt = make_repair_prompt(prompt, prompt_path)
            repair_prompt_sha256 = repair_prompt.prompt_sha256
            adapter_result = call_with_retries(repair_prompt)
            final_raw_output = adapter_result.text
            repair_used = True
            scores = parse_scores(final_raw_output)
        raw_hash = hashlib.sha256(
            json.dumps(
                final_raw_output,
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
            ).encode("utf-8")
        ).hexdigest()
        return {
            "record_id": pointer["record_id"],
            "item_id": pointer["item_id"],
            "answer_id": pointer["answer_id"],
            "dataset": pointer["dataset"],
            "provider": provider,
            "requested_model": model,
            "returned_model": adapter_result.returned_model,
            "status": "ok",
            "scores": scores,
            "raw_output": final_raw_output,
            "first_raw_output": first_raw_output if repair_used else None,
            "prompt_sha256": prompt.prompt_sha256,
            "repair_used": repair_used,
            "repair_prompt_sha256": repair_prompt_sha256,
            "response_sha256": raw_hash,
            "usage": adapter_result.usage,
            "finish_reason": adapter_result.finish_reason,
            "provider_response_id": adapter_result.response_id,
            "network_calls": network_calls,
            "latency_seconds": round(time.perf_counter() - started, 6),
            "completed_at_utc": datetime.now(timezone.utc).isoformat(),
        }
    except Exception as exc:
        return {
            "record_id": pointer["record_id"],
            "item_id": pointer["item_id"],
            "answer_id": pointer["answer_id"],
            "dataset": pointer["dataset"],
            "provider": provider,
            "requested_model": model,
            "status": "error",
            "error_type": type(exc).__name__,
            "error": str(exc)[:300],
            "prompt_sha256": prompt.prompt_sha256 if prompt else None,
            "first_raw_output": first_raw_output,
            "raw_output": final_raw_output,
            "network_calls": network_calls,
            "latency_seconds": round(time.perf_counter() - started, 6),
            "completed_at_utc": datetime.now(timezone.utc).isoformat(),
        }


def completed_ids(path: Path) -> set[str]:
    completed: set[str] = set()
    if not path.exists():
        return completed
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            if not line.strip():
                continue
            row = json.loads(line)
            if row.get("status") == "ok":
                completed.add(row["record_id"])
    return completed


def write_metadata(
    path: Path,
    args: argparse.Namespace,
    manifest: Path,
    prompt_path: Path,
    total_records: int,
) -> None:
    metadata = {
        "schema_version": 1,
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "provider": args.provider,
        "requested_model": args.model,
        "manifest_path": str(manifest),
        "manifest_sha256": file_sha256(manifest),
        "prompt_template_path": str(prompt_path),
        "prompt_template_sha256": file_sha256(prompt_path),
        "experiment_config_sha256": file_sha256(args.config),
        "records_after_limit": total_records,
        "workers": args.workers,
        "requests_per_second": args.requests_per_second,
        "timeout_seconds": args.timeout,
        "retries": args.retries,
        "secrets_source": "environment variables only; never persisted",
        "mock_results_excluded_from_analysis": args.provider == "mock",
    }
    path.write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--provider", choices=sorted(ADAPTERS), required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--workspace", type=Path, default=Path(__file__).resolve().parents[1]
    )
    parser.add_argument(
        "--prompt", type=Path, default=Path("configs/paper1_prompt_v1.txt")
    )
    parser.add_argument(
        "--config", type=Path, default=Path("configs/paper1_experiment_v1.json")
    )
    parser.add_argument("--base-url", default=None)
    parser.add_argument("--key-env", default=None)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--requests-per-second", type=float, default=0.0)
    parser.add_argument("--timeout", type=float, default=180.0)
    parser.add_argument("--retries", type=int, default=5)
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--dry-run", action="store_true")
    return parser.parse_args()


def resolve_from_workspace(workspace: Path, path: Path) -> Path:
    return path.resolve() if path.is_absolute() else (workspace / path).resolve()


def main() -> int:
    args = parse_args()
    if args.workers < 1 or args.retries < 0 or args.requests_per_second < 0:
        print("ERROR: invalid worker/retry/rate setting", file=sys.stderr)
        return 2
    workspace = args.workspace.resolve()
    manifest = resolve_from_workspace(workspace, args.manifest)
    output = resolve_from_workspace(workspace, args.output)
    prompt_path = resolve_from_workspace(workspace, args.prompt)
    args.config = resolve_from_workspace(workspace, args.config)
    rows = read_manifest(manifest)
    if args.limit is not None:
        rows = rows[: args.limit]

    key_env = args.key_env or DEFAULT_KEY_ENVS.get(args.provider)
    key = os.environ.get(key_env, "") if key_env else ""
    if args.provider not in {"openai-compatible", "mock"} and not key:
        print(
            f"ERROR: {key_env} is not set. Secrets must be injected through the "
            "environment; they are never accepted as CLI arguments.",
            file=sys.stderr,
        )
        return 2

    output.parent.mkdir(parents=True, exist_ok=True)
    metadata_path = output.with_suffix(output.suffix + ".meta.json")
    if args.dry_run:
        preview = rows[: min(3, len(rows))]
        lengths = []
        hashes = []
        for pointer in preview:
            record = load_json_member(workspace, pointer)
            prompt = render_prompt(record, prompt_path)
            lengths.append(len(prompt.system) + len(prompt.user))
            hashes.append(prompt.prompt_sha256)
        print(
            json.dumps(
                {
                    "provider": args.provider,
                    "model": args.model,
                    "records": len(rows),
                    "preview_prompt_chars": lengths,
                    "preview_prompt_sha256": hashes,
                    "source_text_printed": False,
                },
                indent=2,
            )
        )
        return 0

    done = completed_ids(output)
    pending = [row for row in rows if row["record_id"] not in done]
    write_metadata(metadata_path, args, manifest, prompt_path, len(rows))
    print(
        f"provider={args.provider} model={args.model} total={len(rows)} "
        f"already_ok={len(done)} pending={len(pending)}"
    )
    if not pending:
        return 0

    gate = RateGate(args.requests_per_second)
    ok = 0
    errors = 0
    with output.open("a", encoding="utf-8", newline="\n") as handle:
        with ThreadPoolExecutor(max_workers=args.workers) as executor:
            futures: list[Future[dict[str, Any]]] = [
                executor.submit(
                    score_one,
                    workspace,
                    prompt_path,
                    pointer,
                    args.provider,
                    args.model,
                    key,
                    args.timeout,
                    args.base_url,
                    args.retries,
                    gate,
                )
                for pointer in pending
            ]
            for index, future in enumerate(as_completed(futures), 1):
                result = future.result()
                handle.write(json.dumps(result, ensure_ascii=False, sort_keys=True) + "\n")
                handle.flush()
                if result["status"] == "ok":
                    ok += 1
                else:
                    errors += 1
                if index % 50 == 0 or index == len(futures):
                    print(f"completed={index}/{len(futures)} ok={ok} errors={errors}")
    return 0 if errors == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
