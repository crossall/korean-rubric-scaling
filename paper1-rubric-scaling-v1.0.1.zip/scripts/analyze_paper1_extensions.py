#!/usr/bin/env python3
"""Paper 1 frontier non-inferiority, Korean-SLM residual, and essay replication.

This script is intentionally gated by an explicit expert-JDI-complete flag so
criterion-level model outcomes are not opened before the protocol's blinded
content-validation step is complete.
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np

from analyze_paper1_primary import (
    bootstrap_analysis,
    build_item_confusions,
    design_matrices,
    human_agreement_from_confusions,
    model_agreement_from_confusions,
    parse_mapping,
    read_prediction_file,
    sha256_file,
    weighted_qwk_from_confusion,
)
from paper1_prompting import CRITERIA, human_scores, load_json_member, read_manifest


def resolve(workspace: Path, path: Path) -> Path:
    return path.resolve() if path.is_absolute() else (workspace / path).resolve()


def load_humans_and_rubrics(
    workspace: Path, manifest: list[dict[str, Any]]
) -> tuple[np.ndarray, np.ndarray]:
    humans = np.empty((len(manifest), len(CRITERIA), 2), dtype=int)
    rubric_keys = np.empty((len(manifest), len(CRITERIA)), dtype=object)
    for response, pointer in enumerate(manifest):
        record = load_json_member(workspace, pointer)
        first, second = human_scores(record)
        for criterion_index, criterion in enumerate(CRITERIA):
            humans[response, criterion_index] = [first[criterion], second[criterion]]
            rubric_keys[response, criterion_index] = record["rubric"]["analytic"][
                criterion
            ]["rubric_key"]
    return humans, rubric_keys


def load_prediction_tensor(
    paths: dict[str, Path],
    aliases: list[str],
    record_index: dict[str, int],
    allow_mock: bool,
) -> tuple[np.ndarray, dict[str, int], dict[str, str]]:
    predictions = np.full(
        (len(record_index), len(aliases), len(CRITERIA)), np.nan, dtype=float
    )
    failures: dict[str, int] = {}
    hashes: dict[str, str] = {}
    for model_index, alias in enumerate(aliases):
        path = paths[alias]
        hashes[alias] = sha256_file(path)
        rows = read_prediction_file(path, allow_mock)
        unknown = set(rows) - set(record_index)
        if unknown:
            raise ValueError(f"{alias}: {len(unknown)} unknown record IDs")
        failure_count = 0
        for record_id, response in record_index.items():
            row = rows.get(record_id)
            if not row or row.get("status") != "ok":
                failure_count += 1
                continue
            scores = row.get("scores", {})
            if set(scores) != set(CRITERIA):
                failure_count += 1
                continue
            for criterion_index, criterion in enumerate(CRITERIA):
                score = scores[criterion]
                if isinstance(score, bool) or not isinstance(score, int) or not 1 <= score <= 5:
                    raise ValueError(f"{alias}/{record_id}/{criterion}: illegal score")
                predictions[response, model_index, criterion_index] = score
        failures[alias] = failure_count
    return predictions, failures, hashes


def bootstrap_qwk_cells(
    item_confusions: np.ndarray, repetitions: int, seed: int
) -> tuple[np.ndarray, np.ndarray]:
    observed = model_agreement_from_confusions(item_confusions)
    item_count, model_count, criterion_count = item_confusions.shape[:3]
    samples = np.empty((repetitions, model_count, criterion_count), dtype=float)
    rng = np.random.default_rng(seed)
    probabilities = np.full(item_count, 1.0 / item_count)
    for replicate in range(repetitions):
        multiplicity = rng.multinomial(item_count, probabilities).astype(float)
        combined = np.tensordot(multiplicity, item_confusions, axes=(0, 0))
        for model in range(model_count):
            for criterion in range(criterion_count):
                samples[replicate, model, criterion] = np.mean(
                    [
                        weighted_qwk_from_confusion(combined[model, criterion, rater])
                        for rater in range(2)
                    ]
                )
    if np.isnan(samples).any():
        raise ValueError("Undefined QWK in at least one item bootstrap sample")
    return observed, samples


def holm_adjust(p_values: dict[str, float]) -> dict[str, float]:
    ordered = sorted(p_values, key=p_values.get)
    count = len(ordered)
    adjusted: dict[str, float] = {}
    running = 0.0
    for rank, name in enumerate(ordered):
        candidate = min(1.0, (count - rank) * p_values[name])
        running = max(running, candidate)
        adjusted[name] = running
    return adjusted


def noninferiority(
    observed: np.ndarray,
    samples: np.ndarray,
    qwen_names: list[str],
    frontier_names: list[str],
    criteria: list[str],
    repetitions: int,
) -> dict[str, Any]:
    q_count = len(qwen_names)
    f_slice = slice(q_count, q_count + len(frontier_names))
    frontier_observed = observed[f_slice]
    frontier_samples = samples[:, f_slice]
    reference_observed = np.median(frontier_observed, axis=0)
    reference_samples = np.median(frontier_samples, axis=1)
    output: dict[str, Any] = {
        "frontier_names": frontier_names,
        "frontier_reference": {},
        "margins": {},
    }
    for criterion_index, criterion in enumerate(criteria):
        output["frontier_reference"][criterion] = {
            "median": float(reference_observed[criterion_index]),
            "band_min": float(frontier_observed[:, criterion_index].min()),
            "band_max": float(frontier_observed[:, criterion_index].max()),
        }

    for margin in (0.05, 0.03):
        margin_key = f"delta_{margin:.2f}"
        details: dict[str, Any] = {}
        boundary_p: dict[str, float] = {}
        tentative_minimum: dict[str, str | None] = {}
        for criterion_index, criterion in enumerate(criteria):
            per_size: dict[str, Any] = {}
            active = True
            minimum: str | None = None
            descending = list(range(q_count - 1, -1, -1))
            for model_index in descending:
                delta = (
                    observed[model_index, criterion_index]
                    - reference_observed[criterion_index]
                )
                boot_delta = (
                    samples[:, model_index, criterion_index]
                    - reference_samples[:, criterion_index]
                )
                lower = float(np.percentile(boot_delta, 5.0))
                p_value = float(
                    (np.count_nonzero(boot_delta <= -margin) + 1)
                    / (repetitions + 1)
                )
                raw_pass = bool(delta > -margin and lower > -margin and p_value < 0.05)
                sequence_pass = bool(active and raw_pass)
                if sequence_pass:
                    minimum = qwen_names[model_index]
                else:
                    active = False
                per_size[qwen_names[model_index]] = {
                    "delta_qwk": float(delta),
                    "one_sided_95_lower_bound": lower,
                    "noninferiority_p": p_value,
                    "raw_pass": raw_pass,
                    "fixed_sequence_pass": sequence_pass,
                }
            tentative_minimum[criterion] = minimum
            if minimum is None:
                boundary_p[criterion] = per_size[qwen_names[-1]]["noninferiority_p"]
            else:
                boundary_p[criterion] = per_size[minimum]["noninferiority_p"]
            details[criterion] = {"sizes": per_size}
        adjusted = holm_adjust(boundary_p)
        for criterion in criteria:
            minimum = tentative_minimum[criterion]
            holm_pass = minimum is not None and adjusted[criterion] < 0.05
            details[criterion]["tentative_minimum_sufficient"] = minimum
            details[criterion]["boundary_holm_adjusted_p"] = adjusted[criterion]
            details[criterion]["minimum_sufficient_holm"] = minimum if holm_pass else None
            details[criterion]["decision"] = (
                minimum if holm_pass else "not reached after Holm boundary control"
            )
        output["margins"][margin_key] = details
    return output


def korean_residuals(
    observed: np.ndarray,
    samples: np.ndarray,
    qwen_parameters: np.ndarray,
    korean_parameters: np.ndarray,
    korean_names: list[str],
    criteria: list[str],
    jdi: np.ndarray,
) -> dict[str, Any]:
    q_count = qwen_parameters.size
    k_count = korean_parameters.size
    x_q = np.column_stack([np.ones(q_count), np.log2(qwen_parameters)])
    x_k = np.column_stack([np.ones(k_count), np.log2(korean_parameters)])
    q_pinv = np.linalg.pinv(x_q)
    residual = np.empty((k_count, len(criteria)), dtype=float)
    for criterion in range(len(criteria)):
        beta = q_pinv @ observed[:q_count, criterion]
        expected = x_k @ beta
        residual[:, criterion] = observed[q_count : q_count + k_count, criterion] - expected

    boot_residual = np.empty((samples.shape[0], k_count, len(criteria)), dtype=float)
    for replicate in range(samples.shape[0]):
        for criterion in range(len(criteria)):
            beta = q_pinv @ samples[replicate, :q_count, criterion]
            expected = x_k @ beta
            boot_residual[replicate, :, criterion] = (
                samples[replicate, q_count : q_count + k_count, criterion] - expected
            )
    deviations = boot_residual - residual[None, :, :]
    simultaneous_radius = float(np.percentile(np.max(np.abs(deviations), axis=(1, 2)), 95))
    jdi_x = np.column_stack([np.ones(len(criteria)), jdi])
    jdi_pinv = np.linalg.pinv(jdi_x)
    output: dict[str, Any] = {
        "interpretation": "architecture/training-distribution residual, not a causal language-specialization effect",
        "simultaneous_95_radius_all_model_criterion_cells": simultaneous_radius,
        "models": {},
    }
    for model, name in enumerate(korean_names):
        slopes = np.array(
            [jdi_pinv @ boot_residual[replicate, model] for replicate in range(samples.shape[0])]
        )[:, 1]
        observed_slope = float((jdi_pinv @ residual[model])[1])
        model_result = {
            "parameters_b": float(korean_parameters[model]),
            "equal_criterion_mean_residual": float(residual[model].mean()),
            "mean_residual_bootstrap_95_ci": np.percentile(
                boot_residual[:, model].mean(axis=1), [2.5, 97.5]
            ).tolist(),
            "residual_by_jdi_slope": observed_slope,
            "residual_by_jdi_bootstrap_95_ci": np.percentile(
                slopes, [2.5, 97.5]
            ).tolist(),
            "criteria": {},
        }
        for criterion_index, criterion in enumerate(criteria):
            estimate = float(residual[model, criterion_index])
            model_result["criteria"][criterion] = {
                "residual_qwk": estimate,
                "bootstrap_percentile_95_ci": np.percentile(
                    boot_residual[:, model, criterion_index], [2.5, 97.5]
                ).tolist(),
                "simultaneous_95_ci": [
                    estimate - simultaneous_radius,
                    estimate + simultaneous_radius,
                ],
            }
        output["models"][name] = model_result
    return output


def build_essay_item_confusions(
    item_indices: np.ndarray,
    predictions: np.ndarray,
    humans: np.ndarray,
    rubric_keys: np.ndarray,
    rubric_names: list[str],
    item_count: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    _, model_count, _ = predictions.shape
    rubric_lookup = {key: index for index, key in enumerate(rubric_names)}
    rubric_count = len(rubric_names)
    model_conf = np.zeros((item_count, model_count, rubric_count, 2, 5, 5))
    human_conf = np.zeros((item_count, rubric_count, 5, 5))
    item_losses = np.full((item_count, model_count, rubric_count), np.nan)
    for item in range(item_count):
        responses = np.flatnonzero(item_indices == item)
        for criterion_slot in range(len(CRITERIA)):
            keys = {rubric_keys[response, criterion_slot] for response in responses}
            if len(keys) != 1:
                raise ValueError(f"Item {item} has inconsistent rubric keys")
            rubric = rubric_lookup[keys.pop()]
            human_weight = 1.0 / len(responses)
            for response in responses:
                human_conf[
                    item,
                    rubric,
                    humans[response, criterion_slot, 0] - 1,
                    humans[response, criterion_slot, 1] - 1,
                ] += human_weight
            for model in range(model_count):
                valid = responses[~np.isnan(predictions[responses, model, criterion_slot])]
                if valid.size:
                    weight = 1.0 / valid.size
                    for response in valid:
                        predicted = int(predictions[response, model, criterion_slot]) - 1
                        for rater in range(2):
                            observed = humans[response, criterion_slot, rater] - 1
                            model_conf[item, model, rubric, rater, predicted, observed] += weight
                losses = []
                for response in responses:
                    predicted = predictions[response, model, criterion_slot]
                    if np.isnan(predicted):
                        losses.append(1.0)
                    else:
                        difference = (predicted - humans[response, criterion_slot]) / 4.0
                        losses.append(float(np.mean(difference**2)))
                item_losses[item, model, rubric] = np.mean(losses)
    return model_conf, human_conf, item_losses


def essay_loss_interaction(
    item_losses: np.ndarray,
    directional: np.ndarray,
    repetitions: int,
    seed: int,
) -> dict[str, Any]:
    if np.isnan(item_losses).any():
        # A rubric is absent from items outside its purpose family. Aggregate only
        # items where that rubric exists, retaining equal weights among those items.
        observed = np.nanmean(item_losses, axis=0)
    else:
        observed = item_losses.mean(axis=0)
    pinv = np.linalg.pinv(directional)
    estimate = float((pinv @ observed.reshape(-1))[-1])
    rng = np.random.default_rng(seed)
    item_count = item_losses.shape[0]
    coefficients = np.empty(repetitions)
    for replicate in range(repetitions):
        sampled_indices = rng.integers(0, item_count, size=item_count)
        cells = np.nanmean(item_losses[sampled_indices], axis=0)
        coefficients[replicate] = (pinv @ cells.reshape(-1))[-1]
    ci = np.percentile(coefficients, [2.5, 97.5]).tolist()
    return {
        "interaction_coefficient": estimate,
        "bootstrap_percentile_95_ci": ci,
        "one_sided_p_for_negative_interaction": float(
            (np.count_nonzero(coefficients >= 0) + 1) / (repetitions + 1)
        ),
        "direction_supported": bool(estimate < 0 and ci[1] < 0),
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--qwen-prediction", action="append", default=[])
    parser.add_argument("--qwen-parameter", action="append", default=[])
    parser.add_argument("--frontier-prediction", action="append", default=[])
    parser.add_argument("--korean-prediction", action="append", default=[])
    parser.add_argument("--korean-parameter", action="append", default=[])
    parser.add_argument("--essay-qwen-prediction", action="append", default=[])
    parser.add_argument(
        "--constructed-manifest",
        type=Path,
        default=Path("artifacts/manifests/constructed_evaluation_v1.jsonl"),
    )
    parser.add_argument(
        "--essay-manifest",
        type=Path,
        default=Path("artifacts/manifests/essay_evaluation_v1.jsonl"),
    )
    parser.add_argument(
        "--constructed-jdi",
        type=Path,
        default=Path("configs/paper1_rubric_judgment_demand_v1.json"),
    )
    parser.add_argument(
        "--essay-jdi",
        type=Path,
        default=Path("configs/paper1_essay_rubric_judgment_demand_v1.json"),
    )
    parser.add_argument(
        "--workspace", type=Path, default=Path(__file__).resolve().parents[1]
    )
    parser.add_argument("--output-dir", type=Path, default=Path("artifacts/analysis"))
    parser.add_argument("--bootstrap", type=int, default=9999)
    parser.add_argument("--seed", type=int, default=20260903)
    parser.add_argument("--allow-mock-for-test", action="store_true")
    parser.add_argument("--confirm-expert-jdi-complete", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if not args.confirm_expert_jdi_complete and not args.allow_mock_for_test:
        print(
            "ERROR: expert JDI validation must be completed before outcomes are opened; "
            "rerun with --confirm-expert-jdi-complete only after that step.",
            file=sys.stderr,
        )
        return 2
    workspace = args.workspace.resolve()
    try:
        qwen_paths = parse_mapping(args.qwen_prediction, Path)
        qwen_parameters_map = parse_mapping(args.qwen_parameter, float)
        frontier_paths = parse_mapping(args.frontier_prediction, Path)
        korean_paths = parse_mapping(args.korean_prediction, Path)
        korean_parameters_map = parse_mapping(args.korean_parameter, float)
        essay_qwen_paths = parse_mapping(args.essay_qwen_prediction, Path)
        if set(qwen_paths) != set(qwen_parameters_map) or len(qwen_paths) != 6:
            raise ValueError("Six matching Qwen prediction/parameter aliases required")
        if len(frontier_paths) != 4:
            raise ValueError("Four frontier predictions required")
        if set(korean_paths) != set(korean_parameters_map) or len(korean_paths) != 4:
            raise ValueError("Four matching Korean prediction/parameter aliases required")
        if set(essay_qwen_paths) != set(qwen_paths):
            raise ValueError("Essay Qwen aliases must match constructed Qwen aliases")
        qwen_names = sorted(qwen_paths, key=qwen_parameters_map.get)
        if [qwen_parameters_map[name] for name in qwen_names] != [0.6, 1.7, 4, 8, 14, 32]:
            raise ValueError("Qwen parameters must be 0.6,1.7,4,8,14,32B")
        frontier_names = list(frontier_paths)
        korean_names = sorted(korean_paths, key=korean_parameters_map.get)
        for mapping in (qwen_paths, frontier_paths, korean_paths, essay_qwen_paths):
            for name, path in list(mapping.items()):
                mapping[name] = resolve(workspace, path)

        constructed_manifest_path = resolve(workspace, args.constructed_manifest)
        constructed_manifest = read_manifest(constructed_manifest_path)
        if len(constructed_manifest) != 4000:
            raise ValueError("Constructed manifest must contain 4,000 records")
        constructed_record_index = {
            row["record_id"]: index for index, row in enumerate(constructed_manifest)
        }
        constructed_items = sorted({row["item_id"] for row in constructed_manifest})
        constructed_item_lookup = {name: index for index, name in enumerate(constructed_items)}
        constructed_item_indices = np.array(
            [constructed_item_lookup[row["item_id"]] for row in constructed_manifest]
        )
        constructed_humans, _ = load_humans_and_rubrics(
            workspace, constructed_manifest
        )
        all_constructed_paths = {
            **{name: qwen_paths[name] for name in qwen_names},
            **{name: frontier_paths[name] for name in frontier_names},
            **{name: korean_paths[name] for name in korean_names},
        }
        all_constructed_names = qwen_names + frontier_names + korean_names
        constructed_predictions, constructed_failures, constructed_hashes = (
            load_prediction_tensor(
                all_constructed_paths,
                all_constructed_names,
                constructed_record_index,
                args.allow_mock_for_test,
            )
        )
        constructed_conf, _ = build_item_confusions(
            constructed_item_indices,
            constructed_predictions,
            constructed_humans,
            len(constructed_items),
        )
        observed, boot = bootstrap_qwk_cells(
            constructed_conf, args.bootstrap, args.seed
        )
        q_count = len(qwen_names)
        f_count = len(frontier_names)
        noninferiority_result = noninferiority(
            observed[:, :],
            boot,
            qwen_names,
            frontier_names,
            list(CRITERIA),
            args.bootstrap,
        )

        constructed_jdi_config = json.loads(
            resolve(workspace, args.constructed_jdi).read_text(encoding="utf-8")
        )
        constructed_jdi_map = {
            entry["criterion"]: entry["judgment_demand_index"]
            for entry in constructed_jdi_config["criteria"]
        }
        constructed_jdi = np.array(
            [constructed_jdi_map[criterion] for criterion in CRITERIA], dtype=float
        )
        # Korean residual arrays must contain Qwen immediately followed by Korean.
        korean_indices = list(range(q_count)) + list(
            range(q_count + f_count, q_count + f_count + len(korean_names))
        )
        korean_result = korean_residuals(
            observed[korean_indices],
            boot[:, korean_indices],
            np.array([qwen_parameters_map[name] for name in qwen_names]),
            np.array([korean_parameters_map[name] for name in korean_names]),
            korean_names,
            list(CRITERIA),
            constructed_jdi,
        )

        essay_manifest_path = resolve(workspace, args.essay_manifest)
        essay_manifest = read_manifest(essay_manifest_path)
        if len(essay_manifest) != 2000:
            raise ValueError("Essay manifest must contain 2,000 records")
        essay_record_index = {
            row["record_id"]: index for index, row in enumerate(essay_manifest)
        }
        essay_items = sorted({row["item_id"] for row in essay_manifest})
        essay_item_lookup = {name: index for index, name in enumerate(essay_items)}
        essay_item_indices = np.array(
            [essay_item_lookup[row["item_id"]] for row in essay_manifest]
        )
        essay_humans, essay_rubric_keys = load_humans_and_rubrics(
            workspace, essay_manifest
        )
        essay_predictions, essay_failures, essay_hashes = load_prediction_tensor(
            essay_qwen_paths,
            qwen_names,
            essay_record_index,
            args.allow_mock_for_test,
        )
        essay_jdi_config = json.loads(
            resolve(workspace, args.essay_jdi).read_text(encoding="utf-8")
        )
        essay_rubric_names = [entry["rubric_key"] for entry in essay_jdi_config["rubrics"]]
        essay_jdi = np.array(
            [entry["judgment_demand_index"] for entry in essay_jdi_config["rubrics"]],
            dtype=float,
        )
        essay_conf, essay_human_conf, essay_item_losses = build_essay_item_confusions(
            essay_item_indices,
            essay_predictions,
            essay_humans,
            essay_rubric_keys,
            essay_rubric_names,
            len(essay_items),
        )
        essay_directional, essay_omnibus, _, _ = design_matrices(
            np.array([qwen_parameters_map[name] for name in qwen_names]), essay_jdi
        )
        essay_qwk = bootstrap_analysis(
            essay_conf,
            essay_directional,
            essay_omnibus,
            args.bootstrap,
            args.seed + 10,
        )
        essay_cells = essay_qwk.pop("observed_cells")
        essay_cell_ci = essay_qwk.pop("observed_cell_95_ci")
        essay_slopes = essay_qwk.pop("criterion_scale_slopes_standardized")
        essay_slope_ci = essay_qwk.pop("criterion_scale_slope_95_ci")
        essay_human_qwk = human_agreement_from_confusions(essay_human_conf)
        essay_loss = essay_loss_interaction(
            essay_item_losses,
            essay_directional,
            args.bootstrap,
            args.seed + 11,
        )
        essay_rubrics = {}
        for rubric_index, rubric in enumerate(essay_rubric_names):
            essay_rubrics[rubric] = {
                "jdi": int(essay_jdi[rubric_index]),
                "human_human_qwk": float(essay_human_qwk[rubric_index]),
                "scale_slope": float(essay_slopes[rubric_index]),
                "scale_slope_bootstrap_95_ci": essay_slope_ci[rubric_index].tolist(),
                "model_human_qwk": {
                    qwen_names[model]: float(essay_cells[model, rubric_index])
                    for model in range(len(qwen_names))
                },
                "model_human_qwk_bootstrap_95_ci": {
                    qwen_names[model]: essay_cell_ci[model, rubric_index].tolist()
                    for model in range(len(qwen_names))
                },
            }

        result = {
            "analysis_version": "paper1-extensions-v1",
            "generated_at_utc": datetime.now(timezone.utc).isoformat(),
            "bootstrap_repetitions": args.bootstrap,
            "bootstrap_seed": args.seed,
            "mock_test_mode": args.allow_mock_for_test,
            "constructed": {
                "manifest_sha256": sha256_file(constructed_manifest_path),
                "prediction_sha256": constructed_hashes,
                "failure_counts": constructed_failures,
                "frontier_noninferiority": noninferiority_result,
                "korean_slm_observed_expected_residuals": korean_result,
            },
            "essay_replication": {
                "manifest_sha256": sha256_file(essay_manifest_path),
                "prediction_sha256": essay_hashes,
                "failure_counts": essay_failures,
                "qwk_scale_by_jdi": essay_qwk["h1b"],
                "qwk_scale_by_rubric_omnibus": essay_qwk["h1a"],
                "normalized_loss_scale_by_jdi": essay_loss,
                "replication_supported": bool(
                    essay_qwk["h1b"]["supported_alpha_0_05"]
                    and essay_loss["direction_supported"]
                ),
                "rubrics": essay_rubrics,
            },
        }
        output_dir = resolve(workspace, args.output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        output_path = output_dir / "paper1_extensions_results.json"
        output_path.write_text(
            json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        print(output_path)
        print(
            f"essay_qwk_interaction={essay_qwk['h1b']['coefficient']:.6g} "
            f"essay_replication_supported={result['essay_replication']['replication_supported']}"
        )
        return 0
    except Exception as exc:
        print(f"ERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
