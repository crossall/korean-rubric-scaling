"""Synthetic checks for the post hoc robustness experiments (no student data)."""
import unittest
import paper1_robustness_helpers as h
np = h.np


class RobustnessTests(unittest.TestCase):
    def test_keyword_parentheses(self):
        groups = h.keyword_groups('공기(기체, 대류현상), 바람, 열(단열), 배수로')
        self.assertEqual(len(groups), 4)
        self.assertEqual(groups[0], ['공기', '기체', '대류현상'])
        self.assertEqual(h.keyword_score('기체 대류현상 바람', groups, True), 3)
        self.assertEqual(h.keyword_score('기체 대류현상 바람', groups, False), 2)

    def test_keyword_normalization_cap_and_errors(self):
        self.assertEqual(h.keyword_score('판 매 한 빵', [['판매한 빵']]), 2)
        self.assertEqual(h.keyword_score('abcdef', [[c] for c in 'abcdef']), 5)
        self.assertEqual(h.keyword_score('nothing', [['안']]), 1)
        for value in ['a(b,c', 'a),b', 'a,,b']:
            with self.assertRaises(ValueError):
                h.keyword_groups(value)

    def test_pairwise_bruteforce(self):
        rng = np.random.default_rng(20261011)
        for n in (2, 9, 100):
            for _ in range(20):
                pred = rng.integers(1, 6, n)
                human = rng.integers(1, 6, n)
                conf = np.bincount((pred-1)*5+human-1, minlength=25).reshape(5, 5)/n
                expected = []
                for a in range(n):
                    for b in range(a+1, n):
                        if human[a] == human[b]:
                            continue
                        product = (human[a]-human[b])*(pred[a]-pred[b])
                        expected.append(1. if product > 0 else .5 if product == 0 else 0.)
                actual, denom = h.pair_agreement(conf)
                if expected:
                    self.assertAlmostEqual(float(actual), np.mean(expected))
                    self.assertAlmostEqual(float(denom)*n*n, len(expected))
                else:
                    self.assertTrue(np.isnan(actual))

    def test_pairwise_extremes_and_batch(self):
        conf = np.stack([np.eye(5), np.fliplr(np.eye(5)), np.ones((5, 5))])
        np.testing.assert_allclose(h.pair_agreement(conf)[0], [1, 0, .5])
        constant = np.zeros((5, 5)); constant[2, :] = 1
        self.assertEqual(h.pair_agreement(constant)[0], .5)
        self.assertTrue(np.isnan(h.pair_agreement(constant.T)[0]))

    def test_equal_item_weighting(self):
        weights = h.item_weights(['A', 'A', 'B'])
        self.assertAlmostEqual(weights.mean(), 1)
        self.assertAlmostEqual(weights[:2].sum(), weights[2])
        values = np.array([[1., np.nan], [3., 5.]])
        np.testing.assert_equal(h.paired_item_means(values, np.array([[1, 1], [2, 0]])),
                                np.array([[2., 5.], [1., np.nan]]))

    def test_rounding_and_group_split(self):
        np.testing.assert_array_equal(h.rounded_score(np.array([0, 1.49, 1.5, 4.5, 9])), [1, 1, 2, 5, 5])
        self.assertEqual(h.tuning_fold('duplicate'), h.tuning_fold('duplicate'))
        self.assertEqual(set(h.tuning_fold(str(i)) for i in range(100)), set(range(5)))

    def test_undefined_bootstrap_is_not_dropped(self):
        result = h.finite_summary(.5, np.array([.4, np.nan, .6]))
        self.assertIsNone(result['ci95'])
        self.assertEqual(result['undefined_bootstrap_draws'], 1)

    def test_squared_error_decomposition(self):
        from run_paper1_robustness_diagnostics import error_components
        human = np.tile(np.arange(1, 5)[:, None, None], (2, 8, 2))
        pred = np.minimum(5, human[:, :, 0]+1)[:, None, :].astype(float)
        pred[0, 0, 0] = np.nan
        keys = np.tile(np.array(h.v.CRITERIA, dtype=object), (8, 1))
        indices = np.array([0]*4+[1]*4)
        bias, centered, counts = error_components(indices, human, keys, list(h.v.CRITERIA), pred)
        np.testing.assert_allclose(bias, 1/16)
        np.testing.assert_allclose(centered, 0)
        self.assertEqual(counts[0, 0, 0], 3)
        self.assertEqual(counts[1, 0, 0], 4)

    def test_text_pipeline_smoke_without_evaluation_labels(self):
        from run_paper1_text_baselines import fit_text_models
        from threadpoolctl import threadpool_limits
        rows = []
        for i in range(100):
            text = f'synthetic example group {i % 3} unique {i}'
            rows.append({'text': text, 'text_hash': h.v.normalized_digest(text),
                         'item': str(i % 2), 'humans': np.full((8, 2), 2+i % 3)})
        with threadpool_limits(limits=2):
            predictions, details = fit_text_models(rows, ['synthetic example unseen'], ['0'])
        self.assertEqual(predictions.shape, (1, 2, 8))
        self.assertEqual(details['group_overlap'], 0)
        self.assertEqual(details['fit_records']+details['tuning_records'], 100)
        self.assertTrue(np.isin(predictions, [1, 2, 3, 4, 5]).all())


if __name__ == '__main__':
    unittest.main()
