"""Independent synthetic checks for the added reviewer diagnostics."""
import unittest
import run_paper1_review_extensions as review
np = review.np


class ReviewDiagnosticsTests(unittest.TestCase):
    def test_equal_item_human_distribution(self):
        conf = np.zeros((2, 1, 5, 5))
        conf[0, 0, 0, 1] = 1
        conf[1, 0, 4, 4] = 1
        row = review.human_distributions(conf, ['a'], [101])[0]
        self.assertEqual(row['mean_h1'], 3)
        self.assertEqual(row['mean_h2'], 3.5)
        self.assertEqual(row['mean_h1_minus_h2'], -.5)
        self.assertEqual(row['floor_h1'], .5)
        self.assertEqual(row['ceiling_h1'], .5)

    def test_unresolved_loss_is_one_for_both_raters(self):
        indices = np.zeros(2, dtype=int)
        humans = np.ones((2, 8, 2), dtype=int)
        humans[0,:,1] = 5
        keys = np.tile(np.arange(8), (2,1))
        pred = np.ones((2, 1, 8))
        pred[1] = np.nan
        result = review.losses_by_rater(indices, humans, keys, list(range(8)), pred)
        np.testing.assert_array_equal(result[0,0,:,0], .5)
        np.testing.assert_array_equal(result[0,0,:,1], 1)

    def test_rater_bootstrap_preserves_identity_weights(self):
        conf = np.zeros((2,1,1,2,5,5))
        for i in range(2):
            conf[i,0,0,:,0,0] = .5
            conf[i,0,0,:,4,4] = .5
        loss = np.zeros((2,1,1,2))
        qb, lb = review.boot_raters(conf, loss, np.array([[1,1], [2,0], [0,2]]))
        np.testing.assert_allclose(qb, 1)
        np.testing.assert_allclose(lb, 0)


if __name__ == '__main__':
    unittest.main()
