"""Post-outcome, local-only numerical audit and answer-blind controls.

The archived primary pipeline is never edited or executed for side effects.
New controls are diagnostic and are not information-matched to zero-shot LLMs.
Only aggregate outputs are written; student texts and identifiers stay local.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
import unicodedata
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'artifacts/paper1_analysis_runtime'))
import numpy as np
from scipy.stats import chi2

import run_paper1_qualified_analysis as archived
from build_paper1_manifests import DATASETS, locate_label_zips, read_json_member
from paper1_prompting import CRITERIA, parse_scores, render_prompt

OLD = ROOT / 'artifacts/paper1_analysis_20261011'
DEFAULT_OUT = ROOT / 'artifacts/paper1_validation_20261011'
BASELINES = ['constant_3', 'training_rubric_mode', 'training_item_mode',
             'training_item_rounded_mean']
GRID = np.arange(1, 6, dtype=float)
DIFF = GRID[:, None] - GRID[None, :]


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2,
                                    allow_nan=False) + '\n', encoding='utf-8')


def normalized_digest(text):
    normalized = ' '.join(unicodedata.normalize('NFC', str(text)).split())
    return hashlib.sha256(normalized.encode('utf-8')).hexdigest()


def source_labels(record):
    """Read the annotation schema independently of the primary label helper."""
    labels = []
    for criterion in CRITERIA:
        entry = record['score']['personal']['analytic'][criterion]
        pair = entry['score'] if isinstance(entry, dict) else entry
        if not isinstance(pair, list) or len(pair) != 2:
            raise ValueError('Expected exactly two analytic rater scores')
        for value in pair:
            if isinstance(value, bool) or float(value) != int(value) or not 1 <= int(value) <= 5:
                raise ValueError('Illegal source score')
        labels.append([int(x) for x in pair])
    return np.asarray(labels, dtype=int)


def qwk(conf):
    """Confusion-matrix calculation, independent of archived moment code."""
    total = conf.sum(axis=(-2, -1))
    rows = conf.sum(axis=-1)
    columns = conf.sum(axis=-2)
    with np.errstate(divide='ignore', invalid='ignore'):
        expected = rows[..., :, None] * columns[..., None, :] / total[..., None, None]
        denominator = (expected * DIFF ** 2).sum(axis=(-2, -1))
        value = 1 - (conf * DIFF ** 2).sum(axis=(-2, -1)) / denominator
    return np.where((total > 0) & (denominator > 1e-12), value, np.nan)


def metrics(conf, item_loss):
    pooled = conf.sum(axis=0)
    total = pooled.sum(axis=(-2, -1))
    denom = pooled.sum(axis=-1) + pooled.sum(axis=-2)
    f1 = np.divide(2 * np.diagonal(pooled, axis1=-2, axis2=-1), denom,
                   out=np.zeros_like(denom), where=denom > 0).mean(axis=-1)
    def weighted(matrix):
        return ((pooled * matrix).sum(axis=(-2, -1)) / total).mean(axis=-1)
    return {
        'qwk': qwk(pooled).mean(axis=-1),
        'qwk_h1': qwk(pooled)[..., 0], 'qwk_h2': qwk(pooled)[..., 1],
        'normalized_squared_loss': np.nanmean(item_loss, axis=0),
        'mae': weighted(np.abs(DIFF)), 'bias': weighted(DIFF),
        'exact_agreement': weighted(np.eye(5)),
        'within_one_agreement': weighted((np.abs(DIFF) <= 1).astype(float)),
        'macro_f1': f1.mean(axis=-1),
    }


def build_confusions(indices, humans, rubric_keys, key_names, predictions):
    """Use bincount tables rather than the archived nested score accumulation."""
    nitems = int(indices.max()) + 1
    nmodels = predictions.shape[1]
    conf = np.zeros((nitems, nmodels, len(key_names), 2, 5, 5))
    human_conf = np.zeros((nitems, len(key_names), 5, 5))
    loss = np.full((nitems, nmodels, len(key_names)), np.nan)
    lookup = {key: i for i, key in enumerate(key_names)}
    for item in range(nitems):
        selected = np.flatnonzero(indices == item)
        seen_keys = set()
        for slot in range(8):
            keys = set(rubric_keys[selected, slot])
            if len(keys) != 1:
                raise ValueError('Rubric key changes within an item')
            key = keys.pop()
            if key in seen_keys:
                raise ValueError('Duplicate rubric key within an item')
            seen_keys.add(key)
            c = lookup[key]
            h = humans[selected, slot]
            human_conf[item, c] = np.bincount((h[:, 0] - 1) * 5 + h[:, 1] - 1,
                                             minlength=25).reshape(5, 5) / len(selected)
            for m in range(nmodels):
                p = predictions[selected, m, slot]
                valid = np.isfinite(p)
                if valid.any():
                    for r in range(2):
                        pairs = (p[valid].astype(int) - 1) * 5 + h[valid, r] - 1
                        conf[item, m, c, r] = np.bincount(pairs, minlength=25).reshape(5, 5) / valid.sum()
                errors = np.ones(len(selected))
                errors[valid] = ((p[valid, None] - h[valid]) ** 2 / 16).mean(axis=-1)
                loss[item, m, c] = errors.mean()
    return conf, human_conf, loss


def bootstrap_from_weights(conf, loss, weights):
    shape = conf.shape[1:]
    flat = conf.reshape(len(conf), -1)
    support = np.isfinite(loss).reshape(len(conf), -1).astype(float)
    values = np.nan_to_num(loss).reshape(len(conf), -1)
    qs = np.empty((len(weights), *shape[:2]))
    ls = np.empty_like(qs)
    for start in range(0, len(weights), 128):
        w = weights[start:start + 128]
        combined = (w @ flat).reshape(len(w), *shape)
        qs[start:start + len(w)] = qwk(combined).mean(axis=-1)
        with np.errstate(divide='ignore', invalid='ignore'):
            ls[start:start + len(w)] = ((w @ values) / (w @ support)).reshape(len(w), *shape[:2])
    if not np.isfinite(qs).all() or not np.isfinite(ls).all():
        raise ValueError('Undefined bootstrap quantity; no silent replacement/discard')
    return qs, ls


def ci(values):
    return np.percentile(values, [2.5, 97.5], axis=0).T.tolist()


def load_evaluation(family):
    manifest_path = ROOT / f'artifacts/manifests/{family}_evaluation_v1.jsonl'
    manifest = [json.loads(line) for line in manifest_path.read_text(encoding='utf-8').splitlines()]
    item_names = sorted({row['item_id'] for row in manifest})
    lookup = {key: i for i, key in enumerate(item_names)}
    indices = np.array([lookup[row['item_id']] for row in manifest])
    humans = np.empty((len(manifest), 8, 2), dtype=int)
    rubric_keys = np.empty((len(manifest), 8), dtype=object)
    training_keys = np.empty_like(rubric_keys)
    normalized_hashes = []
    prompt_hashes = []
    sources = {}
    try:
        for i, pointer in enumerate(manifest):
            assert pointer['source_split'] == 'Validation'
            path = (ROOT / pointer['zip_path']).resolve()
            assert ROOT in path.parents
            if path not in sources:
                sources[path] = zipfile.ZipFile(path)
            record = read_json_member(sources[path], pointer['member'])
            answer = str(record['essay_answer']['text'])
            assert hashlib.sha256(answer.encode('utf-8')).hexdigest() == pointer['content_sha256']
            assert str(record['essay_question']['id']) == pointer['item_id']
            assert str(record['essay_answer']['id']) == pointer['answer_id']
            humans[i] = source_labels(record)
            for c, criterion in enumerate(CRITERIA):
                key = record['rubric']['analytic'][criterion]['rubric_key']
                training_keys[i, c] = key
                rubric_keys[i, c] = criterion if family == 'constructed' else key
            normalized_hashes.append(normalized_digest(answer))
            prompt_hashes.append(render_prompt(record, ROOT / 'configs/paper1_prompt_v1.txt').prompt_sha256)
    finally:
        for source in sources.values():
            source.close()
    assert len({p['record_id'] for p in manifest}) == len(manifest)
    return manifest, item_names, indices, humans, rubric_keys, training_keys, normalized_hashes, prompt_hashes


def load_predictions(family, manifest, prompt_hashes):
    lookup = {row['record_id']: i for i, row in enumerate(manifest)}
    names = list(archived.paths_for(family))
    predictions = np.full((len(manifest), len(names), 8), np.nan)
    checks = Counter()
    for m, (name, path) in enumerate(archived.paths_for(family).items()):
        seen = set()
        with path.open(encoding='utf-8') as stream:
            for line in stream:
                row = json.loads(line)
                rid = row['record_id']
                assert row.get('provider') != 'mock'
                assert rid in lookup and rid not in seen
                seen.add(rid)
                i = lookup[rid]
                assert str(row['item_id']) == manifest[i]['item_id']
                assert str(row['answer_id']) in (rid, manifest[i]['answer_id'])
                assert row['prompt_sha256'] == prompt_hashes[i]
                checks['record_and_prompt_checks'] += 1
                if row['status'] == 'ok':
                    parsed = parse_scores(row['raw_output'])
                    assert parsed == row['scores'] and set(parsed) == set(CRITERIA)
                    for c, criterion in enumerate(CRITERIA):
                        value = parsed[criterion]
                        assert type(value) is int and 1 <= value <= 5
                        predictions[i, m, c] = value
                    checks['raw_outputs_reparsed'] += 1
                else:
                    assert row['status'] == 'error'
                    checks['retained_error_outputs'] += 1
        assert seen == set(lookup)
    return names, predictions, dict(checks)


def training_baselines(family, manifest, training_keys, evaluation_hashes):
    item_counts = defaultdict(lambda: np.zeros(5, dtype=int))
    rubric_counts = defaultdict(lambda: np.zeros(5, dtype=int))
    evaluation_set = set(evaluation_hashes)
    seen_ids = set()
    counts = Counter()
    archive_hashes = {}
    for path in locate_label_zips(ROOT, DATASETS[family]['root'], 'Training'):
        archive_hashes[str(path.relative_to(ROOT))] = sha(path)
        with zipfile.ZipFile(path) as archive:
            for member in sorted(n for n in archive.namelist() if n.lower().endswith('.json')):
                record = read_json_member(archive, member)
                item = str(record['essay_question']['id'])
                identity = (item, str(record['essay_answer']['id']))
                assert identity not in seen_ids
                seen_ids.add(identity)
                counts['training_records_scanned'] += 1
                if normalized_digest(record['essay_answer']['text']) in evaluation_set:
                    counts['training_records_excluded_for_evaluation_text_overlap'] += 1
                    continue
                labels = source_labels(record)
                for c, criterion in enumerate(CRITERIA):
                    key = record['rubric']['analytic'][criterion]['rubric_key']
                    frequency = np.bincount(labels[c] - 1, minlength=5)
                    item_counts[(item, key)] += frequency
                    rubric_counts[key] += frequency
                counts['training_records_retained'] += 1
    assert counts['training_records_scanned'] == DATASETS[family]['expected']['Training']
    output = np.empty((len(manifest), 4, 8), dtype=float)
    fitted = {}
    for i, row in enumerate(manifest):
        for c, key in enumerate(training_keys[i]):
            global_counts = rubric_counts[key]
            assert global_counts.sum() > 0
            local_counts = item_counts[(row['item_id'], key)]
            if not local_counts.sum():
                local_counts = global_counts
                counts['fallback_response_criterion_cells'] += 1
            global_mode = int(global_counts.argmax() + 1)
            local_mode = int(local_counts.argmax() + 1)
            mean = float(local_counts @ GRID / local_counts.sum())
            rounded = int(np.floor(mean + .5))
            output[i, :, c] = [3, global_mode, local_mode, rounded]
            fitted[f"{row['item_id']}|{key}"] = {
                'training_rater_observations': int(local_counts.sum()),
                'rubric_mode': global_mode, 'item_mode': local_mode,
                'item_mean': mean, 'item_rounded_mean': rounded}
    frequencies = Counter(evaluation_hashes)
    counts['evaluation_unique_normalized_texts'] = len(frequencies)
    counts['evaluation_duplicate_text_groups'] = sum(n > 1 for n in frequencies.values())
    counts['evaluation_records_in_duplicate_text_groups'] = sum(n for n in frequencies.values() if n > 1)
    for key in ('training_records_excluded_for_evaluation_text_overlap', 'fallback_response_criterion_cells'):
        counts.setdefault(key, 0)
    return output, {'counts': dict(counts), 'training_archive_sha256': archive_hashes,
                    'fitted_rules': fitted,
                    'training_label_use': 'Both raters pooled with equal weight; no evaluation labels used',
                    'uncertainty': 'Conditional on fitted Training rules; Training is not resampled'}


def check_close(left, right, label, errors):
    left, right = np.asarray(left, dtype=float), np.asarray(right, dtype=float)
    assert left.shape == right.shape, label
    assert np.isfinite(left).all() and np.isfinite(right).all(), label
    error = float(np.max(np.abs(left - right)))
    if not np.allclose(left, right, rtol=0, atol=2e-10):
        raise AssertionError(f'{label}: max absolute discrepancy {error}')
    errors[label] = error


def independent_inference_checks(result, boot):
    errors = {}
    x = np.log2(archived.PARAMETERS)
    x = (x - x.mean()) / x.std()
    for label, variant in result['jdi_variants'].items():
        z = np.asarray(variant['jdi'], dtype=float)
        z = (z - z.mean()) / z.std()
        for metric, stored_key in [('qwk', 'qwk'), ('loss', 'normalized_loss')]:
            slopes = x @ boot[metric][:6] / (x @ x)
            sampled_slopes = np.einsum('m,bmc->bc', x, boot[f'{metric}_boot'][:, :6]) / (x @ x)
            beta = slopes @ z / (z @ z)
            draws = sampled_slopes @ z / (z @ z)
            reference = variant[stored_key]
            check_close(beta, reference['scale_by_jdi']['estimate'], f'{label}/{metric}/beta', errors)
            check_close(ci(draws), reference['scale_by_jdi']['ci95_two_sided'], f'{label}/{metric}/ci', errors)
            contrasts = slopes[1:] - slopes[0]
            boot_contrasts = sampled_slopes[:, 1:] - sampled_slopes[:, [0]]
            covariance = np.cov(boot_contrasts, rowvar=False)
            statistic = contrasts @ np.linalg.pinv(covariance) @ contrasts
            check_close(statistic, reference['scale_by_criterion']['wald'], f'{label}/{metric}/wald', errors)
    if result['family'] == 'constructed':
        differences = boot['qwk'][:6] - np.median(boot['qwk'][6:10], axis=0)
        sampled = boot['qwk_boot'][:, :6] - np.median(boot['qwk_boot'][:, 6:10], axis=1)[:, None, :]
        for margin in (.05, .03):
            p = (np.sum(sampled <= -margin, axis=0) + 1) / (len(sampled) + 1)
            flat = p.ravel()
            order = np.argsort(flat, kind='stable')
            corrected = np.empty_like(flat)
            corrected[order] = np.minimum(1, np.maximum.accumulate(flat[order] * np.arange(48, 0, -1)))
            corrected = corrected.reshape(6, 8)
            lower = np.percentile(sampled, 5, axis=0)
            for c, criterion in enumerate(result['rubric_keys']):
                entry = result['noninferiority']['all_48_holm'][str(margin)][criterion]
                minimum = None
                active = True
                for m in range(5, -1, -1):
                    name = archived.QWEN[m]
                    stored = entry['sizes'][name]
                    check_close([differences[m, c], p[m, c], corrected[m, c], lower[m, c]],
                                [stored['delta'], stored['raw_p'], stored['holm_48_p'], stored['nominal_one_sided_95_lower']],
                                f'ni/{margin}/{name}/{criterion}', errors)
                    passed = bool(differences[m, c] > -margin and corrected[m, c] < .05 and lower[m, c] > -margin)
                    assert passed == stored['pass_holm']
                    reached = active and passed
                    assert reached == stored['descending_sequence_pass']
                    if reached:
                        minimum = name
                    else:
                        active = False
                assert minimum == entry['minimum_sufficient']
    return errors


def residual_sensitivity(boot):
    x = np.log2(archived.PARAMETERS)
    k = np.log2(archived.KPARAMETERS)
    interpolation = np.zeros((4, 6))
    for i, value in enumerate(k):
        right = int(np.searchsorted(x, value))
        assert 0 < right < len(x)
        fraction = (value - x[right - 1]) / (x[right] - x[right - 1])
        interpolation[i, right - 1] = 1 - fraction
        interpolation[i, right] = fraction
    output = {}
    for metric in ('qwk', 'loss'):
        residual = boot[metric][10:14] - interpolation @ boot[metric][:6]
        sampled = boot[f'{metric}_boot'][:, 10:14] - np.einsum('km,bmc->bkc', interpolation, boot[f'{metric}_boot'][:, :6])
        mean = residual.mean(axis=1)
        samples = sampled.mean(axis=2)
        radius = np.percentile(np.max(np.abs(samples - mean), axis=1), 95)
        output[metric] = {model: {'mean_residual': float(mean[i]),
                                  'simultaneous_mean_ci95': [float(mean[i] - radius), float(mean[i] + radius)]}
                          for i, model in enumerate(archived.KOREAN)}
    return {'status': 'post hoc functional-form sensitivity, all four Korean models reported',
            'curve': 'Piecewise-linear interpolation between neighboring Qwen sizes in log2 parameter count',
            'interpolation_weights': interpolation.tolist(), 'results': output}


def verify_family(family, out):
    result = read_json(OLD / f'{family}_results.json')
    with np.load(OLD / f'{family}_bootstrap.npz') as stream:
        boot = {key: stream[key] for key in stream.files}
    manifest, items, indices, humans, keys, training_keys, normalized_hashes, prompt_hashes = load_evaluation(family)
    names, predictions, raw_checks = load_predictions(family, manifest, prompt_hashes)
    assert names == result['models']
    conf, human_conf, loss = build_confusions(indices, humans, keys, result['rubric_keys'], predictions)
    values = metrics(conf, loss)
    errors = {}
    check_close(values['qwk'], boot['qwk'], 'all_model_rater_mean_qwk', errors)
    check_close(np.stack([values['qwk_h1'], values['qwk_h2']], axis=-1), boot['qwk_by_rater'], 'each_rater_qwk', errors)
    check_close(qwk(human_conf.sum(axis=0)), boot['human'], 'human_qwk', errors)
    check_close(values['normalized_squared_loss'], boot['loss'], 'intent_to_score_loss', errors)
    for c, key in enumerate(result['rubric_keys']):
        for m, model in enumerate(names):
            row = next(row for row in result['cells'] if row['model'] == model and row['rubric'] == key)
            for metric, array in values.items():
                check_close(array[m, c], row[metric], f'cell/{model}/{key}/{metric}', errors)
    seed = result['bootstrap_seed']
    weights = np.random.default_rng(seed).multinomial(len(items), np.full(len(items), 1 / len(items)), size=9999)
    assert np.array_equal(weights, boot['multiplicities'])
    selected = np.unique(np.linspace(0, len(weights) - 1, 64, dtype=int))
    qcheck, lcheck = bootstrap_from_weights(conf, loss, weights[selected])
    check_close(qcheck, boot['qwk_boot'][selected], '64_independent_qwk_bootstrap_draws', errors)
    check_close(lcheck, boot['loss_boot'][selected], '64_independent_loss_bootstrap_draws', errors)
    errors.update(independent_inference_checks(result, boot))
    print(f'{family}: numerical audit passed ({len(errors)} checks)', flush=True)

    baseline_scores, fit = training_baselines(family, manifest, training_keys, normalized_hashes)
    bc, _, bl = build_confusions(indices, humans, keys, result['rubric_keys'], baseline_scores)
    bv = metrics(bc, bl)
    bq, bs = bootstrap_from_weights(bc, bl, weights)
    summary = []
    cells = []
    comparisons = []
    for b, name in enumerate(BASELINES):
        summary.append({'baseline': name, 'mean_qwk': float(bv['qwk'][b].mean()),
                        'mean_qwk_ci95': ci(bq[:, b].mean(axis=1)),
                        'mean_loss': float(bv['normalized_squared_loss'][b].mean()),
                        'mean_loss_ci95': ci(bs[:, b].mean(axis=1)),
                        'mean_mae': float(bv['mae'][b].mean()),
                        'mean_exact_agreement': float(bv['exact_agreement'][b].mean())})
        for c, key in enumerate(result['rubric_keys']):
            cells.append({'baseline': name, 'rubric': key,
                          **{metric: float(array[b, c]) for metric, array in bv.items()},
                          'qwk_ci95': ci(bq[:, b, c]), 'loss_ci95': ci(bs[:, b, c])})
        for m, model in enumerate(names):
            comparisons.append({'baseline': name, 'model': model,
                                'model_minus_baseline_mean_qwk': float((boot['qwk'][m] - bv['qwk'][b]).mean()),
                                'qwk_difference_ci95_unadjusted': ci((boot['qwk_boot'][:, m] - bq[:, b]).mean(axis=1)),
                                'model_minus_baseline_mean_loss': float((boot['loss'][m] - bv['normalized_squared_loss'][b]).mean()),
                                'loss_difference_ci95_unadjusted': ci((boot['loss_boot'][:, m] - bs[:, b]).mean(axis=1))})
    output = {'family': family, 'records': len(manifest), 'items': len(items),
              'status': 'post-outcome numerical verification and exploratory controls',
              'checks': raw_checks, 'numerical_check_count': len(errors),
              'largest_absolute_numerical_discrepancy': max(errors.values()),
              'all_9999_seeded_multiplicities_match': True,
              'independently_recomputed_bootstrap_draws': selected.tolist(),
              'numerical_errors': errors, 'baseline_training': fit,
              'baseline_summary': summary, 'baseline_cells': cells,
              'paired_comparisons': comparisons,
              'comparison_scope': 'Descriptive unadjusted intervals, conditional on fitted training rules; item controls have training-label access unavailable to zero-shot LLMs'}
    if family == 'constructed':
        output['korean_residual_curve_sensitivity'] = residual_sensitivity(boot)
    save(out / f'{family}_verification.json', output)
    np.savez_compressed(out / f'{family}_baseline_bootstrap.npz', qwk=bv['qwk'], loss=bv['normalized_squared_loss'], qwk_boot=bq, loss_boot=bs)
    print(f'{family}: all four baseline rules saved', flush=True)
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', type=Path, default=DEFAULT_OUT)
    args = parser.parse_args()
    out = args.output_dir.resolve()
    assert ROOT in out.parents
    out.mkdir(parents=True, exist_ok=True)
    if (out / 'audit_manifest.json').exists():
        raise ValueError('Use a fresh output directory; do not overwrite a recorded audit')
    frozen = read_json(OLD / 'preunblinding_freeze.json')
    protected = {ROOT / name: digest for name, digest in frozen['inputs'].items()}
    protected[ROOT / 'scripts/run_paper1_qualified_analysis.py'] = frozen['script_sha256']
    completion = read_json(OLD / 'completion.json')
    for family, digest in completion['result_sha256'].items():
        protected[OLD / f'{family}_results.json'] = digest
    for path in OLD.glob('*'):
        if path.is_file():
            protected.setdefault(path, sha(path))
    for path, digest in protected.items():
        assert sha(path) == digest, f'Protected input changed: {path.name}'
    manifest = {'created_at_utc': datetime.now(timezone.utc).isoformat(),
                'status': 'Post hoc; original model outcomes were already known',
                'script_sha256': sha(Path(__file__)),
                'amendment_014_sha256': sha(ROOT / 'reports/paper1_amendment_014.md'),
                'protected_files': {str(path.relative_to(ROOT)): digest for path, digest in protected.items()},
                'new_inference_calls': 0, 'external_student_data_transfers': 0}
    save(out / 'audit_manifest.json', manifest)
    for family in ('constructed', 'essay'):
        verify_family(family, out)
    for path, digest in protected.items():
        assert sha(path) == digest
    save(out / 'completion.json', {'completed_at_utc': datetime.now(timezone.utc).isoformat(),
                                   'protected_files_unchanged': len(protected),
                                   'new_inference_calls': 0,
                                   'result_sha256': {family: sha(out / f'{family}_verification.json') for family in ('constructed', 'essay')}})
    print('Audit complete; archived evidence unchanged; no paid or network inference', flush=True)


if __name__ == '__main__':
    main()
