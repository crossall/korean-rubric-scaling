#!/usr/bin/env python3
"""Deterministic batched BF16 inference for Paper 1 local Hugging Face models.

Designed for a single 80GB RunPod GPU.  The script is resume-safe and keeps the
licensed response text only in memory; output rows store IDs, score-only model
output, token counts, timing, and version metadata.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from paper1_prompting import (
    load_json_member,
    make_repair_prompt,
    parse_scores,
    read_manifest,
    render_prompt,
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def completed_ids(path: Path) -> set[str]:
    completed: set[str] = set()
    if not path.exists():
        return completed
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            if line.strip():
                row = json.loads(line)
                if row.get("status") == "ok":
                    completed.add(row["record_id"])
    return completed


def chunks(rows: list[Any], size: int):
    for start in range(0, len(rows), size):
        yield rows[start : start + size]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", required=True)
    parser.add_argument("--revision", required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--workspace", type=Path, default=Path(__file__).resolve().parents[1]
    )
    parser.add_argument(
        "--prompt", type=Path, default=Path("configs/paper1_prompt_v1.txt")
    )
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--max-input-tokens", type=int, default=8064)
    parser.add_argument("--max-new-tokens", type=int, default=128)
    parser.add_argument("--dtype", choices=("bfloat16", "float16"), default="bfloat16")
    parser.add_argument("--trust-remote-code", action="store_true")
    parser.add_argument("--limit", type=int, default=None)
    parser.add_argument("--dry-run", action="store_true")
    return parser.parse_args()


def resolve(workspace: Path, path: Path) -> Path:
    return path.resolve() if path.is_absolute() else (workspace / path).resolve()


def main() -> int:
    args = parse_args()
    workspace = args.workspace.resolve()
    manifest_path = resolve(workspace, args.manifest)
    output_path = resolve(workspace, args.output)
    prompt_path = resolve(workspace, args.prompt)
    rows = read_manifest(manifest_path)
    if args.limit is not None:
        rows = rows[: args.limit]
    if args.batch_size < 1:
        print("ERROR: --batch-size must be positive", file=sys.stderr)
        return 2

    preview = []
    for pointer in rows[: min(3, len(rows))]:
        record = load_json_member(workspace, pointer)
        prompt = render_prompt(record, prompt_path)
        preview.append(
            {
                "record_id": pointer["record_id"],
                "prompt_sha256": prompt.prompt_sha256,
                "prompt_characters": len(prompt.system) + len(prompt.user),
            }
        )
    if args.dry_run:
        print(
            json.dumps(
                {
                    "model": args.model,
                    "revision": args.revision,
                    "records": len(rows),
                    "preview": preview,
                    "response_text_printed": False,
                },
                indent=2,
            )
        )
        return 0

    try:
        import torch
        import transformers
        from transformers import AutoModelForCausalLM, AutoTokenizer
    except ImportError as exc:
        print(f"ERROR: PyTorch/Transformers dependencies missing: {exc}", file=sys.stderr)
        return 2
    if not torch.cuda.is_available():
        print("ERROR: CUDA GPU is required", file=sys.stderr)
        return 2
    if args.dtype == "bfloat16" and not torch.cuda.is_bf16_supported():
        print("ERROR: GPU does not support required bfloat16 inference", file=sys.stderr)
        return 2

    torch_dtype = torch.bfloat16 if args.dtype == "bfloat16" else torch.float16
    torch.manual_seed(20260903)
    torch.cuda.manual_seed_all(20260903)
    tokenizer = AutoTokenizer.from_pretrained(
        args.model,
        revision=args.revision,
        trust_remote_code=args.trust_remote_code,
        token=os.environ.get("HF_TOKEN") or None,
    )
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token_id = tokenizer.eos_token_id
    tokenizer.padding_side = "left"
    model = AutoModelForCausalLM.from_pretrained(
        args.model,
        revision=args.revision,
        torch_dtype=torch_dtype,
        device_map={"": 0},
        low_cpu_mem_usage=True,
        trust_remote_code=args.trust_remote_code,
        token=os.environ.get("HF_TOKEN") or None,
    )
    model.eval()
    torch.cuda.reset_peak_memory_stats()

    def chat_text(prompt) -> str:
        return tokenizer.apply_chat_template(
            [
                {"role": "system", "content": prompt.system},
                {"role": "user", "content": prompt.user},
            ],
            tokenize=False,
            add_generation_prompt=True,
            enable_thinking=False,
        )

    def generate(prompts) -> tuple[list[str], list[int], list[int], float]:
        texts = [chat_text(prompt) for prompt in prompts]
        encoded = tokenizer(
            texts,
            return_tensors="pt",
            padding=True,
            truncation=True,
            max_length=args.max_input_tokens,
            add_special_tokens=False,
        )
        lengths = encoded["attention_mask"].sum(dim=1).tolist()
        if any(length >= args.max_input_tokens for length in lengths):
            raise ValueError("At least one prompt reached the input truncation boundary")
        # Some decoder-only remote-code tokenizers emit token_type_ids even though
        # their causal LM forward/generate signatures do not consume them (for
        # example Mi:dm 2.0 Mini).  Removing this unused tokenizer artifact leaves
        # the actual token sequence and attention mask unchanged.
        encoded.pop("token_type_ids", None)
        encoded = {name: value.to("cuda") for name, value in encoded.items()}
        torch.cuda.synchronize()
        started = time.perf_counter()
        with torch.inference_mode():
            generated = model.generate(
                **encoded,
                max_new_tokens=args.max_new_tokens,
                do_sample=False,
                use_cache=True,
                pad_token_id=tokenizer.pad_token_id,
                eos_token_id=tokenizer.eos_token_id,
            )
        torch.cuda.synchronize()
        elapsed = time.perf_counter() - started
        new_tokens = generated[:, encoded["input_ids"].shape[1] :]
        decoded = tokenizer.batch_decode(new_tokens, skip_special_tokens=True)
        output_lengths = [
            int((sequence != tokenizer.pad_token_id).sum().item()) for sequence in new_tokens
        ]
        return decoded, [int(value) for value in lengths], output_lengths, elapsed

    output_path.parent.mkdir(parents=True, exist_ok=True)
    meta_path = output_path.with_suffix(output_path.suffix + ".meta.json")
    existing = completed_ids(output_path)
    pending = [row for row in rows if row["record_id"] not in existing]
    initial_meta = {
        "schema_version": 1,
        "status": "running",
        "started_at_utc": datetime.now(timezone.utc).isoformat(),
        "model": args.model,
        "requested_revision": args.revision,
        "loaded_commit_hash": getattr(model.config, "_commit_hash", None),
        "manifest_path": str(manifest_path),
        "manifest_sha256": sha256(manifest_path),
        "prompt_template_sha256": sha256(prompt_path),
        "dtype": args.dtype,
        "batch_size": args.batch_size,
        "max_input_tokens": args.max_input_tokens,
        "max_new_tokens": args.max_new_tokens,
        "seed": 20260903,
        "do_sample": False,
        "enable_thinking": False,
        "trust_remote_code": args.trust_remote_code,
        "torch_version": torch.__version__,
        "transformers_version": transformers.__version__,
        "python_version": platform.python_version(),
        "gpu": torch.cuda.get_device_name(0),
        "total_records": len(rows),
        "already_complete": len(existing),
        "pending": len(pending),
    }
    meta_path.write_text(
        json.dumps(initial_meta, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print(
        f"model={args.model} total={len(rows)} already_ok={len(existing)} "
        f"pending={len(pending)} batch_size={args.batch_size}"
    )
    total_elapsed = 0.0
    total_input_tokens = 0
    total_output_tokens = 0
    repaired = 0
    errors = 0
    completed = 0
    with output_path.open("a", encoding="utf-8", newline="\n") as handle:
        for batch_number, batch in enumerate(chunks(pending, args.batch_size), 1):
            prompts = [
                render_prompt(load_json_member(workspace, pointer), prompt_path)
                for pointer in batch
            ]
            batch_started = time.perf_counter()
            try:
                outputs, input_lengths, output_lengths, generation_seconds = generate(prompts)
                total_elapsed += generation_seconds
                total_input_tokens += sum(input_lengths)
                total_output_tokens += sum(output_lengths)
                results: list[dict[str, Any]] = []
                invalid: list[int] = []
                for index, output in enumerate(outputs):
                    try:
                        score = parse_scores(output)
                        parse_error = None
                    except (ValueError, json.JSONDecodeError) as exc:
                        invalid.append(index)
                        score = {}
                        parse_error = f"{type(exc).__name__}: {str(exc)[:240]}"
                    results.append(
                        {
                            "raw_output": output,
                            "first_raw_output": None,
                            "scores": score,
                            "parse_error": parse_error,
                            "repair_used": False,
                            "repair_prompt_sha256": None,
                        }
                    )
                if invalid:
                    repair_prompts = [make_repair_prompt(prompts[index], prompt_path) for index in invalid]
                    repair_outputs, repair_inputs, repair_output_lengths, repair_seconds = generate(
                        repair_prompts
                    )
                    total_elapsed += repair_seconds
                    total_input_tokens += sum(repair_inputs)
                    total_output_tokens += sum(repair_output_lengths)
                    for repair_index, original_index in enumerate(invalid):
                        results[original_index]["first_raw_output"] = results[original_index][
                            "raw_output"
                        ]
                        results[original_index]["raw_output"] = repair_outputs[repair_index]
                        results[original_index]["repair_used"] = True
                        results[original_index]["repair_prompt_sha256"] = repair_prompts[
                            repair_index
                        ].prompt_sha256
                        try:
                            results[original_index]["scores"] = parse_scores(
                                repair_outputs[repair_index]
                            )
                            results[original_index]["parse_error"] = None
                            repaired += 1
                        except (ValueError, json.JSONDecodeError) as exc:
                            results[original_index]["parse_error"] = (
                                f"{type(exc).__name__}: {str(exc)[:240]}"
                            )
                amortized_latency = generation_seconds / len(batch)
                for index, pointer in enumerate(batch):
                    result = results[index]
                    parse_error = result.pop("parse_error")
                    row = {
                        "record_id": pointer["record_id"],
                        "item_id": pointer["item_id"],
                        "answer_id": pointer["answer_id"],
                        "dataset": pointer["dataset"],
                        "provider": "transformers",
                        "requested_model": args.model,
                        "returned_model": args.model,
                        "requested_revision": args.revision,
                        "loaded_commit_hash": getattr(model.config, "_commit_hash", None),
                        "status": "error" if parse_error else "ok",
                        **result,
                        "prompt_sha256": prompts[index].prompt_sha256,
                        "input_tokens": input_lengths[index],
                        "output_tokens": output_lengths[index],
                        "batch_number": batch_number,
                        "batch_size_actual": len(batch),
                        "batch_generation_seconds": round(generation_seconds, 6),
                        "amortized_latency_seconds": round(amortized_latency, 6),
                        "completed_at_utc": datetime.now(timezone.utc).isoformat(),
                    }
                    if parse_error:
                        row["error_type"] = "ScoreParseError"
                        row["error"] = parse_error
                        row.pop("scores", None)
                        errors += 1
                    else:
                        completed += 1
                    handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")
            except Exception as exc:
                errors += len(batch)
                for index, pointer in enumerate(batch):
                    row = {
                        "record_id": pointer["record_id"],
                        "item_id": pointer["item_id"],
                        "answer_id": pointer["answer_id"],
                        "dataset": pointer["dataset"],
                        "provider": "transformers",
                        "requested_model": args.model,
                        "requested_revision": args.revision,
                        "status": "error",
                        "error_type": type(exc).__name__,
                        "error": str(exc)[:300],
                        "prompt_sha256": prompts[index].prompt_sha256,
                        "batch_number": batch_number,
                        "completed_at_utc": datetime.now(timezone.utc).isoformat(),
                    }
                    handle.write(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n")
            handle.flush()
            if batch_number % 10 == 0 or completed + errors == len(pending):
                wall = time.perf_counter() - batch_started
                print(
                    f"processed={completed + errors}/{len(pending)} ok={completed} "
                    f"errors={errors} repaired={repaired} last_batch_wall={wall:.2f}s"
                )

    final_meta = {
        **initial_meta,
        "status": "complete" if errors == 0 else "complete_with_errors",
        "completed_at_utc": datetime.now(timezone.utc).isoformat(),
        "newly_completed": completed,
        "errors": errors,
        "repaired": repaired,
        "generation_seconds": round(total_elapsed, 6),
        "input_tokens": total_input_tokens,
        "output_tokens": total_output_tokens,
        "input_tokens_per_second": (
            round(total_input_tokens / total_elapsed, 3) if total_elapsed else None
        ),
        "peak_vram_bytes": int(torch.cuda.max_memory_allocated()),
    }
    meta_path.write_text(
        json.dumps(final_meta, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    print(
        f"status={final_meta['status']} peak_vram_gib="
        f"{final_meta['peak_vram_bytes'] / 1024**3:.2f} "
        f"generation_seconds={total_elapsed:.1f}"
    )
    return 0 if errors == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
