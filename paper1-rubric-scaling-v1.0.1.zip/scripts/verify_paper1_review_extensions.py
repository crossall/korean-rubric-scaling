"""Recalculate new point estimates using direct row weights and sklearn QWK."""
import json
import run_paper1_review_extensions as r
from sklearn.metrics import cohen_kappa_score
np, v = r.np, r.v


def main():
    checks = 0
    discrepancy = 0.0
    for family in ('constructed', 'essay'):
        result = v.read_json(r.OUT/f'{family}_review_diagnostics.json')
        manifest, items, indices, human, keys, training_keys, hashes, prompt_hashes = v.load_evaluation(family)
        names, pred, _ = v.load_predictions(family, manifest, prompt_hashes)
        for row in result['human_distributions']:
            mask = keys == row['rubric']
            weights = np.zeros_like(mask, dtype=float)
            for item in np.unique(indices):
                chosen = mask & (indices[:,None] == item)
                if chosen.any():
                    weights[chosen] = 1/chosen.sum()
            weights /= weights.sum()
            for slot in range(2):
                probs = np.array([weights[human[:,:,slot] == value].sum() for value in range(1,6)])
                actual = row[f'score_probabilities_h{slot+1}']
                np.testing.assert_allclose(probs, actual, atol=1e-13, rtol=0)
                discrepancy = max(discrepancy, float(np.max(np.abs(probs-actual))))
                checks += 5
        for row in result['model_rater_cells']:
            if row['model'] not in names:
                continue
            p = pred[:,names.index(row['model'])]
            applicable = keys == row['rubric']
            valid = applicable & np.isfinite(p)
            weight = np.zeros_like(p)
            loss_weight = np.zeros_like(p)
            for item in np.unique(indices):
                chosen = valid & (indices[:,None] == item)
                full = applicable & (indices[:,None] == item)
                if chosen.any():
                    weight[chosen] = 1/chosen.sum()
                if full.any():
                    loss_weight[full] = 1/full.sum()
            for slot in range(2):
                expected_q = cohen_kappa_score(human[:,:,slot][valid], p[valid], labels=[1,2,3,4,5],
                                             weights='quadratic', sample_weight=weight[valid])
                errs = np.where(np.isfinite(p), (p-human[:,:,slot])**2/16, 1)
                expected_l = float((errs*loss_weight).sum()/loss_weight.sum())
                for expected, actual in [(expected_q,row[f'qwk_h{slot+1}']), (expected_l,row[f'loss_h{slot+1}'])]:
                    np.testing.assert_allclose(expected, actual, atol=1e-12, rtol=0)
                    discrepancy = max(discrepancy, abs(float(expected)-actual))
                    checks += 1
    v.save(r.OUT/'independent_point_verification.json',dict(scalar_checks=checks,
           maximum_absolute_discrepancy=discrepancy, independent_QWK='sklearn weighted quadratic kappa with direct response weights',
           raw_rows_exported=0, new_inference_calls=0))
    print(json.dumps(dict(checks=checks,maximum_absolute_discrepancy=discrepancy)))


if __name__ == '__main__':
    main()
