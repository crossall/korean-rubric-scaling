#!/usr/bin/env python3
"""Run the preregistered Paper 1 constructed-response QWK analysis.

The paired item-cluster bootstrap operates on pre-aggregated 5x5 item confusion
matrices, making 9,999 resamples practical while preserving every response in a
sampled item.  This script never exposes response text in its outputs.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
from scipy.stats import chi2

from paper1_prompting import CRITERIA, human_scores, load_json_member, read_manifest


QUADRATIC_WEIGHTS = (
    np.subtract.outer(np.arange(5, dtype=float), np.arange(5, dtype=float)) ** 2 / 16.0
)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def parse_mapping(values: list[str], value_type: type) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for value in values:
        if "=" not in value:
            raise ValueError(f"Expected NAME=VALUE, got {value}")
        name, raw = value.split("=", 1)
        if not name or name in result:
            raise ValueError(f"Missing or duplicate name: {name}")
        result[name] = value_type(raw)
    return result


def read_prediction_file(path: Path, allow_mock: bool) -> dict[str, dict[str, Any]]:
    rows: dict[str, dict[str, Any]] = {}
    with path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, 1):
            if not line.strip():
                continue
            row = json.loads(line)
            if row.get("provider") == "mock" and not allow_mock:
                raise ValueError(f"Mock result rejected: {path}:{line_number}")
            record_id = row["record_id"]
            previous = rows.get(record_id)
            if previous is None or row.get("status") == "ok":
                rows[record_id] = row
    return rows


def weighted_qwk_from_confusion(confusion: np.ndarray) -> float:
    total = float(confusion.sum())
    if total <= 0:
        return float("nan")
    row = confusion.sum(axis=1)
    column = confusion.sum(axis=0)
    expected = np.outer(row, column) / total
    denominator = float((QUADRATIC_WEIGHTS * expected).sum())
    if denominator <= 0:
        return float("nan")
    return 1.0 - float((QUADRATIC_WEIGHTS * confusion).sum()) / denominator


def model_agreement_from_confusions(confusions: np.ndarray) -> np.ndarray:
    """Return mean model-human QWK from [item,model,criterion,rater,5,5]."""
    combined = confusions.sum(axis=0)
    model_count, criterion_count, rater_count = combined.shape[:3]
    result = np.empty((model_count, criterion_count, rater_count), dtype=float)
    for model in range(model_count):
        for criterion in range(criterion_count):
            for rater in range(rater_count):
                result[model, criterion, rater] = weighted_qwk_from_confusion(
                    combined[model, criterion, rater]
                )
    return result.mean(axis=2)


def human_agreement_from_confusions(confusions: np.ndarray) -> np.ndarray:
    combined = confusions.sum(axis=0)
    return np.array([weighted_qwk_from_confusion(matrix) for matrix in combined])


def bootstrap_human_agreement(
    confusions: np.ndarray, repetitions: int, seed: int
) -> tuple[np.ndarray, np.ndarray]:
    """Return human-human QWK and paired item-bootstrap percentile intervals."""
    observed = human_agreement_from_confusions(confusions)
    item_count, criterion_count = confusions.shape[:2]
    samples = np.empty((repetitions, criterion_count), dtype=float)
    rng = np.random.default_rng(seed)
    probabilities = np.full(item_count, 1.0 / item_count)
    for replicate in range(repetitions):
        multiplicity = rng.multinomial(item_count, probabilities).astype(float)
        combined = np.tensordot(multiplicity, confusions, axes=(0, 0))
        for criterion in range(criterion_count):
            samples[replicate, criterion] = weighted_qwk_from_confusion(
                combined[criterion]
            )
    if np.isnan(samples).any():
        raise ValueError("Undefined human-human QWK in an item bootstrap sample")
    return observed, np.percentile(samples, [2.5, 97.5], axis=0).T


def secondary_metrics_from_confusions(confusions: np.ndarray) -> dict[str, np.ndarray]:
    """Average standard agreement/error metrics across the two human raters."""
    combined = confusions.sum(axis=0)
    model_count, criterion_count, rater_count = combined.shape[:3]
    names = ("exact_agreement", "within_one_agreement", "mae", "macro_f1", "bias")
    metrics = {
        name: np.full((model_count, criterion_count, rater_count), np.nan)
        for name in names
    }
    grid = np.arange(1, 6, dtype=float)
    absolute = np.abs(np.subtract.outer(grid, grid))
    signed = np.subtract.outer(grid, grid)
    within = (absolute <= 1).astype(float)
    for model in range(model_count):
        for criterion in range(criterion_count):
            for rater in range(rater_count):
                matrix = combined[model, criterion, rater]
                total = matrix.sum()
                if total <= 0:
                    continue
                metrics["exact_agreement"][model, criterion, rater] = (
                    np.trace(matrix) / total
                )
                metrics["within_one_agreement"][model, criterion, rater] = (
                    (within * matrix).sum() / total
                )
                metrics["mae"][model, criterion, rater] = (
                    (absolute * matrix).sum() / total
                )
                metrics["bias"][model, criterion, rater] = (
                    (signed * matrix).sum() / total
                )
                predicted = matrix.sum(axis=1)
                observed = matrix.sum(axis=0)
                denominators = predicted + observed
                f1 = np.divide(
                    2 * np.diag(matrix),
                    denominators,
                    out=np.zeros(5, dtype=float),
                    where=denominators > 0,
                )
                metrics["macro_f1"][model, criterion, rater] = f1.mean()
    return {name: values.mean(axis=2) for name, values in metrics.items()}


def worst_score_fill(predictions: np.ndarray, humans: np.ndarray) -> np.ndarray:
    filled = predictions.copy()
    response_count, model_count, criterion_count = filled.shape
    for response in range(response_count):
        for model in range(model_count):
            for criterion in range(criterion_count):
                if np.isnan(filled[response, model, criterion]):
                    human_mean = humans[response, criterion].mean()
                    filled[response, model, criterion] = 1 if human_mean >= 3 else 5
    return filled


def build_item_losses(
    item_indices: np.ndarray,
    predictions: np.ndarray,
    humans: np.ndarray,
    item_count: int,
) -> np.ndarray:
    """Equal-item normalized squared loss; failures receive the maximum loss 1."""
    _, model_count, criterion_count = predictions.shape
    losses = np.empty((item_count, model_count, criterion_count), dtype=float)
    for item in range(item_count):
        responses = np.flatnonzero(item_indices == item)
        for model in range(model_count):
            for criterion in range(criterion_count):
                values = []
                for response in responses:
                    predicted = predictions[response, model, criterion]
                    if np.isnan(predicted):
                        values.append(1.0)
                    else:
                        difference = (predicted - humans[response, criterion]) / 4.0
                        values.append(float(np.mean(difference**2)))
                losses[item, model, criterion] = np.mean(values)
    return losses


def bootstrap_loss_analysis(
    item_losses: np.ndarray,
    directional: np.ndarray,
    omnibus: np.ndarray,
    repetitions: int,
    seed: int,
) -> dict[str, Any]:
    item_count, _, criterion_count = item_losses.shape
    directional_pinv = np.linalg.pinv(directional)
    omnibus_pinv = np.linalg.pinv(omnibus)
    observed_cells = item_losses.mean(axis=0)
    observed_directional = fit_cells(directional_pinv, observed_cells)
    observed_omnibus = fit_cells(omnibus_pinv, observed_cells)
    observed_slopes = observed_omnibus[criterion_count:]
    observed_contrasts = observed_slopes[1:] - observed_slopes[0]

    rng = np.random.default_rng(seed)
    interaction = np.empty(repetitions)
    contrasts = np.empty((repetitions, criterion_count - 1))
    slopes = np.empty((repetitions, criterion_count))
    probabilities = np.full(item_count, 1.0 / item_count)
    for replicate in range(repetitions):
        multiplicity = rng.multinomial(item_count, probabilities).astype(float)
        cells = np.tensordot(multiplicity, item_losses, axes=(0, 0)) / item_count
        directional_beta = fit_cells(directional_pinv, cells)
        omnibus_beta = fit_cells(omnibus_pinv, cells)
        criterion_slopes = omnibus_beta[criterion_count:]
        interaction[replicate] = directional_beta[-1]
        slopes[replicate] = criterion_slopes
        contrasts[replicate] = criterion_slopes[1:] - criterion_slopes[0]
    covariance = np.cov(contrasts, rowvar=False, ddof=1)
    wald = (
        observed_contrasts
        @ np.linalg.pinv(covariance)
        @ observed_contrasts.reshape(-1, 1)
    ).item()
    ci = np.percentile(interaction, [2.5, 97.5]).tolist()
    one_sided_p = float(
        (np.count_nonzero(interaction >= 0) + 1) / (repetitions + 1)
    )
    return {
        "outcome": "normalized squared loss; lower is better; failures mapped to 1",
        "interaction_coefficient": float(observed_directional[-1]),
        "bootstrap_percentile_95_ci": ci,
        "one_sided_p_for_negative_interaction": one_sided_p,
        "direction_supported": bool(
            observed_directional[-1] < 0 and ci[1] < 0
        ),
        "criterion_heterogeneity_wald_chi_square": float(wald),
        "criterion_heterogeneity_df": criterion_count - 1,
        "criterion_heterogeneity_p": float(chi2.sf(wald, criterion_count - 1)),
        "criterion_scale_slopes": {
            criterion: {
                "estimate": float(observed_slopes[index]),
                "bootstrap_percentile_95_ci": np.percentile(
                    slopes[:, index], [2.5, 97.5]
                ).tolist(),
            }
            for index, criterion in enumerate(CRITERIA)
        },
    }


def build_item_confusions(
    item_indices: np.ndarray,
    predictions: np.ndarray,
    humans: np.ndarray,
    item_count: int,
    equal_item_weighting: bool = True,
) -> tuple[np.ndarray, np.ndarray]:
    response_count, model_count, criterion_count = predictions.shape
    model_conf = np.zeros((item_count, model_count, criterion_count, 2, 5, 5))
    human_conf = np.zeros((item_count, criterion_count, 5, 5))

    for item_index in range(item_count):
        in_item = np.flatnonzero(item_indices == item_index)
        if in_item.size == 0:
            continue
        human_weight = 1.0 / in_item.size if equal_item_weighting else 1.0
        for response in in_item:
            for criterion in range(criterion_count):
                human_conf[
                    item_index,
                    criterion,
                    humans[response, criterion, 0] - 1,
                    humans[response, criterion, 1] - 1,
                ] += human_weight
        for model in range(model_count):
            for criterion in range(criterion_count):
                valid = in_item[~np.isnan(predictions[in_item, model, criterion])]
                if valid.size == 0:
                    continue
                weight = 1.0 / valid.size if equal_item_weighting else 1.0
                for response in valid:
                    predicted = int(predictions[response, model, criterion]) - 1
                    for rater in range(2):
                        observed = humans[response, criterion, rater] - 1
                        model_conf[
                            item_index, model, criterion, rater, predicted, observed
                        ] += weight
    return model_conf, human_conf


def design_matrices(
    parameters: np.ndarray, jdi: np.ndarray
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    scale = np.log2(parameters / 0.6)
    scale_z = (scale - scale.mean()) / scale.std(ddof=0)
    jdi_z = (jdi - jdi.mean()) / jdi.std(ddof=0)
    model_count = parameters.size
    criterion_count = jdi.size
    rows = model_count * criterion_count

    directional = np.zeros((rows, criterion_count + 2))
    omnibus = np.zeros((rows, criterion_count * 2))
    row_index = 0
    for model in range(model_count):
        for criterion in range(criterion_count):
            directional[row_index, criterion] = 1.0
            directional[row_index, criterion_count] = scale_z[model]
            directional[row_index, criterion_count + 1] = (
                scale_z[model] * jdi_z[criterion]
            )
            omnibus[row_index, criterion] = 1.0
            omnibus[row_index, criterion_count + criterion] = scale_z[model]
            row_index += 1
    return directional, omnibus, scale, scale_z


def fit_cells(pseudoinverse: np.ndarray, cells: np.ndarray) -> np.ndarray:
    vector = cells.reshape(-1)
    if np.isnan(vector).any():
        raise ValueError("A QWK cell is undefined; inspect score variation/missing items")
    return pseudoinverse @ vector


def bootstrap_analysis(
    model_confusions: np.ndarray,
    directional: np.ndarray,
    omnibus: np.ndarray,
    repetitions: int,
    seed: int,
) -> dict[str, Any]:
    item_count = model_confusions.shape[0]
    criterion_count = model_confusions.shape[2]
    directional_pinv = np.linalg.pinv(directional)
    omnibus_pinv = np.linalg.pinv(omnibus)

    observed_cells = model_agreement_from_confusions(model_confusions)
    observed_directional = fit_cells(directional_pinv, observed_cells)
    observed_omnibus = fit_cells(omnibus_pinv, observed_cells)
    observed_slopes = observed_omnibus[criterion_count:]
    observed_contrasts = observed_slopes[1:] - observed_slopes[0]

    rng = np.random.default_rng(seed)
    boot_interaction = np.empty(repetitions)
    boot_slopes = np.empty((repetitions, criterion_count))
    boot_contrasts = np.empty((repetitions, criterion_count - 1))
    boot_cells = np.empty((repetitions, *observed_cells.shape))
    probabilities = np.full(item_count, 1.0 / item_count)
    for replicate in range(repetitions):
        multiplicity = rng.multinomial(item_count, probabilities).astype(float)
        sampled = np.tensordot(multiplicity, model_confusions, axes=(0, 0))
        cells = np.empty(observed_cells.shape, dtype=float)
        for model in range(sampled.shape[0]):
            for criterion in range(sampled.shape[1]):
                cells[model, criterion] = np.mean(
                    [
                        weighted_qwk_from_confusion(sampled[model, criterion, rater])
                        for rater in range(2)
                    ]
                )
        directional_beta = fit_cells(directional_pinv, cells)
        omnibus_beta = fit_cells(omnibus_pinv, cells)
        slopes = omnibus_beta[criterion_count:]
        boot_interaction[replicate] = directional_beta[-1]
        boot_cells[replicate] = cells
        boot_slopes[replicate] = slopes
        boot_contrasts[replicate] = slopes[1:] - slopes[0]

    covariance = np.cov(boot_contrasts, rowvar=False, ddof=1)
    wald = (
        observed_contrasts
        @ np.linalg.pinv(covariance)
        @ observed_contrasts.reshape(-1, 1)
    ).item()
    h1a_p = float(chi2.sf(wald, criterion_count - 1))
    h1b_p = float((np.count_nonzero(boot_interaction <= 0) + 1) / (repetitions + 1))
    interaction_ci = np.percentile(boot_interaction, [2.5, 95, 97.5]).tolist()
    slope_ci = np.percentile(boot_slopes, [2.5, 97.5], axis=0).T

    return {
        "observed_cells": observed_cells,
        "observed_cell_95_ci": np.percentile(
            boot_cells, [2.5, 97.5], axis=0
        ).transpose(1, 2, 0),
        "h1a": {
            "test": "Scale by Criterion 7-df omnibus bootstrap-covariance Wald test",
            "wald_chi_square": wald,
            "df": criterion_count - 1,
            "two_sided_p": h1a_p,
            "supported_alpha_0_05": h1a_p < 0.05,
        },
        "h1b": {
            "test": "positive Scale by JDI interaction",
            "coefficient": float(observed_directional[-1]),
            "bootstrap_percentile_95_ci": [interaction_ci[0], interaction_ci[2]],
            "one_sided_95_lower_bound": interaction_ci[0],
            "bootstrap_one_sided_p": h1b_p,
            "supported_alpha_0_05": bool(
                observed_directional[-1] > 0 and interaction_ci[0] > 0
            ),
        },
        "criterion_scale_slopes_standardized": observed_slopes,
        "criterion_scale_slope_95_ci": slope_ci,
        "valid_bootstrap_repetitions": repetitions,
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--prediction",
        action="append",
        default=[],
        metavar="MODEL=PATH",
        help="Repeat six times, once for each Qwen3 size",
    )
    parser.add_argument(
        "--parameter",
        action="append",
        default=[],
        metavar="MODEL=BILLIONS",
        help="Dense parameter count corresponding to each prediction alias",
    )
    parser.add_argument(
        "--manifest",
        type=Path,
        default=Path("artifacts/manifests/constructed_evaluation_v1.jsonl"),
    )
    parser.add_argument(
        "--jdi",
        type=Path,
        default=Path("configs/paper1_rubric_judgment_demand_v1.json"),
    )
    parser.add_argument(
        "--workspace", type=Path, default=Path(__file__).resolve().parents[1]
    )
    parser.add_argument("--output-dir", type=Path, default=Path("artifacts/analysis"))
    parser.add_argument("--bootstrap", type=int, default=9999)
    parser.add_argument("--seed", type=int, default=20260903)
    parser.add_argument("--allow-mock-for-test", action="store_true")
    return parser.parse_args()


def resolve(workspace: Path, path: Path) -> Path:
    return path.resolve() if path.is_absolute() else (workspace / path).resolve()


def main() -> int:
    args = parse_args()
    workspace = args.workspace.resolve()
    try:
        prediction_paths = parse_mapping(args.prediction, Path)
        parameter_map = parse_mapping(args.parameter, float)
        if set(prediction_paths) != set(parameter_map) or len(prediction_paths) != 6:
            raise ValueError("Exactly six matching --prediction and --parameter aliases required")
        if sorted(parameter_map.values()) != [0.6, 1.7, 4.0, 8.0, 14.0, 32.0]:
            raise ValueError("Parameter series must be 0.6, 1.7, 4, 8, 14, and 32B")
        ordered_models = sorted(parameter_map, key=parameter_map.get)
        prediction_paths = {
            name: resolve(workspace, prediction_paths[name]) for name in ordered_models
        }
        manifest_path = resolve(workspace, args.manifest)
        jdi_path = resolve(workspace, args.jdi)
        output_dir = resolve(workspace, args.output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        manifest = read_manifest(manifest_path)
        if len(manifest) != 4000 or len({row["item_id"] for row in manifest}) != 60:
            raise ValueError("Primary manifest must contain 4,000 records and 60 items")
        record_index = {row["record_id"]: index for index, row in enumerate(manifest)}
        item_names = sorted({row["item_id"] for row in manifest})
        item_lookup = {name: index for index, name in enumerate(item_names)}
        item_indices = np.array([item_lookup[row["item_id"]] for row in manifest])

        jdi_config = json.loads(jdi_path.read_text(encoding="utf-8"))
        jdi_map = {
            entry["criterion"]: entry["judgment_demand_index"]
            for entry in jdi_config["criteria"]
        }
        jdi = np.array([jdi_map[criterion] for criterion in CRITERIA], dtype=float)

        humans = np.empty((len(manifest), len(CRITERIA), 2), dtype=int)
        for index, pointer in enumerate(manifest):
            record = load_json_member(workspace, pointer)
            first, second = human_scores(record)
            for criterion_index, criterion in enumerate(CRITERIA):
                humans[index, criterion_index] = [first[criterion], second[criterion]]

        predictions = np.full(
            (len(manifest), len(ordered_models), len(CRITERIA)), np.nan, dtype=float
        )
        failure_counts: dict[str, int] = {}
        prediction_hashes: dict[str, str] = {}
        for model_index, model in enumerate(ordered_models):
            path = prediction_paths[model]
            prediction_hashes[model] = sha256_file(path)
            rows = read_prediction_file(path, args.allow_mock_for_test)
            unknown = set(rows) - set(record_index)
            if unknown:
                raise ValueError(f"{model} contains {len(unknown)} unknown record IDs")
            failures = 0
            for record_id, manifest_index in record_index.items():
                prediction = rows.get(record_id)
                if not prediction or prediction.get("status") != "ok":
                    failures += 1
                    continue
                scores = prediction.get("scores", {})
                if set(scores) != set(CRITERIA):
                    failures += 1
                    continue
                for criterion_index, criterion in enumerate(CRITERIA):
                    value = scores[criterion]
                    if isinstance(value, bool) or not isinstance(value, int) or not 1 <= value <= 5:
                        raise ValueError(f"Illegal score for {model}/{record_id}/{criterion}")
                    predictions[manifest_index, model_index, criterion_index] = value
            failure_counts[model] = failures

        model_conf, human_conf = build_item_confusions(
            item_indices, predictions, humans, len(item_names)
        )
        response_conf, response_human_conf = build_item_confusions(
            item_indices,
            predictions,
            humans,
            len(item_names),
            equal_item_weighting=False,
        )
        predictions_worst = worst_score_fill(predictions, humans)
        worst_conf, _ = build_item_confusions(
            item_indices, predictions_worst, humans, len(item_names)
        )
        worst_qwk = model_agreement_from_confusions(worst_conf)
        secondary = secondary_metrics_from_confusions(model_conf)
        item_losses = build_item_losses(
            item_indices, predictions, humans, len(item_names)
        )
        parameters = np.array([parameter_map[name] for name in ordered_models])
        directional, omnibus, scale, scale_z = design_matrices(parameters, jdi)
        analysis = bootstrap_analysis(
            model_conf, directional, omnibus, args.bootstrap, args.seed
        )
        loss_analysis = bootstrap_loss_analysis(
            item_losses, directional, omnibus, args.bootstrap, args.seed + 1
        )
        human_qwk, human_qwk_ci = bootstrap_human_agreement(
            human_conf, args.bootstrap, args.seed
        )
        response_weighted_qwk = model_agreement_from_confusions(response_conf)
        response_weighted_human_qwk = human_agreement_from_confusions(
            response_human_conf
        )
        cells = analysis.pop("observed_cells")
        cell_ci = analysis.pop("observed_cell_95_ci")
        slopes = analysis.pop("criterion_scale_slopes_standardized")
        slope_ci = analysis.pop("criterion_scale_slope_95_ci")

        rows_out: list[dict[str, Any]] = []
        for model_index, model in enumerate(ordered_models):
            for criterion_index, criterion in enumerate(CRITERIA):
                rows_out.append(
                    {
                        "model": model,
                        "parameters_b": parameter_map[model],
                        "scale_log2_p_over_0_6": float(scale[model_index]),
                        "criterion": criterion,
                        "jdi": int(jdi[criterion_index]),
                        "model_human_qwk": float(cells[model_index, criterion_index]),
                        "model_human_qwk_bootstrap_95_low": float(
                            cell_ci[model_index, criterion_index, 0]
                        ),
                        "model_human_qwk_bootstrap_95_high": float(
                            cell_ci[model_index, criterion_index, 1]
                        ),
                        "model_human_qwk_worst_score_sensitivity": float(
                            worst_qwk[model_index, criterion_index]
                        ),
                        "model_human_qwk_response_weighted_sensitivity": float(
                            response_weighted_qwk[model_index, criterion_index]
                        ),
                        "human_human_qwk": float(human_qwk[criterion_index]),
                        "human_human_qwk_bootstrap_95_low": float(
                            human_qwk_ci[criterion_index, 0]
                        ),
                        "human_human_qwk_bootstrap_95_high": float(
                            human_qwk_ci[criterion_index, 1]
                        ),
                        "human_human_qwk_response_weighted_sensitivity": float(
                            response_weighted_human_qwk[criterion_index]
                        ),
                        "exact_agreement": float(
                            secondary["exact_agreement"][model_index, criterion_index]
                        ),
                        "within_one_agreement": float(
                            secondary["within_one_agreement"][model_index, criterion_index]
                        ),
                        "mae": float(secondary["mae"][model_index, criterion_index]),
                        "macro_f1": float(
                            secondary["macro_f1"][model_index, criterion_index]
                        ),
                        "signed_bias": float(
                            secondary["bias"][model_index, criterion_index]
                        ),
                        "normalized_squared_loss": float(
                            item_losses[:, model_index, criterion_index].mean()
                        ),
                        "model_failures": failure_counts[model],
                    }
                )
        csv_path = output_dir / "paper1_primary_qwk_cells.csv"
        with csv_path.open("w", encoding="utf-8-sig", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows_out[0]))
            writer.writeheader()
            writer.writerows(rows_out)

        criterion_slopes = {}
        for index, criterion in enumerate(CRITERIA):
            criterion_slopes[criterion] = {
                "jdi": int(jdi[index]),
                "slope_per_1sd_log_scale": float(slopes[index]),
                "bootstrap_percentile_95_ci": slope_ci[index].tolist(),
            }
        central_supported = bool(
            analysis["h1a"]["supported_alpha_0_05"]
            and analysis["h1b"]["supported_alpha_0_05"]
        )
        result = {
            "analysis_version": "paper1-primary-qwk-v1",
            "generated_at_utc": datetime.now(timezone.utc).isoformat(),
            "manifest": {
                "path": str(manifest_path),
                "sha256": sha256_file(manifest_path),
                "records": len(manifest),
                "items": len(item_names),
            },
            "prediction_sha256": prediction_hashes,
            "models_in_scale_order": ordered_models,
            "parameters_b": {name: parameter_map[name] for name in ordered_models},
            "criteria": list(CRITERIA),
            "judgment_demand_index": {
                criterion: int(jdi_map[criterion]) for criterion in CRITERIA
            },
            "failure_counts": failure_counts,
            "equal_item_weighting": True,
            "bootstrap": {
                "unit": "item",
                "items": len(item_names),
                "repetitions": args.bootstrap,
                "seed": args.seed,
            },
            **analysis,
            "criterion_slopes": criterion_slopes,
            "response_level_loss_robustness_item_bootstrap": loss_analysis,
            "central_conjunctive_claim_supported": central_supported,
            "mock_test_mode": args.allow_mock_for_test,
            "cell_table": str(csv_path),
        }
        json_path = output_dir / "paper1_primary_qwk_results.json"
        json_path.write_text(
            json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        print(f"results={json_path}")
        print(f"cells={csv_path}")
        print(
            f"H1a_p={result['h1a']['two_sided_p']:.6g} "
            f"H1b_beta={result['h1b']['coefficient']:.6g} "
            f"H1b_p={result['h1b']['bootstrap_one_sided_p']:.6g} "
            f"central_supported={central_supported}"
        )
        return 0
    except Exception as exc:
        print(f"ERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
