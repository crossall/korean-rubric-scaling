#!/usr/bin/env python3
"""Shared record loading, prompt rendering, and score validation for Paper 1."""

from __future__ import annotations

import hashlib
import json
import re
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any


CRITERIA = (
    "task_1",
    "content_1",
    "content_2",
    "content_3",
    "organization_1",
    "organization_2",
    "expression_1",
    "expression_2",
)


@dataclass(frozen=True)
class PromptPair:
    system: str
    user: str
    prompt_sha256: str


def load_json_member(workspace: Path, pointer: dict[str, Any]) -> dict[str, Any]:
    zip_path = (workspace / pointer["zip_path"]).resolve()
    if workspace.resolve() not in zip_path.parents:
        raise ValueError("Manifest ZIP path escapes workspace")
    with zipfile.ZipFile(zip_path) as archive:
        raw = archive.read(pointer["member"])
    for encoding in ("utf-8-sig", "utf-8", "cp949"):
        try:
            record = json.loads(raw.decode(encoding))
            break
        except (UnicodeDecodeError, json.JSONDecodeError):
            continue
    else:
        raise ValueError(f"Could not decode source JSON for {pointer['record_id']}")

    text = str(record["essay_answer"].get("text", ""))
    observed_hash = hashlib.sha256(text.encode("utf-8")).hexdigest()
    if observed_hash != pointer["content_sha256"]:
        raise ValueError(f"Content hash mismatch for {pointer['record_id']}")
    if str(record["essay_question"]["id"]) != str(pointer["item_id"]):
        raise ValueError(f"Item ID mismatch for {pointer['record_id']}")
    if str(record["essay_answer"]["id"]) != str(pointer["answer_id"]):
        raise ValueError(f"Answer ID mismatch for {pointer['record_id']}")
    return record


def load_prompt_template(path: Path) -> tuple[str, str]:
    text = path.read_text(encoding="utf-8").replace("\r\n", "\n")
    marker = "[USER TEMPLATE]"
    repair_marker = "[REPAIR]"
    if (
        not text.startswith("[SYSTEM]\n")
        or marker not in text
        or repair_marker not in text
    ):
        raise ValueError(
            "Prompt file must contain [SYSTEM], [USER TEMPLATE], and [REPAIR]"
        )
    system, user = text[len("[SYSTEM]\n") :].split(marker, 1)
    user, _ = user.split(repair_marker, 1)
    return system.strip(), user.strip()


def load_repair_instruction(path: Path) -> str:
    text = path.read_text(encoding="utf-8").replace("\r\n", "\n")
    marker = "[REPAIR]"
    if marker not in text:
        raise ValueError("Prompt file does not contain [REPAIR]")
    return text.split(marker, 1)[1].strip()


def rubric_block(record: dict[str, Any]) -> str:
    analytic = record["rubric"]["analytic"]
    if set(analytic) != set(CRITERIA):
        raise ValueError(
            f"Expected exactly {list(CRITERIA)}, observed {sorted(analytic)}"
        )
    sections: list[str] = []
    for criterion in CRITERIA:
        rubric = analytic[criterion]
        lines = [f"- {criterion} | {rubric.get('name', '')}"]
        for score in range(5, 0, -1):
            lines.append(f"  {score}점: {rubric.get(f'evaluation_{score}', '')}")
        sections.append("\n".join(lines))
    return "\n".join(sections)


def render_prompt(record: dict[str, Any], prompt_path: Path) -> PromptPair:
    system, template = load_prompt_template(prompt_path)
    question = record["essay_question"]
    rubric = record["rubric"]
    answer = record["essay_answer"]
    values = {
        "grade": question.get("grade", ""),
        "subject": question.get("subject", ""),
        "topic": question.get("topic", ""),
        "prompt": question.get("prompt", ""),
        "keyword": question.get("keyword", "제공되지 않음"),
        "rubric_purpose": rubric.get("purpose", question.get("purpose", "")),
        "rubric_achievement": rubric.get("achievement", ""),
        "rubric_block": rubric_block(record),
        "response_text": answer.get("text", ""),
    }
    user = template.format_map(values)
    digest = hashlib.sha256(
        json.dumps(
            {"system": system, "user": user},
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    ).hexdigest()
    return PromptPair(system=system, user=user, prompt_sha256=digest)


def make_repair_prompt(prompt: PromptPair, prompt_path: Path) -> PromptPair:
    instruction = load_repair_instruction(prompt_path)
    user = f"{prompt.user}\n\n[출력 형식 재요청]\n{instruction}"
    digest = hashlib.sha256(
        json.dumps(
            {"system": prompt.system, "user": user},
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    ).hexdigest()
    return PromptPair(system=prompt.system, user=user, prompt_sha256=digest)


def score_schema() -> dict[str, Any]:
    properties = {
        criterion: {"type": "integer", "enum": [1, 2, 3, 4, 5]}
        for criterion in CRITERIA
    }
    return {
        "type": "object",
        "properties": properties,
        "required": list(CRITERIA),
        "additionalProperties": False,
    }


def parse_scores(value: str | dict[str, Any]) -> dict[str, int]:
    if isinstance(value, str):
        candidate = value.strip()
        fenced = re.fullmatch(
            r"```(?:json)?\s*(\{.*\})\s*```", candidate, flags=re.DOTALL | re.IGNORECASE
        )
        if fenced:
            candidate = fenced.group(1)
        parsed = json.loads(candidate)
    else:
        parsed = value
    if not isinstance(parsed, dict):
        raise ValueError("Score response must be a JSON object")
    if set(parsed) != set(CRITERIA):
        raise ValueError(
            f"Score keys must be exactly {list(CRITERIA)}; got {sorted(parsed)}"
        )
    scores: dict[str, int] = {}
    for criterion in CRITERIA:
        score = parsed[criterion]
        if isinstance(score, bool) or not isinstance(score, int) or not 1 <= score <= 5:
            raise ValueError(f"{criterion} must be an integer from 1 to 5")
        scores[criterion] = score
    return scores


def read_manifest(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    seen: set[str] = set()
    with path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, 1):
            if not line.strip():
                continue
            row = json.loads(line)
            record_id = row["record_id"]
            if record_id in seen:
                raise ValueError(f"Duplicate record_id at line {line_number}: {record_id}")
            seen.add(record_id)
            rows.append(row)
    return rows


def human_scores(record: dict[str, Any]) -> tuple[dict[str, int], dict[str, int]]:
    """Extract the two human analytic score sets only at analysis time.

    This function is intentionally separate from prompt construction.  AI Hub uses
    a list of two values for each analytic criterion in the inspected release.
    """
    personal = record["score"]["personal"]["analytic"]
    first: dict[str, int] = {}
    second: dict[str, int] = {}
    for criterion in CRITERIA:
        entry = personal[criterion]
        values = entry.get("score") if isinstance(entry, dict) else entry
        if not isinstance(values, list) or len(values) != 2:
            raise ValueError(f"Expected two human scores for {criterion}")
        first[criterion], second[criterion] = int(values[0]), int(values[1])
    return first, second
