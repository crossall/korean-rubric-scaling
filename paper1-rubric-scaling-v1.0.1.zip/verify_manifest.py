"""Verify packaged files without reading external inputs or making requests."""
import hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def main():
    count = 0
    for line in (ROOT / 'MANIFEST.sha256').read_text('utf-8').splitlines():
        digest, name = line.split('  ', 1)
        path = (ROOT / name).resolve()
        if ROOT not in path.parents:
            raise ValueError('Manifest path escapes package')
        if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            raise ValueError(f'Checksum mismatch: {name}')
        count += 1
    print(f'PASS: {count} packaged file checksums')

if __name__ == '__main__':
    main()
