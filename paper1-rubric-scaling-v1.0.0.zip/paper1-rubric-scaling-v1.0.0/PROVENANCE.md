# Provenance and limits

## Data

- AI Hub, constructed-response writing evaluation data, dataset 71818: https://www.aihub.or.kr/aihubdata/data/view.do?currMenu=115&topMenu=100&dataSetSn=71818
- AI Hub, essay writing evaluation data, dataset 71819: https://www.aihub.or.kr/aihubdata/data/view.do?currMenu=115&topMenu=100&dataSetSn=71819
- NIA (2025), AI data construction guide v3.5, Vol. 2: https://www.nia.or.kr/site/nia_kor/ex/bbs/View.do?bcIdx=28106&cbIdx=26537
- ReadingM (2025-01-31), project completion announcement: https://readingm.com/notice/detail?id=304&type=notice
- Access conditions: https://aihub.or.kr/intrcn/guid/usagepolicy.do

The NIA constructed-response chapter documents collection from school-age writers, transcription and anonymization (pp. 78, 82, 87, 90). The category label LLM is not by itself evidence of synthetic response authorship. All 6,000 current evaluation records name ReadingM in their collection-reference field. These facts establish the documented collection route, not an independent audit of individual consent records or unassisted authorship. Detailed constructed-response documentation is not asserted to independently verify every essay record.

The 4,000/2,000 evaluation records were the available Validation splits. The constructed set has 60 represented items and eight analytic criteria. The essay set has 89 items and 24 analytic rubric keys, covering eight returned criterion scores. Counts refer to responses, not verified unique students.

## Related work and sample reuse

Kim (2026), *Inter-rater agreement in Korean constructed-response writing assessment*, Frontiers in Education, 11, 1887497: https://doi.org/10.3389/feduc.2026.1887497

That work and its public repository (https://github.com/crossall/essay-grading-agreement) describe all Grade-5 Training+Validation records: 8,407 constructed and 4,466 essay responses. The current evaluation includes 956 and 534 Grade-5 responses, respectively. Thus 1,490 current responses (24.83% of 6,000) meet that previous selection rule. This is a source-population/selection-rule comparison, not a direct match against a preserved historical record-level manifest. The current human reference must not be described as an independent replication on a wholly new population.

Related author-associated frontier-bias and HRMT work also uses the AI Hub source population. Exact response-level overlap with their analysis subsets was not established. Their endpoints differ from the current Qwen within-family scaling analysis. Repository separation is not evidence of statistical sample independence.

## Analysis status

The original JDI features were frozen before LLM-outcome analysis, but after human agreement had been seen. Three supplied forms contained AI-assisted material and do not establish a historically independent, blinded expert-validation gate. Model-by-criterion heterogeneity and the originally predicted positive size-by-JDI mechanism are distinct claims. The latter was not supported. Answer-blind, supervised-text, within-item, literal-keyword and first-attempt controls are post-outcome diagnostics and are not relabeled confirmatory.

Preserved source code may retain words such as "preregistered" from the original plan. Those comments are not independent evidence of external preregistration or successful expert validation. The current manuscript and analysis qualification take precedence for interpreting status.

## Reproducibility boundaries

Aggregate replay regenerates presentation from frozen summaries and archived bootstrap intervals. It cannot verify record-level predictions without restricted inputs. Qwen revision claims are supported by the private initialization records, whereas API aliases are not immutable snapshot guarantees. The complete Kanana local-patch manifest remains unresolved. Per-row token/latency logs do not support a fully reconciled cross-provider cost frontier. This candidate does not assert a full environment capture or exact rerun of every historical model.

This is secondary analysis with no new recruitment, contact or intervention. On 2026-10-13, the author confirmed that exemption P01-202605-01-076 from the Public Institutional Bioethics Committee covers the present secondary analysis. This statement relies on author confirmation; the release maintainer did not independently inspect the determination document. Data-access permission is distinct from ethics determination. Private ethics documents and personal expert forms are excluded. Original Korean prompts are preserved for experimental fidelity; they are not student text.
