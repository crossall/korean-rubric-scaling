# Korean rubric-conditional model-size study: computational materials

Author: Taeryeong Kim. Version: 1.0.0, prepared 2026-10-13.

This release accompanies *Rubric dependent associations between Qwen3 model size and Korean constructed response scoring*. It is separate from the HRMT project. Historical configurations retain the original working title and intended plan; those records are not rewritten as though the current exploratory qualification had always applied.

## Offline reproduction

Use Python 3.11 or newer with `requirements-analysis.txt`; this candidate was tested with the recorded Python version in `release-metadata.json`. Once dependencies are installed, these commands need no network, API key, GPU or student data:

```sh
python -m pip install -r requirements-analysis.txt
python verify_manifest.py
python reproduce_aggregate.py
python reproduce_review.py
python -m unittest discover -s scripts -p "test_paper1*.py"
```

The first replay regenerates the original five tables and two figures. The second regenerates Table 6 and the outcome-known noninferiority calculation sensitivity from archived paired model-by-criterion QWK draws. Both check their outputs against saved targets. All 28 synthetic tests must pass. Test Korean phrases are artificial examples, not student answers. Outputs go to `replayed/`.

These are **aggregate replay and computational tests**, not independent replication of the historical model calls or record-level human ratings. The two human annotation positions are not verified identities of the same two people across all records. JDI interpretation remains exploratory; neither failed positive hypotheses nor later controls are relabeled confirmatory.

## Contents

- `aggregate/`: the original summaries, new human distributions, rater-slot comparisons, grade descriptions and first/final protocol results. `ni_qwk_bootstrap.npz` contains only 10-by-8 QWK point estimates and 9,999 paired draws, in the model and rubric order of `constructed.json`. It excludes original item IDs, resampling multiplicities, per-item sufficient statistics and response-level predictions.
- `expected/`: the unchanged first five tables and new Table 6 for replay checking.
- `scripts/`: archived computational source, current reviewer-diagnostic code and synthetic tests. Record-level verification scripts require restricted inputs and are not invoked by the offline commands.
- `configs/`: historical plan, original prompt template, references and reduced investigator JDI summary; no item-specific source rubric text.
- `SUPPLEMENTARY_METHODS.md`: detailed interpretation and limitations. The scientific manuscript itself is not included or relicensed.
- `PROVENANCE.md`: collection route, related work/sample reuse, chronology and reproducibility limitations.
- `LICENSE-CODE.txt`, `LICENSE-DOCUMENTATION.md`: scoped licenses; no third-party rights are granted.
- `MANIFEST.sha256`: file integrity, not scientific-validity certification.

The old source modules are provided for inspection. Some scoring modules can make paid calls when separately configured; the offline commands do not execute them. Do not run historical inference just to replay the manuscript.

## Restricted inputs and scope

AI Hub datasets 71818 and 71819 must be obtained under their access conditions. Evaluation used available Validation splits, not official Test files: 4,000 constructed responses and 2,000 essays. Full record-level reanalysis additionally needs matching private manifests and historical predictions, as described in the source input contracts. A seed cannot replace those inputs. New API output would be a new experiment, not guaranteed reconstruction of historical aliases.

Student text, response identifiers, original text hashes, row-level human scores/predictions, raw API logs, item-specific source rubrics, credentials, private expert forms and ethics documents are excluded. Grade descriptions are aggregate exploratory comparisons, not fairness certification. No new independent item sample is asserted. On 2026-10-13, the author confirmed that the existing exemption P01-202605-01-076 applies to this secondary analysis. The private determination document is not included. The unresolved Kanana local-patch manifest and incomplete cross-provider billing reconciliation remain limitations.

## Change from internal candidates

The internal rc1 and rc2 archives remain unchanged. The reviewed computations from rc2 are retained; v1.0.0 adds archive metadata and author-confirmed ethics scope. The candidate series added reviewer-diagnostic aggregates/code, Table 6, the paired aggregate NI arrays and replay, supplementary methods, and scoped licenses selected under the author's delegation. Original primary tables, figures and inference outputs are unchanged. The basic-bootstrap comparison does not replace the original percentile analysis or establish exact finite-sample validity.

## Archive and citation

Version archive: https://doi.org/10.5281/zenodo.23322382

Repository: https://github.com/crossall/korean-rubric-scaling

The DOI identifies these computational materials, not an accepted journal article. The author authorized public release of code and aggregate results. Original data remain subject to AI Hub access conditions; prior transfer permission is not blanket permission to redistribute source records. Cite the version DOI and preserve the file-scoped license notices.

Substantial AI assistance covered planning, code, checks, literature work and drafting. The human author remains responsible. No complete pre-AI source history, exhaustive prompt archive, new expert attestation or approval document has been reconstructed.
