# Criterion-Dependent Associations between Qwen3 Model Size and Zero-Shot Scoring of Korean Constructed Responses — Code and Aggregate Reproducibility Materials



Author: Taeryeong Kim. Version: 1.0.2, prepared 2026-10-14.



This release accompanies *Criterion-Dependent Associations between Qwen3 Model Size and Zero-Shot Scoring of Korean Constructed Responses*. It is separate from the HRMT project. Historical configurations retain the original working title and intended plan; those records are not rewritten as though the current exploratory qualification had always applied.



## Offline reproduction



Use Python 3.11 or newer with `requirements-analysis.txt`; this release was tested with the recorded Python version in `release-metadata.json`. Once dependencies are installed, these commands need no network, API key, GPU or student data:



```sh

python -m pip install -r requirements-analysis.txt

python verify_manifest.py

python reproduce_aggregate.py

python reproduce_review.py

python -m unittest discover -s scripts -p "test_paper1*.py"

```



The first replay regenerates the original five tables and two figures. The second regenerates Table 6 and the outcome-known noninferiority calculation sensitivity from archived paired model-by-criterion QWK draws. Both check their outputs against saved targets. All 28 synthetic tests must pass. Test Korean phrases are artificial examples, not student answers. Outputs go to `replayed/`.



These are **aggregate replay and computational tests**, not independent replication of the historical model calls or record-level human ratings. The two human annotation positions are not verified identities of the same two people across all records. JDI interpretation remains exploratory; neither failed positive hypotheses nor later controls are relabeled confirmatory.



## Contents



- `aggregate/`: the original summaries, new human distributions, rater-slot comparisons, grade descriptions and first/final protocol results. `ni_qwk_bootstrap.npz` contains only 10-by-8 QWK point estimates and 9,999 paired draws, in the model and rubric order of `constructed.json`. It excludes original item IDs, resampling multiplicities, per-item sufficient statistics and response-level predictions.

- `expected/`: the unchanged first five tables and new Table 6 for replay checking.

- `scripts/`: archived computational source, current reviewer-diagnostic code and synthetic tests. Record-level verification scripts require restricted inputs and are not invoked by the offline commands.

- `configs/`: historical plan, original prompt template, references and reduced investigator JDI summary; no item-specific source rubric text.

- `SUPPLEMENTARY_METHODS.md` and `Paper1_Applied_Sciences_Supplement_S1_20261014.pdf`: aligned Supplementary Methods S1, detailed interpretation and limitations. Numeric reference labels in S1 refer to the accompanying manuscript bibliography, reproduced in `REFERENCES.txt`. The scientific manuscript itself is not included or relicensed.

- `PROVENANCE.md`: collection route, related work/sample reuse, chronology and reproducibility limitations.

- `LICENSE-CODE.txt`, `LICENSE-DOCUMENTATION.md`: scoped licenses; no third-party rights are granted.

- `MANIFEST.sha256`: file integrity, not scientific-validity certification.



The old source modules are provided for inspection. Some scoring modules can make paid calls when separately configured; the offline commands do not execute them. Do not run historical inference just to replay the manuscript.



## Restricted inputs and scope



AI Hub datasets 71818 and 71819 must be obtained under their access conditions. Evaluation used available Validation splits, not official Test files: 4,000 constructed responses and 2,000 essays. Full record-level reanalysis additionally needs matching private manifests and historical predictions, as described in the source input contracts. A seed cannot replace those inputs. New API output would be a new experiment, not guaranteed reconstruction of historical aliases.



Student text, response identifiers, original text hashes, row-level human scores/predictions, raw API logs, item-specific source rubrics, credentials, private expert forms and ethics documents are excluded. Grade descriptions are aggregate exploratory comparisons, not fairness certification. No new independent item sample is asserted. On 13 October 2026, the author stated that existing exemption P01-202605-01-076 applied to the present secondary analysis. This attestation is not presented as a new institutional determination specifically covering hosted or external API processing; the private determination is not included in the public release. The unresolved Kanana local-patch manifest and incomplete cross-provider billing reconciliation remain limitations.



## Release history

Version **1.0.2** aligns all citation numbers with the final 33-entry manuscript bibliography, adds the related 2026 Huang–Palermo–Wilson journal study, and corrects bibliographic details. `REFERENCES.txt` supplies the complete matching bibliography. Version 1.0.1 is preserved at https://doi.org/10.5281/zenodo.23345003. No code, frozen configuration, aggregate result, numerical finding, or ethics statement changed.


Version **1.0.1** is a documentation-only revision of v1.0.0. It aligns the final manuscript title, citation metadata, README, provenance wording, and Supplementary Methods S1. The S1 PDF in this release is the same file supplied with the journal submission. Code, configurations, aggregate data, expected outputs, and license files are byte-identical to v1.0.0; no new inference or analysis was performed. Historical analysis plans and execution labels remain unchanged.

### Earlier internal candidates



The internal rc1 and rc2 archives remain unchanged. The reviewed computations from rc2 are retained; v1.0.0 adds archive metadata and author-confirmed ethics scope. The candidate series added reviewer-diagnostic aggregates/code, Table 6, the paired aggregate NI arrays and replay, supplementary methods, and scoped licenses selected under the author's delegation. Original primary tables, figures and inference outputs are unchanged. The basic-bootstrap comparison does not replace the original percentile analysis or establish exact finite-sample validity.



## Archive and citation



Version archive: https://doi.org/10.5281/zenodo.23354049



Previous version: https://doi.org/10.5281/zenodo.23345003

All versions (concept DOI): https://doi.org/10.5281/zenodo.23322381

Repository: https://github.com/crossall/korean-rubric-scaling



The DOI identifies these computational materials, not an accepted journal article. The author authorized public release of code and aggregate results. Original data remain subject to AI Hub access conditions; prior transfer permission is not blanket permission to redistribute source records. Cite the version DOI and preserve the file-scoped license notices.



Substantial AI assistance covered planning, code, checks, literature work and drafting. The human author remains responsible. No complete pre-AI source history, exhaustive prompt archive, new expert attestation or approval document has been reconstructed.

